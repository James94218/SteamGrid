/**
 * SteamGrid 前端脚本
 * 移动端菜单、搜索面板、回到顶部、子菜单展开
 */
(function () {
	'use strict';

	var nav = document.getElementById('site-navigation');
	var menuToggle = document.querySelector('.sg-menu-toggle');
	var searchToggle = document.querySelector('.sg-search-toggle');
	var searchPanel = document.querySelector('.sg-search-panel');
	var backTop = document.querySelector('.sg-back-top');

	/* 移动端菜单 */
	if (menuToggle && nav) {
		menuToggle.addEventListener('click', function () {
			var open = nav.classList.toggle('is-open');
			menuToggle.classList.toggle('is-active', open);
			menuToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			document.body.classList.toggle('sg-nav-open', open);
		});
	}

	/* 移动端子菜单：点击父级展开 */
	if (nav) {
		var parents = nav.querySelectorAll('li.menu-item-has-children > a, li.page_item_has_children > a');

		Array.prototype.forEach.call(parents, function (link) {
			link.addEventListener('click', function (event) {
				if (window.innerWidth > 1024) {
					return;
				}

				var sub = link.nextElementSibling;
				if (!sub || !sub.classList.contains('sub-menu')) {
					return;
				}

				event.preventDefault();
				link.parentElement.classList.toggle('open');
			});
		});

		/* 点击导航外部时收起菜单 */
		document.addEventListener('click', function (event) {
			if (!nav.classList.contains('is-open')) {
				return;
			}
			if (event.target.closest('#site-navigation') || event.target.closest('.sg-menu-toggle')) {
				return;
			}
			nav.classList.remove('is-open');
			document.body.classList.remove('sg-nav-open');
			if (menuToggle) {
				menuToggle.classList.remove('is-active');
				menuToggle.setAttribute('aria-expanded', 'false');
			}
		});
	}

	/* 搜索面板 */
	if (searchToggle && searchPanel) {
		searchToggle.addEventListener('click', function () {
			var open = searchPanel.classList.toggle('is-open');
			searchToggle.setAttribute('aria-expanded', open ? 'true' : 'false');

			if (open) {
				var field = searchPanel.querySelector('input[type="search"]');
				if (field) {
					field.focus();
				}
			}
		});
	}

	/* 回到顶部 */
	if (backTop) {
		var onScroll = function () {
			backTop.classList.toggle('is-visible', window.scrollY > 420);
		};

		window.addEventListener('scroll', onScroll, { passive: true });
		onScroll();

		backTop.addEventListener('click', function () {
			window.scrollTo({ top: 0, behavior: 'smooth' });
		});
	}
})();
