/**
 * 小工具页：站点名片从媒体库选择头像
 */
(function ($) {
	'use strict';

	$(document).on('click', '.sg-widget-media', function (event) {
		event.preventDefault();

		var $button = $(this);
		var $input = $button.siblings('input.sg-widget-avatar');
		if (!$input.length) {
			$input = $button.closest('.widget').find('input.sg-widget-avatar').first();
		}

		var frame = wp.media({
			title: '选择名片头像',
			button: { text: '使用这张图片' },
			multiple: false
		});

		frame.on('select', function () {
			var attachment = frame.state().get('selection').first().toJSON();
			$input.val(attachment.url).trigger('change');
		});

		frame.open();
	});
})(jQuery);
