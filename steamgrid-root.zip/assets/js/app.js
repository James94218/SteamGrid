/**
 * SteamGrid 前端交互
 */
(function () {
	'use strict';

	var D = window.SG_DATA || {};
	var doc = document;
	var i18n = D.i18n || {};

	function $(selector, context) {
		return (context || doc).querySelector(selector);
	}

	function $$(selector, context) {
		return Array.prototype.slice.call((context || doc).querySelectorAll(selector));
	}

	function on(target, type, handler, options) {
		target.addEventListener(type, handler, options || false);
	}

	function copyText(text) {
		if (navigator.clipboard && navigator.clipboard.writeText) {
			return navigator.clipboard.writeText(text);
		}
		return new Promise(function (resolve, reject) {
			var area = doc.createElement('textarea');
			area.value = text;
			area.style.position = 'fixed';
			area.style.opacity = '0';
			doc.body.appendChild(area);
			area.select();
			try {
				doc.execCommand('copy');
				resolve();
			} catch (error) {
				reject(error);
			}
			doc.body.removeChild(area);
		});
	}

	function insertAtCursor(field, text) {
		if (!field) {
			return;
		}
		var start = typeof field.selectionStart === 'number' ? field.selectionStart : 0;
		var end = typeof field.selectionEnd === 'number' ? field.selectionEnd : 0;
		var value = field.value || '';
		field.value = value.slice(0, start) + text + value.slice(end);
		field.selectionStart = start + text.length;
		field.selectionEnd = start + text.length;
		field.focus();
	}

	function loadScript(src) {
		return new Promise(function (resolve, reject) {
			if (!src) {
				reject(new Error('no src'));
				return;
			}
			var script = doc.createElement('script');
			script.src = src;
			script.async = true;
			script.onload = resolve;
			script.onerror = reject;
			doc.head.appendChild(script);
		});
	}

	function escapeHtml(text) {
		var div = doc.createElement('div');
		div.textContent = text == null ? '' : String(text);
		return div.innerHTML;
	}

	/* ============================================================
	 * 主题切换
	 * ========================================================== */
	function systemLight() {
		return window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches;
	}

	function applyThemeMode(mode) {
		try {
			localStorage.setItem('sg-color-mode', mode);
		} catch (error) {
			/* ignore */
		}
		var theme = 'auto' === mode ? (systemLight() ? 'light' : 'dark') : mode;
		doc.documentElement.setAttribute('data-sg-theme', theme);
		doc.documentElement.setAttribute('data-sg-mode', mode);
	}

	function initTheme() {
		var pref = '';
		try {
			pref = localStorage.getItem('sg-color-mode') || '';
		} catch (error) {
			pref = '';
		}
		if (!pref) {
			pref = doc.documentElement.getAttribute('data-sg-mode') || 'auto';
		}
		if (pref === 'auto') {
			applyThemeMode('auto');
		}

		if (window.matchMedia) {
			var media = window.matchMedia('(prefers-color-scheme: light)');
			var listener = function () {
				var mode = doc.documentElement.getAttribute('data-sg-mode') || 'auto';
				if (mode === 'auto') {
					doc.documentElement.setAttribute('data-sg-theme', systemLight() ? 'light' : 'dark');
				}
			};
			if (media.addEventListener) {
				media.addEventListener('change', listener);
			}
		}
	}

	on(doc, 'click', function (event) {
		var button = event.target.closest('[data-sg-theme-toggle]');
		if (!button) {
			return;
		}
		var current = doc.documentElement.getAttribute('data-sg-theme');
		var next = current === 'light' ? 'dark' : 'light';
		applyThemeMode(next);
		button.setAttribute('aria-pressed', next === 'light' ? 'true' : 'false');
	});

	/* ============================================================
	 * 公告关闭
	 * ========================================================== */
	var ANNOUNCE_KEY = 'sg-announcement-closed';

	function initAnnouncement() {
		var bar = $('[data-sg-announcement]');
		if (!bar) {
			return;
		}
		try {
			if (localStorage.getItem(ANNOUNCE_KEY) === new Date().toDateString()) {
				bar.classList.add('is-hidden');
			}
		} catch (error) {
			/* ignore */
		}
	}

	on(doc, 'click', function (event) {
		if (!event.target.closest('[data-sg-announcement-close]')) {
			return;
		}
		var bar = $('[data-sg-announcement]');
		if (bar) {
			bar.classList.add('is-hidden');
		}
		try {
			localStorage.setItem(ANNOUNCE_KEY, new Date().toDateString());
		} catch (error) {
			/* ignore */
		}
	});

	/* ============================================================
	 * 侧边栏抽屉
	 * ========================================================== */
	function setSidebar(open) {
		var sidebar = $('[data-sg-sidebar]');
		var overlay = $('.sg-sidebar-overlay');
		if (!sidebar) {
			return;
		}
		sidebar.classList.toggle('is-open', open);
		if (overlay) {
			overlay.hidden = !open;
			overlay.classList.toggle('is-open', open);
		}
		doc.body.classList.toggle('sg-sidebar-open', open);
		doc.body.style.overflow = open ? 'hidden' : '';
	}

	on(doc, 'click', function (event) {
		if (event.target.closest('[data-sg-sidebar-open]')) {
			event.preventDefault();
			setSidebar(true);
			return;
		}
		if (event.target.closest('[data-sg-sidebar-close]') || event.target.classList.contains('sg-sidebar-overlay')) {
			setSidebar(false);
		}
	});

	/* 悬浮广告 */
	function initFloatAd() {
		var ad = $('.sg-ad-float');
		if (!ad) {
			return;
		}
		try {
			if (localStorage.getItem('sg-float-ad-closed') === new Date().toDateString()) {
				ad.remove();
			}
		} catch (error) {
			/* ignore */
		}
	}

	on(doc, 'click', function (event) {
		var close = event.target.closest('.sg-ad-close');
		if (!close) {
			return;
		}
		var ad = close.closest('.sg-ad-float');
		if (ad) {
			ad.remove();
		}
		try {
			localStorage.setItem('sg-float-ad-closed', new Date().toDateString());
		} catch (error) {
			/* ignore */
		}
	});

	/* 侧边栏自适应：内容高于视口时取消粘性，避免内部滚动条 */
	var sidebarObserver = null;

	function initSidebarFit() {
		var sidebar = $('[data-sg-sidebar]');
		if (!sidebar) {
			return;
		}
		var header = $('.sg-site-header');
		var headerHeight = header ? header.offsetHeight : 0;
		var available = window.innerHeight - headerHeight - 40;
		var isTall = sidebar.offsetHeight > available;
		sidebar.classList.toggle('sg-sidebar-tall', isTall && window.innerWidth > 1024);
	}

	function observeSidebar() {
		var sidebar = $('[data-sg-sidebar]');
		if (!sidebar) {
			return;
		}
		initSidebarFit();
		if ('ResizeObserver' in window) {
			if (sidebarObserver) {
				sidebarObserver.disconnect();
			}
			sidebarObserver = new ResizeObserver(function () {
				initSidebarFit();
			});
			sidebarObserver.observe(sidebar);
		}
	}

	var sidebarFitTimer = null;
	on(window, 'resize', function () {
		window.clearTimeout(sidebarFitTimer);
		sidebarFitTimer = window.setTimeout(initSidebarFit, 120);
	});
	on(window, 'load', initSidebarFit);

	/* 链接预取 */
	function initPrefetch() {
		if (!D.prefetch) {
			return;
		}
		on(doc, 'mouseover', function (event) {
			var link = event.target.closest('a[href]');
			if (!link || link.dataset.sgPrefetch) {
				return;
			}
			if (link.target && link.target !== '_self') {
				return;
			}
			var url;
			try {
				url = new URL(link.href, location.href);
			} catch (error) {
				return;
			}
			if (url.origin !== location.origin || url.pathname === location.pathname) {
				return;
			}
			if (/\/wp-(admin|login|json|cron|content)/.test(url.pathname)) {
				return;
			}
			if (/\.(zip|rar|7z|tar|gz|pdf|png|jpe?g|gif|webp|svg|ico|mp4|mp3|css|js|xml|txt|woff2?|ttf|otf)$/i.test(url.pathname)) {
				return;
			}
			link.dataset.sgPrefetch = '1';
			var hint = doc.createElement('link');
			hint.rel = 'prefetch';
			hint.href = url.href;
			doc.head.appendChild(hint);
		});
	}

	/* ============================================================
	 * 进度条 / 骨架屏
	 * ========================================================== */
	function progressBar() {
		var bar = $('.sg-progress');
		if (!bar) {
			bar = doc.createElement('div');
			bar.className = 'sg-progress';
			doc.body.appendChild(bar);
		}
		return bar;
	}

	function progressStart() {
		if (!D.skeleton) {
			return;
		}
		var bar = progressBar();
		bar.classList.add('is-active');
		bar.style.width = '12%';
		window.requestAnimationFrame(function () {
			bar.style.width = '72%';
		});
		doc.documentElement.classList.add('sg-pjax-loading');
	}

	function progressDone() {
		var bar = $('.sg-progress');
		doc.documentElement.classList.remove('sg-pjax-loading');
		if (!bar) {
			return;
		}
		bar.style.width = '100%';
		window.setTimeout(function () {
			bar.classList.remove('is-active');
			bar.style.width = '0';
		}, 260);
	}

	/* ============================================================
	 * 目录：多级展开 + 高亮
	 * ========================================================== */
	function initToc() {
		var toc = $('.sg-toc');
		if (!toc) {
			return;
		}

		$$('.sg-toc-item', toc).forEach(function (item) {
			if (!item.querySelector('.sg-toc-list') || item.querySelector('.sg-toc-arrow')) {
				return;
			}
			var arrow = doc.createElement('button');
			arrow.type = 'button';
			arrow.className = 'sg-toc-arrow';
			arrow.setAttribute('aria-label', '展开或收起');
			on(arrow, 'click', function (event) {
				event.preventDefault();
				item.classList.toggle('is-collapsed');
			});
			item.insertBefore(arrow, item.firstChild);
		});

		var toggle = $('.sg-toc-toggle', toc);
		if (toggle) {
			on(toggle, 'click', function () {
				var collapsed = toc.classList.toggle('is-collapsed');
				toggle.textContent = collapsed ? '展开' : '收起';
				toggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
			});
		}

		var links = {};
		$$('a[href^="#"]', toc).forEach(function (link) {
			links[decodeURIComponent(link.getAttribute('href').slice(1))] = link;
		});

		if (!('IntersectionObserver' in window)) {
			return;
		}

		if (window.__sgTocObserver) {
			window.__sgTocObserver.disconnect();
		}

		var observer = new IntersectionObserver(
			function (entries) {
				entries.forEach(function (entry) {
					if (!entry.isIntersecting) {
						return;
					}
					Object.keys(links).forEach(function (id) {
						links[id].classList.remove('is-active');
					});
					if (links[entry.target.id]) {
						links[entry.target.id].classList.add('is-active');
					}
				});
			},
			{ rootMargin: '-90px 0px -72% 0px' }
		);

		Object.keys(links).forEach(function (id) {
			var heading = doc.getElementById(id);
			if (heading) {
				observer.observe(heading);
			}
		});
		window.__sgTocObserver = observer;
	}

	/* ============================================================
	 * 代码块（仿 Mac + 拷贝）
	 * ========================================================== */
	function initCodeBlocks() {
		if (!D.codeCopy) {
			return;
		}
		$$('.sg-article-content pre').forEach(function (pre) {
			if (pre.closest('.sg-code-block')) {
				return;
			}
			var language = 'code';
			var code = pre.querySelector('code');
			if (code && code.className) {
				var match = code.className.match(/language-([\w-]+)/);
				if (match) {
					language = match[1];
				}
			}

			var wrap = doc.createElement('div');
			wrap.className = 'sg-code-block';

			var head = doc.createElement('div');
			head.className = 'sg-code-head';
			head.innerHTML =
				'<span class="sg-code-dot red"></span><span class="sg-code-dot yellow"></span><span class="sg-code-dot green"></span>' +
				'<span class="sg-code-lang"></span>';
			head.querySelector('.sg-code-lang').textContent = language;

			var button = doc.createElement('button');
			button.type = 'button';
			button.className = 'sg-code-copy';
			button.textContent = '复制代码';
			head.appendChild(button);

			var parent = pre.parentNode;
			if (!parent) {
				return;
			}
			parent.insertBefore(wrap, pre);
			wrap.appendChild(head);
			wrap.appendChild(pre);

			on(button, 'click', function () {
				copyText(pre.innerText)
					.then(function () {
						button.textContent = i18n.copied || '已复制';
						window.setTimeout(function () {
							button.textContent = '复制代码';
						}, 1600);
					})
					.catch(function () {
						button.textContent = i18n.copyFailed || '复制失败';
					});
			});
		});
	}

	/* ============================================================
	 * DPlayer
	 * ========================================================== */
	function initDPlayer() {
		if (typeof window.DPlayer === 'undefined') {
			return;
		}
		$$('.sg-dplayer').forEach(function (box) {
			if (box.dataset.sgInit) {
				return;
			}
			box.dataset.sgInit = '1';
			try {
				new window.DPlayer({
					container: box,
					video: {
						url: box.dataset.src,
						pic: box.dataset.poster || '',
						type: box.dataset.type || 'auto'
					},
					autoplay: false
				});
			} catch (error) {
				/* ignore */
			}
		});
	}

	/* ============================================================
	 * Twemoji
	 * ========================================================== */
	function initTwemoji() {
		if (!D.twemoji || typeof window.twemoji === 'undefined') {
			return;
		}
		try {
			window.twemoji.parse(doc.body, { folder: 'svg', ext: '.svg' });
		} catch (error) {
			/* ignore */
		}
	}

	/* ============================================================
	 * 点赞
	 * ========================================================== */
	function markLikedButtons() {
		$$('[data-sg-like]').forEach(function (button) {
			var postId = button.getAttribute('data-post-id');
			try {
				if (localStorage.getItem('sg-liked-' + postId)) {
					button.classList.add('is-liked');
				}
			} catch (error) {
				/* ignore */
			}
		});
	}

	on(doc, 'click', function (event) {
		var button = event.target.closest('[data-sg-like]');
		if (!button || button.classList.contains('is-liked')) {
			return;
		}
		var postId = button.getAttribute('data-post-id');
		if (!postId) {
			return;
		}
		button.disabled = true;

		fetch(D.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: 'action=sg_like&nonce=' + encodeURIComponent(D.nonce) + '&post_id=' + encodeURIComponent(postId)
		})
			.then(function (response) {
				return response.json();
			})
			.then(function (json) {
				if (!json.success) {
					throw new Error((json.data && json.data.message) || 'error');
				}
				button.classList.add('is-liked');
				var counter = button.querySelector('[data-sg-like-count]');
				if (counter) {
					counter.textContent = json.data.likes;
				}
				try {
					localStorage.setItem('sg-liked-' + postId, '1');
				} catch (error) {
					/* ignore */
				}
			})
			.catch(function () {
				button.classList.add('is-liked');
			})
			.then(function () {
				button.disabled = false;
			});
	});

	/* ============================================================
	 * 弹窗 / 分享 / 海报
	 * ========================================================== */
	function openModal(id) {
		var modal = doc.getElementById(id);
		if (!modal) {
			return;
		}
		modal.hidden = false;
		doc.body.style.overflow = 'hidden';
		if (id === 'sg-poster-modal') {
			generatePoster();
		}
	}

	function closeModals() {
		$$('[data-sg-modal]').forEach(function (modal) {
			modal.hidden = true;
		});
		doc.body.style.overflow = '';
	}

	on(doc, 'click', function (event) {
		var opener = event.target.closest('[data-sg-modal-open]');
		if (opener) {
			event.preventDefault();
			openModal(opener.getAttribute('data-sg-modal-open'));
			return;
		}
		if (event.target.closest('[data-sg-modal-close]') || event.target.classList.contains('sg-modal')) {
			closeModals();
		}
	});

	on(doc, 'keydown', function (event) {
		if (event.key === 'Escape') {
			closeModals();
		}
	});

	on(doc, 'click', function (event) {
		var button = event.target.closest('[data-sg-share]');
		if (!button) {
			return;
		}
		var kind = button.getAttribute('data-sg-share');
		var url = location.href;
		var title = doc.title;

		if (kind === 'copy') {
			copyText(url)
				.then(function () {
					button.textContent = i18n.shareCopied || '链接已复制';
				})
				.catch(function () {});
			return;
		}

		var shareUrl = '';
		if (kind === 'weibo') {
			shareUrl = 'https://service.weibo.com/share/share.php?url=' + encodeURIComponent(url) + '&title=' + encodeURIComponent(title);
		} else if (kind === 'qq') {
			shareUrl = 'https://connect.qq.com/widget/shareqq/index.html?url=' + encodeURIComponent(url) + '&title=' + encodeURIComponent(title);
		} else if (kind === 'twitter') {
			shareUrl = 'https://twitter.com/intent/tweet?url=' + encodeURIComponent(url) + '&text=' + encodeURIComponent(title);
		} else if (kind === 'native' && navigator.share) {
			navigator.share({ title: title, url: url }).catch(function () {});
			return;
		}

		if (shareUrl) {
			window.open(shareUrl, '_blank', 'noopener,noreferrer');
		}
	});

	function wrapCanvasText(ctx, text, x, y, maxWidth, lineHeight, maxLines) {
		var chars = String(text || '').split('');
		var line = '';
		var lines = [];
		for (var i = 0; i < chars.length; i++) {
			var test = line + chars[i];
			if (ctx.measureText(test).width > maxWidth && line) {
				lines.push(line);
				line = chars[i];
				if (lines.length >= maxLines - 1) {
					break;
				}
			} else {
				line = test;
			}
		}
		if (line) {
			lines.push(line);
		}
		lines.forEach(function (item, index) {
			ctx.fillText(item, x, y + index * lineHeight);
		});
		return lines.length;
	}

	function generatePoster() {
		var canvas = doc.getElementById('sg-poster-canvas');
		if (!canvas || !canvas.getContext) {
			return;
		}
		var ctx = canvas.getContext('2d');
		var W = canvas.width;
		var H = canvas.height;

		var gradient = ctx.createLinearGradient(0, 0, W, H);
		gradient.addColorStop(0, '#1b2838');
		gradient.addColorStop(0.55, '#223a4f');
		gradient.addColorStop(1, '#0f1a26');
		ctx.fillStyle = gradient;
		ctx.fillRect(0, 0, W, H);

		ctx.save();
		ctx.globalAlpha = 0.12;
		ctx.fillStyle = '#66c0f4';
		ctx.beginPath();
		ctx.arc(W * 0.82, H * 0.16, 200, 0, Math.PI * 2);
		ctx.fill();
		ctx.globalAlpha = 0.08;
		ctx.beginPath();
		ctx.arc(W * 0.15, H * 0.85, 240, 0, Math.PI * 2);
		ctx.fill();
		ctx.restore();

		ctx.fillStyle = '#66c0f4';
		ctx.font = '600 28px "Segoe UI", "Microsoft YaHei", sans-serif';
		ctx.fillText(D.siteName || 'SteamGrid', 48, 86);

		ctx.strokeStyle = 'rgba(102,192,244,0.4)';
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.moveTo(48, 112);
		ctx.lineTo(W - 48, 112);
		ctx.stroke();

		var titleEl = doc.querySelector('.sg-article-title');
		var title = titleEl ? titleEl.textContent.trim() : doc.title;
		ctx.fillStyle = '#ffffff';
		ctx.font = '700 42px "Segoe UI", "Microsoft YaHei", sans-serif';
		wrapCanvasText(ctx, title, 48, 190, W - 96, 56, 3);

		var excerpt = '';
		var firstP = doc.querySelector('.sg-article-content p');
		if (firstP) {
			excerpt = firstP.textContent;
		}
		if (!excerpt) {
			excerpt = D.postExcerpt || '';
		}
		ctx.fillStyle = '#aebfcd';
		ctx.font = '400 23px "Segoe UI", "Microsoft YaHei", sans-serif';
		wrapCanvasText(ctx, excerpt, 48, 380, W - 96, 36, 4);

		var dateEl = doc.querySelector('.sg-article-date');
		var authorEl = doc.querySelector('.sg-article-author');
		ctx.fillStyle = '#8f98a0';
		ctx.font = '400 20px "Segoe UI", "Microsoft YaHei", sans-serif';
		ctx.fillText((authorEl ? authorEl.textContent : '') + '  ·  ' + (dateEl ? dateEl.textContent : ''), 48, H - 86);

		var download = doc.getElementById('sg-poster-download');

		var finish = function (qrImage) {
			if (qrImage) {
				ctx.fillStyle = '#ffffff';
				ctx.fillRect(W - 200, H - 240, 152, 152);
				ctx.drawImage(qrImage, W - 192, H - 232, 136, 136);
				ctx.fillStyle = '#aebfcd';
				ctx.font = '400 16px "Segoe UI", "Microsoft YaHei", sans-serif';
				ctx.textAlign = 'center';
				ctx.fillText('扫码阅读', W - 124, H - 60);
				ctx.textAlign = 'left';
			}
			if (download) {
				download.href = canvas.toDataURL('image/png');
			}
		};

		if (!D.posterQr || !D.posterQrCdn) {
			finish(null);
			return;
		}

		if (window.QRCode && window.QRCode.toDataURL) {
			window.QRCode.toDataURL(location.href, { width: 272, margin: 1 })
				.then(function (url) {
					var image = new Image();
					image.onload = function () {
						finish(image);
					};
					image.onerror = function () {
						finish(null);
					};
					image.src = url;
				})
				.catch(function () {
					finish(null);
				});
			return;
		}

		loadScript(D.posterQrCdn)
			.then(function () {
				generatePoster();
			})
			.catch(function () {
				finish(null);
			});
	}

	/* 表情选择 */
	on(doc, 'click', function (event) {
		var toggle = event.target.closest('[data-sg-emoji-toggle]');
		if (toggle) {
			event.preventDefault();
			var tools = toggle.closest('.sg-comment-tools');
			var panel = tools ? tools.querySelector('[data-sg-emoji-panel]') : null;
			if (!panel) {
				return;
			}
			var willOpen = panel.hidden;
			panel.hidden = !willOpen;
			toggle.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
			return;
		}

		var item = event.target.closest('[data-sg-emoji]');
		if (item) {
			event.preventDefault();
			var form = item.closest('form');
			var textarea = form ? form.querySelector('textarea[name="comment"]') : null;
			insertAtCursor(textarea, item.getAttribute('data-sg-emoji') || item.textContent);
			var panel = item.closest('[data-sg-emoji-panel]');
			if (panel) {
				panel.hidden = true;
			}
			var toggle = form ? form.querySelector('[data-sg-emoji-toggle]') : null;
			if (toggle) {
				toggle.setAttribute('aria-expanded', 'false');
			}
			return;
		}

		if (!event.target.closest('.sg-comment-tools')) {
			$$('[data-sg-emoji-panel]').forEach(function (panel) {
				panel.hidden = true;
			});
		}
	});

	/* ============================================================
	 * 验证码刷新 / 极验
	 * ========================================================== */
	on(doc, 'click', function (event) {
		var button = event.target.closest('[data-sg-captcha-refresh]');
		if (!button) {
			return;
		}
		event.preventDefault();
		var wrap = button.closest('.sg-captcha');
		if (!wrap) {
			return;
		}
		fetch(D.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: 'action=sg_captcha_refresh'
		})
			.then(function (response) {
				return response.json();
			})
			.then(function (json) {
				if (!json.success) {
					return;
				}
				var image = wrap.querySelector('.sg-captcha-img');
				var token = wrap.querySelector('input[name="sg_captcha_token"]');
				if (image) {
					image.src = json.data.img;
				}
				if (token) {
					token.value = json.data.token;
				}
			})
			.catch(function () {});
	});

	function initGeetest() {
		if (D.captchaMode !== 'geetest' || !D.geetestKeySet || typeof window.initGeetest4 !== 'function') {
			return;
		}
		$$('[data-sg-geetest]').forEach(function (box) {
			if (box.dataset.sgGtInit) {
				return;
			}
			box.dataset.sgGtInit = '1';
			try {
				window.initGeetest4({ captchaId: D.geetestId, product: 'float' }, function (captcha) {
					captcha.onSuccess(function () {
						var result = captcha.getValidate() || {};
						var fields = {
							sg_geetest_lot: result.lot_number,
							sg_geetest_output: result.captcha_output,
							sg_geetest_pass: result.pass_token,
							sg_geetest_gen: result.gen_time
						};
						Object.keys(fields).forEach(function (name) {
							var input = box.querySelector('input[name="' + name + '"]');
							if (input) {
								input.value = fields[name] || '';
							}
						});
					});
				});
			} catch (error) {
				/* ignore */
			}
		});
	}

	/* ============================================================
	 * 加载更多
	 * ========================================================== */
	on(doc, 'click', function (event) {
		var button = event.target.closest('[data-sg-load-more]');
		if (!button || button.classList.contains('is-loading')) {
			return;
		}
		var grid = $('[data-sg-post-grid]');
		if (!grid) {
			return;
		}
		var paged = parseInt(button.getAttribute('data-paged'), 10) || 2;
		button.classList.add('is-loading');
		button.textContent = i18n.loading || '加载中…';

		var body = new URLSearchParams({
			action: 'sg_load_more',
			nonce: D.nonce,
			paged: paged,
			per_page: button.getAttribute('data-per-page') || '',
			exclude: button.getAttribute('data-exclude') || ''
		});

		if (D.skeleton) {
			for (var i = 0; i < 2; i++) {
				var skeleton = doc.createElement('div');
				skeleton.className = 'sg-skeleton-card';
				grid.appendChild(skeleton);
			}
		}

		fetch(D.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		})
			.then(function (response) {
				return response.json();
			})
			.then(function (json) {
				$$('.sg-skeleton-card', grid).forEach(function (node) {
					node.remove();
				});
				if (!json.success) {
					throw new Error();
				}
				if (json.data.html) {
					grid.insertAdjacentHTML('beforeend', json.data.html);
				}
				if (json.data.hasMore) {
					button.setAttribute('data-paged', json.data.next);
					button.textContent = i18n.loadMore || '加载更多';
					button.classList.remove('is-loading');
				} else {
					button.remove();
				}
			})
			.catch(function () {
				$$('.sg-skeleton-card', grid).forEach(function (node) {
					node.remove();
				});
				button.classList.remove('is-loading');
				button.textContent = i18n.loadMore || '加载更多';
			});
	});

	/* ============================================================
	 * 评论：AJAX 提交与刷新
	 * ========================================================== */
	function showCommentFeedback(text, isError) {
		var toast = doc.createElement('div');
		toast.className = 'sg-toast' + (isError ? ' is-error' : '');
		toast.textContent = text;
		doc.body.appendChild(toast);
		window.setTimeout(function () {
			toast.classList.add('is-out');
			window.setTimeout(function () {
				toast.remove();
			}, 320);
		}, 3200);
	}

	function refreshComments(url) {
		var target = $('[data-sg-comments]');
		if (!target) {
			return;
		}
		target.classList.add('is-loading');
		fetch(url || location.href, { credentials: 'same-origin' })
			.then(function (response) {
				return response.text();
			})
			.then(function (html) {
				var parsed = new DOMParser().parseFromString(html, 'text/html');
				var fresh = parsed.querySelector('[data-sg-comments]');
				if (fresh) {
					target.innerHTML = fresh.innerHTML;
				}
				target.classList.remove('is-loading');
				initGeetest();
			})
			.catch(function () {
				target.classList.remove('is-loading');
			});
	}

	on(doc, 'submit', function (event) {
		var form = event.target;
		if (!form.classList || !form.classList.contains('sg-comment-form') || !D.commentsAjax) {
			return;
		}
		event.preventDefault();

		var commentField = form.querySelector('textarea[name="comment"]');
		if (!commentField || !commentField.value.trim()) {
			showCommentFeedback(i18n.commentEmpty || '评论内容不能为空', true);
			return;
		}

		var submit = form.querySelector('.submit, button[type="submit"], input[type="submit"]');
		if (submit) {
			submit.disabled = true;
		}

		var data = new FormData(form);
		data.append('action', 'sg_comment');
		data.append('nonce', D.nonce);

		fetch(D.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: data
		})
			.then(function (response) {
				return response.json();
			})
			.then(function (json) {
				if (!json.success) {
					throw new Error((json.data && json.data.message) || i18n.commentError);
				}
				showCommentFeedback(json.data.message || i18n.commentPosted, false);
				form.reset();
				refreshComments();
			})
			.catch(function (error) {
				showCommentFeedback(error.message || i18n.commentError, true);
			})
			.then(function () {
				if (submit) {
					submit.disabled = false;
				}
			});
	});

	on(doc, 'click', function (event) {
		var link = event.target.closest('[data-sg-comments] a.page-numbers, [data-sg-comments] a.comment-page-numbers');
		if (!link || !D.commentsAjax) {
			return;
		}
		event.preventDefault();
		refreshComments(link.href);
		var comments = $('[data-sg-comments]');
		if (comments) {
			comments.scrollIntoView({ behavior: 'smooth', block: 'start' });
		}
	});

	/* ============================================================
	 * 首页幻灯片
	 * ========================================================== */
	var carouselTimer = null;

	function stopCarousel() {
		if (carouselTimer) {
			window.clearInterval(carouselTimer);
			carouselTimer = null;
		}
	}

	function initCarousel() {
		stopCarousel();

		var root = $('[data-sg-carousel]');
		if (!root) {
			return;
		}

		var slides = $$('.sg-slide', root);
		if (!slides.length) {
			return;
		}

		var dots = $$('[data-sg-carousel-dot]', root);
		var progress = $('[data-sg-carousel-progress]', root);
		var speed = Math.max(2, parseInt(root.getAttribute('data-speed'), 10) || 6) * 1000;
		var autoplay = root.getAttribute('data-autoplay') === '1';
		var wheel = root.getAttribute('data-wheel') === '1';
		var pause = root.getAttribute('data-pause') === '1';
		var index = 0;

		for (var i = 0; i < slides.length; i++) {
			if (slides[i].classList.contains('is-active')) {
				index = i;
				break;
			}
		}

		root.style.setProperty('--sg-carousel-speed', speed + 'ms');

		function show(next) {
			index = (next + slides.length) % slides.length;

			slides.forEach(function (slide, slideIndex) {
				var active = slideIndex === index;
				slide.classList.toggle('is-active', active);
				slide.classList.toggle('is-before', slideIndex < index);
				slide.setAttribute('aria-hidden', active ? 'false' : 'true');
			});

			dots.forEach(function (dot, dotIndex) {
				dot.classList.toggle('is-active', dotIndex === index);
			});

			if (progress) {
				progress.classList.remove('is-running');
				void progress.offsetWidth;
				if (autoplay) {
					progress.classList.add('is-running');
				}
			}
		}

		function start() {
			if (!autoplay || slides.length < 2) {
				return;
			}
			stopCarousel();
			carouselTimer = window.setInterval(function () {
				show(index + 1);
			}, speed);
			if (progress) {
				progress.classList.remove('is-running');
				void progress.offsetWidth;
				progress.classList.add('is-running');
			}
		}

		function restart() {
			stopCarousel();
			start();
		}

		show(index);
		start();

		var prev = $('[data-sg-carousel-prev]', root);
		var next = $('[data-sg-carousel-next]', root);

		if (prev) {
			on(prev, 'click', function () {
				show(index - 1);
				restart();
			});
		}
		if (next) {
			on(next, 'click', function () {
				show(index + 1);
				restart();
			});
		}

		dots.forEach(function (dot) {
			on(dot, 'click', function () {
				var target = parseInt(dot.getAttribute('data-sg-carousel-dot'), 10);
				if (!isNaN(target)) {
					show(target);
					restart();
				}
			});
		});

		if (pause) {
			on(root, 'mouseenter', stopCarousel);
			on(root, 'mouseleave', start);
		}

		if (wheel) {
			on(
				root,
				'wheel',
				function (event) {
					if (Math.abs(event.deltaY) < 10) {
						return;
					}
					event.preventDefault();
					if (root._sgWheelLock) {
						return;
					}
					root._sgWheelLock = true;
					window.setTimeout(function () {
						root._sgWheelLock = false;
					}, 650);
					show(index + (event.deltaY > 0 ? 1 : -1));
					restart();
				},
				{ passive: false }
			);
		}

		var touchX = null;
		on(
			root,
			'touchstart',
			function (event) {
				if (event.touches.length === 1) {
					touchX = event.touches[0].clientX;
				}
			},
			{ passive: true }
		);
		on(
			root,
			'touchend',
			function (event) {
				if (null === touchX || !event.changedTouches.length) {
					return;
				}
				var dx = event.changedTouches[0].clientX - touchX;
				touchX = null;
				if (Math.abs(dx) < 40) {
					return;
				}
				show(index + (dx < 0 ? 1 : -1));
				restart();
			},
			{ passive: true }
		);

		on(root, 'keydown', function (event) {
			if (event.key === 'ArrowLeft') {
				event.preventDefault();
				show(index - 1);
				restart();
			}
			if (event.key === 'ArrowRight') {
				event.preventDefault();
				show(index + 1);
				restart();
			}
		});
	}

	/* ============================================================
	 * PJAX 无刷新加载
	 * ========================================================== */
	function shouldPjax(link) {
		if (!D.pjax || !link) {
			return false;
		}
		if (link.target && link.target !== '_self') {
			return false;
		}
		if (link.hasAttribute('download') || link.hasAttribute('data-no-pjax')) {
			return false;
		}
		if (link.closest('[data-sg-comments], .sg-modal, .sg-toc, .sg-admin-page, #wpadminbar')) {
			return false;
		}
		var href = link.getAttribute('href');
		if (!href || href.charAt(0) === '#') {
			return false;
		}
		var url;
		try {
			url = new URL(link.href, location.href);
		} catch (error) {
			return false;
		}
		if (url.origin !== location.origin) {
			return false;
		}
		if (url.pathname === location.pathname && url.search === location.search) {
			return false;
		}
		if (/\/wp-(admin|login|json|cron|content)/.test(url.pathname)) {
			return false;
		}
		if (/\.(zip|rar|7z|tar|gz|pdf|png|jpe?g|gif|webp|svg|ico|mp4|mp3|css|js|xml|txt|woff2?|ttf|otf)$/i.test(url.pathname)) {
			return false;
		}
		return true;
	}

	function replaceModals(parsed) {
		$$('.sg-modal').forEach(function (modal) {
			if (!modal.closest('.sg-main')) {
				modal.remove();
			}
		});
		$$('.sg-modal', parsed).forEach(function (modal) {
			doc.body.appendChild(modal);
		});
	}

	function afterSwap(parsed, url) {
		replaceModals(parsed);
		setSidebar(false);
		initToc();
		initCodeBlocks();
		initDPlayer();
		initGeetest();
		initTwemoji();
		markLikedButtons();
		observeSidebar();
		initCarousel();

		if (url && url.hash) {
			var target = doc.getElementById(decodeURIComponent(url.hash.slice(1)));
			if (target) {
				target.scrollIntoView({ behavior: 'smooth', block: 'start' });
			}
		}
	}

	function loadPage(url, push) {
		progressStart();
		fetch(url, {
			credentials: 'same-origin',
			headers: { 'X-SG-Pjax': '1' }
		})
			.then(function (response) {
				if (!response.ok) {
					throw new Error('HTTP ' + response.status);
				}
				return response.text();
			})
			.then(function (html) {
				var parsed = new DOMParser().parseFromString(html, 'text/html');
				var newMain = parsed.querySelector('.sg-main');
				var oldMain = $('.sg-main');
				if (!newMain || !oldMain) {
					throw new Error('no main');
				}
				stopCarousel();
				oldMain.innerHTML = newMain.innerHTML;
				doc.body.className = parsed.body.className;
				if (parsed.title) {
					doc.title = parsed.title;
				}
				var targetUrl = new URL(url, location.href);
				if (push) {
					try {
						history.pushState({ sg: 1 }, '', targetUrl.href);
					} catch (error) {
						/* ignore */
					}
				}
				window.scrollTo({ top: 0, behavior: 'auto' });
				afterSwap(parsed, targetUrl);
				progressDone();
			})
			.catch(function () {
				location.href = url;
			});
	}

	on(doc, 'click', function (event) {
		if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
			return;
		}
		var link = event.target.closest('a[href]');
		if (!shouldPjax(link)) {
			return;
		}
		event.preventDefault();
		loadPage(link.href, true);
	});

	on(window, 'popstate', function () {
		if (D.pjax) {
			loadPage(location.href, false);
		}
	});

	/* ============================================================
	 * 初始化
	 * ========================================================== */
	function init() {
		initTheme();
		initAnnouncement();
		initFloatAd();
		initToc();
		initCodeBlocks();
		initDPlayer();
		initGeetest();
		initTwemoji();
		markLikedButtons();
		initPrefetch();
		observeSidebar();
		initCarousel();
	}

	if (doc.readyState === 'loading') {
		doc.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}

	on(window, 'load', function () {
		initTwemoji();
		initDPlayer();
	});
})();
