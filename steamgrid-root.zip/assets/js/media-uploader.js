/**
 * SteamGrid 后台：从媒体库选择卡片图片
 */
(function ($) {
	'use strict';

	var frame;

	$(document).on('click', '.sg-media-select', function (event) {
		event.preventDefault();

		var $input = $(this).closest('.postbox').find('input.sg-card-image-url');

		if (frame) {
			frame.open();
			return;
		}

		frame = wp.media({
			title: '选择卡片图片',
			button: { text: '使用这张图片' },
			multiple: false
		});

		frame.on('select', function () {
			var attachment = frame.state().get('selection').first().toJSON();
			$input.val(attachment.url).trigger('change');
		});

		frame.open();
	});

	$(document).on('click', '.sg-media-clear', function (event) {
		event.preventDefault();
		$(this).closest('.postbox').find('input.sg-card-image-url').val('').trigger('change');
	});
})(jQuery);
