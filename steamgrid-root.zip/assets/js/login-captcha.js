/**
 * 登录页验证码（SVG 刷新 / 极验）
 */
(function () {
	'use strict';

	var D = window.SG_LOGIN_CAPTCHA || {};
	var doc = document;

	doc.addEventListener('click', function (event) {
		var button = event.target.closest('[data-sg-captcha-refresh]');
		if (!button) {
			return;
		}
		event.preventDefault();
		var wrap = button.closest('.sg-captcha');
		if (!wrap) {
			return;
		}
		var body = 'action=sg_captcha_refresh';
		fetch(D.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body
		})
			.then(function (response) {
				return response.json();
			})
			.then(function (json) {
				if (!json.success) {
					return;
				}
				var image = wrap.querySelector('.sg-captcha-img');
				var token = wrap.querySelector('input[name="sg_captcha_token"]');
				if (image) {
					image.src = json.data.img;
				}
				if (token) {
					token.value = json.data.token;
				}
			})
			.catch(function () {});
	});

	function initGeetest() {
		if (D.mode !== 'geetest' || !D.keySet || typeof window.initGeetest4 !== 'function') {
			return;
		}
		var boxes = Array.prototype.slice.call(doc.querySelectorAll('[data-sg-geetest]'));
		boxes.forEach(function (box) {
			if (box.dataset.sgGtInit) {
				return;
			}
			box.dataset.sgGtInit = '1';
			try {
				window.initGeetest4({ captchaId: D.id, product: 'float' }, function (captcha) {
					captcha.onSuccess(function () {
						var result = captcha.getValidate() || {};
						var map = {
							sg_geetest_lot: result.lot_number,
							sg_geetest_output: result.captcha_output,
							sg_geetest_pass: result.pass_token,
							sg_geetest_gen: result.gen_time
						};
						Object.keys(map).forEach(function (name) {
							var input = box.querySelector('input[name="' + name + '"]');
							if (input) {
								input.value = map[name] || '';
							}
						});
					});
				});
			} catch (error) {
				/* ignore */
			}
		});
	}

	if (doc.readyState === 'loading') {
		doc.addEventListener('DOMContentLoaded', initGeetest);
	} else {
		initGeetest();
	}
})();
