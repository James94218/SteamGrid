<?php
/**
 * 搜索结果模板
 *
 * @package SteamGrid
 */

get_header();
?>

<div class="sg-container sg-page">
	<div class="sg-main-grid">

		<div class="sg-content-area">
			<header class="sg-page-head">
				<h1 class="sg-page-title">
					<?php
					printf(
						/* translators: %s: 搜索关键词 */
						esc_html__( '搜索：%s', 'steamgrid' ),
						'<span>' . esc_html( get_search_query() ) . '</span>'
					);
					?>
				</h1>
				<p class="sg-page-desc">
					<?php
					printf(
						/* translators: %d: 结果数量 */
						esc_html__( '共找到 %d 条结果', 'steamgrid' ),
						(int) $wp_query->found_posts
					);
					?>
				</p>
			</header>

			<?php if ( have_posts() ) : ?>
				<div class="sg-grid">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/content', 'card' );
					endwhile;
					?>
				</div>
				<?php sg_pagination(); ?>
			<?php else : ?>
				<?php get_template_part( 'template-parts/content', 'none' ); ?>
			<?php endif; ?>
		</div>

		<?php get_sidebar(); ?>
	</div>
</div>

<?php
get_footer();
