<?php
/**
 * 独立页面模板
 *
 * @package SteamGrid
 */

get_header();
?>

<div class="sg-container sg-page">
	<div class="sg-main-grid">

		<div class="sg-content-area">
			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<article id="post-<?php the_ID(); ?>" <?php post_class( 'sg-article' ); ?>>
					<header class="sg-article-head">
						<h1 class="sg-article-title"><?php the_title(); ?></h1>
					</header>

					<?php if ( has_post_thumbnail() ) : ?>
						<figure class="sg-article-thumb">
							<?php the_post_thumbnail( 'large' ); ?>
						</figure>
					<?php endif; ?>

					<div class="sg-article-content">
						<?php
						the_content();

						wp_link_pages(
							array(
								'before' => '<div class="sg-page-links">' . esc_html__( '分页：', 'steamgrid' ),
								'after'  => '</div>',
							)
						);
						?>
					</div>

					<?php if ( get_edit_post_link() ) : ?>
						<footer class="sg-article-foot">
							<?php
							edit_post_link(
								__( '编辑页面', 'steamgrid' ),
								'<span class="sg-edit-link">',
								'</span>'
							);
							?>
						</footer>
					<?php endif; ?>
				</article>

				<?php
				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
			endwhile;
			?>
		</div>

		<?php get_sidebar(); ?>
	</div>
</div>

<?php
get_footer();
