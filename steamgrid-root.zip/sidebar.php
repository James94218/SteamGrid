<?php
/**
 * 侧边栏
 *
 * @package SteamGrid
 */

if ( ! sg_has_sidebar() ) {
	return;
}
?>
<aside id="secondary" class="sg-sidebar<?php echo sg_on( 'sidebar_sticky' ) ? ' sg-sidebar-sticky' : ''; ?>" data-sg-sidebar>
	<div class="sg-sidebar-head">
		<span class="sg-sidebar-head-title"><?php esc_html_e( '侧边栏', 'steamgrid' ); ?></span>
		<button type="button" class="sg-sidebar-close" data-sg-sidebar-close aria-label="<?php esc_attr_e( '关闭侧边栏', 'steamgrid' ); ?>">
			<?php echo sg_svg_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</button>
	</div>

	<?php sg_ad( 'sidebar_top' ); ?>

	<?php
	$sg_card_configured = (bool) ( sg_get( 'card_avatar' ) || sg_get( 'card_name' ) || sg_get( 'card_bio' ) || sg_get( 'card_html' ) );
	$sg_profile_widget  = is_active_widget( false, false, 'sg_profile', true );

	// 已配置站点名片且没有单独添加名片小工具时，自动显示在侧边栏顶部。
	if ( $sg_card_configured && ! $sg_profile_widget && is_active_sidebar( 'sidebar-1' ) ) :
		?>
		<section class="sg-widget sg-widget-profile-fallback">
			<h3 class="sg-widget-title"><?php esc_html_e( '关于本站', 'steamgrid' ); ?></h3>
			<?php echo sg_site_card_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</section>
	<?php endif; ?>

	<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
	<?php else : ?>
		<section class="sg-widget sg-widget-profile-fallback">
			<h3 class="sg-widget-title"><?php esc_html_e( '关于本站', 'steamgrid' ); ?></h3>
			<?php echo sg_site_card_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</section>

		<?php
		$sg_sidebar_hot = new WP_Query(
			array(
				'posts_per_page'      => 5,
				'ignore_sticky_posts' => true,
			)
		);
		if ( $sg_sidebar_hot->have_posts() ) :
			?>
			<section class="sg-widget">
				<h3 class="sg-widget-title"><?php esc_html_e( '最新文章', 'steamgrid' ); ?></h3>
				<ul class="sg-widget-hot">
					<?php
					$sg_sidebar_index = 0;
					while ( $sg_sidebar_hot->have_posts() ) :
						$sg_sidebar_hot->the_post();
						$sg_sidebar_index++;
						?>
						<li>
							<span class="sg-hot-index<?php echo $sg_sidebar_index <= 3 ? ' is-top' : ''; ?>"><?php echo esc_html( $sg_sidebar_index ); ?></span>
							<a class="sg-hot-title" href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html( get_the_title() ); ?></a>
						</li>
					<?php endwhile; ?>
				</ul>
			</section>
			<?php
			wp_reset_postdata();
		endif;
		?>

		<?php
		$sg_sidebar_tags = get_tags(
			array(
				'orderby'    => 'count',
				'order'      => 'DESC',
				'number'     => 18,
				'hide_empty' => true,
			)
		);
		if ( $sg_sidebar_tags ) :
			?>
			<section class="sg-widget">
				<h3 class="sg-widget-title"><?php esc_html_e( '热门标签', 'steamgrid' ); ?></h3>
				<div class="tagcloud">
					<?php foreach ( $sg_sidebar_tags as $sg_tag ) : ?>
						<a href="<?php echo esc_url( get_tag_link( $sg_tag ) ); ?>"><?php echo esc_html( $sg_tag->name ); ?></a>
					<?php endforeach; ?>
				</div>
			</section>
		<?php endif; ?>
	<?php endif; ?>

	<?php sg_ad( 'sidebar_bottom' ); ?>
</aside>
