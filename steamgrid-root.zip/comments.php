<?php
/**
 * 评论模板（AJAX 提交与刷新）
 *
 * @package SteamGrid
 */

if ( post_password_required() ) {
	return;
}
?>
<div id="comments" class="sg-comments" data-sg-comments>
	<div class="sg-comments-head">
		<h2 class="sg-comments-title"><?php echo esc_html( sg_comment_count_text() ); ?></h2>
		<?php if ( ! is_user_logged_in() && sg_captcha_enabled( 'comment' ) ) : ?>
			<span class="sg-comments-hint"><?php esc_html_e( '游客评论需填写验证码', 'steamgrid' ); ?></span>
		<?php endif; ?>
	</div>

	<?php if ( have_comments() ) : ?>
		<ol class="sg-comment-list">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'short_ping'  => true,
					'avatar_size' => 44,
					'callback'    => 'sg_comment_callback',
				)
			);
			?>
		</ol>

		<?php
		the_comments_pagination(
			array(
				'prev_text' => '← ' . esc_html__( '较早评论', 'steamgrid' ),
				'next_text' => esc_html__( '较新评论', 'steamgrid' ) . ' →',
			)
		);
		?>
	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
		<p class="sg-comments-closed"><?php esc_html_e( '评论已关闭。', 'steamgrid' ); ?></p>
	<?php endif; ?>

	<?php
	$sg_emoji_list = array( '😀', '😁', '😂', '🤣', '😃', '😄', '😅', '😊', '😍', '😘', '😎', '🤔', '😴', '😭', '😡', '👍', '👎', '👏', '🙏', '💪', '🎉', '❤️', '💔', '🔥', '✨', '💯', '🌟', '🚀', '☕', '🍺', '🎮', '📚' );
	$sg_emoji_html = '';

	foreach ( $sg_emoji_list as $sg_emoji ) {
		$sg_emoji_html .= '<button type="button" class="sg-emoji-item" data-sg-emoji="' . esc_attr( $sg_emoji ) . '" aria-label="' . esc_attr( $sg_emoji ) . '">' . esc_html( $sg_emoji ) . '</button>';
	}

	comment_form(
		array(
			'title_reply'          => __( '发表评论', 'steamgrid' ),
			'title_reply_to'       => __( '回复 %s', 'steamgrid' ),
			'cancel_reply_link'    => __( '取消回复', 'steamgrid' ),
			'label_submit'         => __( '发表评论', 'steamgrid' ),
			'class_form'           => 'sg-comment-form',
			'class_submit'         => 'sg-btn',
			'comment_notes_before' => '<p class="sg-comment-notes">' . esc_html__( '邮箱不会被公开。带 * 的为必填项，验证码用于拦截垃圾评论。', 'steamgrid' ) . '</p>',
			'comment_field'        => '<p class="comment-form-comment"><label for="comment">' . esc_html__( '评论内容', 'steamgrid' ) . ' <span class="required">*</span></label><textarea id="comment" name="comment" cols="45" rows="6" required></textarea></p>'
				. '<div class="sg-comment-tools">'
				. '<button type="button" class="sg-emoji-toggle" data-sg-emoji-toggle aria-expanded="false">😊 ' . esc_html__( '表情', 'steamgrid' ) . '</button>'
				. '<div class="sg-emoji-panel" data-sg-emoji-panel hidden>' . $sg_emoji_html . '</div>'
				. '</div>',
		)
	);
	?>

	<div class="sg-comment-feedback" data-sg-comment-feedback hidden></div>
</div>
