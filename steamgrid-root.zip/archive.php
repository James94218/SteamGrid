<?php
/**
 * 归档模板（分类、标签、日期、作者）
 *
 * @package SteamGrid
 */

get_header();
?>

<div class="sg-container sg-page">
	<div class="sg-main-grid">

		<div class="sg-content-area">
			<header class="sg-page-head">
				<?php the_archive_title( '<h1 class="sg-page-title">', '</h1>' ); ?>
				<?php the_archive_description( '<div class="sg-page-desc">', '</div>' ); ?>
			</header>

			<?php if ( have_posts() ) : ?>
				<div class="sg-grid">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/content', 'card' );
					endwhile;
					?>
				</div>
				<?php sg_pagination(); ?>
			<?php else : ?>
				<?php get_template_part( 'template-parts/content', 'none' ); ?>
			<?php endif; ?>
		</div>

		<?php get_sidebar(); ?>
	</div>
</div>

<?php
get_footer();
