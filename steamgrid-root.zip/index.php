<?php
/**
 * 博客列表 / 默认模板
 *
 * @package SteamGrid
 */

get_header();
?>

<div class="sg-container sg-page">
	<div class="sg-main-grid">

		<div class="sg-content-area">
			<header class="sg-page-head">
				<h1 class="sg-page-title">
					<?php
					if ( is_home() && ! is_front_page() ) {
						single_post_title();
					} else {
						esc_html_e( '全部内容', 'steamgrid' );
					}
					?>
				</h1>
			</header>

			<?php if ( have_posts() ) : ?>
				<div class="sg-grid">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/content', 'card' );
					endwhile;
					?>
				</div>
				<?php sg_pagination(); ?>
			<?php else : ?>
				<?php get_template_part( 'template-parts/content', 'none' ); ?>
			<?php endif; ?>
		</div>

		<?php get_sidebar(); ?>
	</div>
</div>

<?php
get_footer();
