<?php
/**
 * 首页：横幅 + 推荐 + 最新（含侧边栏与加载更多）
 *
 * @package SteamGrid
 */

get_header();

$sg_hero_btn_url = sg_get( 'hero_btn_url' );
if ( ! $sg_hero_btn_url ) {
	$sg_hero_btn_url = sg_posts_page_url();
}

$sg_carousel_slides = sg_on( 'carousel_enable' ) ? sg_get_carousel_slides() : array();
$sg_carousel_speed  = max( 2, absint( sg_get( 'carousel_speed', 6 ) ) );

$sg_carousel_transition = sg_get( 'carousel_transition', 'fade' );
if ( ! in_array( $sg_carousel_transition, array( 'fade', 'slide', 'zoom' ), true ) ) {
	$sg_carousel_transition = 'fade';
}

$sg_carousel_autoplay = sg_on( 'carousel_autoplay' );
$sg_carousel_wheel    = sg_on( 'carousel_wheel' );
$sg_carousel_pause    = sg_on( 'carousel_pause_hover' );
$sg_carousel_button   = sg_get( 'carousel_button_text' );
if ( ! $sg_carousel_button ) {
	$sg_carousel_button = __( '查看详情', 'steamgrid' );
}
?>

<?php if ( $sg_carousel_slides ) : ?>
<section
	class="sg-hero-carousel"
	data-sg-carousel
	data-speed="<?php echo esc_attr( $sg_carousel_speed ); ?>"
	data-transition="<?php echo esc_attr( $sg_carousel_transition ); ?>"
	data-autoplay="<?php echo $sg_carousel_autoplay ? '1' : '0'; ?>"
	data-wheel="<?php echo $sg_carousel_wheel ? '1' : '0'; ?>"
	data-pause="<?php echo $sg_carousel_pause ? '1' : '0'; ?>"
	tabindex="0"
	aria-roledescription="carousel"
	aria-label="<?php esc_attr_e( '精选推荐', 'steamgrid' ); ?>"
>
	<div class="sg-carousel-viewport">
		<?php foreach ( $sg_carousel_slides as $sg_index => $sg_slide ) : ?>
			<?php
			$sg_slide_title  = isset( $sg_slide['title'] ) ? $sg_slide['title'] : '';
			$sg_slide_text   = isset( $sg_slide['text'] ) ? $sg_slide['text'] : '';
			$sg_slide_link   = isset( $sg_slide['link'] ) ? $sg_slide['link'] : '';
			$sg_slide_image  = isset( $sg_slide['image'] ) ? $sg_slide['image'] : '';
			$sg_slide_button = ! empty( $sg_slide['button'] ) ? $sg_slide['button'] : $sg_carousel_button;
			$sg_slide_tags   = isset( $sg_slide['tags'] ) ? array_filter( array_map( 'trim', explode( ',', $sg_slide['tags'] ) ) ) : array();
			$sg_is_active    = ( 0 === (int) $sg_index );
			?>
			<article class="sg-slide<?php echo $sg_is_active ? ' is-active' : ''; ?>" aria-hidden="<?php echo $sg_is_active ? 'false' : 'true'; ?>">
				<div class="sg-slide-media"<?php echo $sg_slide_image ? ' style="background-image:url(' . esc_url( $sg_slide_image ) . ')"' : ''; ?>>
					<?php if ( $sg_slide_link ) : ?>
						<a class="sg-slide-hit" href="<?php echo esc_url( $sg_slide_link ); ?>" aria-label="<?php echo esc_attr( $sg_slide_title ); ?>"></a>
					<?php endif; ?>
				</div>
				<div class="sg-slide-info">
					<?php if ( $sg_slide_title ) : ?>
						<h2 class="sg-slide-title"><?php echo esc_html( $sg_slide_title ); ?></h2>
					<?php endif; ?>

					<?php if ( $sg_slide_tags ) : ?>
						<div class="sg-slide-tags">
							<?php foreach ( $sg_slide_tags as $sg_tag ) : ?>
								<span><?php echo esc_html( $sg_tag ); ?></span>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>

					<?php if ( $sg_slide_text ) : ?>
						<p class="sg-slide-text"><?php echo esc_html( $sg_slide_text ); ?></p>
					<?php endif; ?>

					<?php if ( $sg_slide_link ) : ?>
						<a class="sg-btn sg-slide-btn" href="<?php echo esc_url( $sg_slide_link ); ?>"><?php echo esc_html( $sg_slide_button ); ?></a>
					<?php endif; ?>
				</div>
			</article>
		<?php endforeach; ?>

		<?php if ( sg_on( 'carousel_arrows' ) && count( $sg_carousel_slides ) > 1 ) : ?>
			<button type="button" class="sg-carousel-arrow prev" data-sg-carousel-prev aria-label="<?php esc_attr_e( '上一张', 'steamgrid' ); ?>">‹</button>
			<button type="button" class="sg-carousel-arrow next" data-sg-carousel-next aria-label="<?php esc_attr_e( '下一张', 'steamgrid' ); ?>">›</button>
		<?php endif; ?>

		<?php if ( sg_on( 'carousel_dots' ) && count( $sg_carousel_slides ) > 1 ) : ?>
			<div class="sg-carousel-dots" role="tablist">
				<?php foreach ( $sg_carousel_slides as $sg_dot_index => $sg_dot_slide ) : ?>
					<button
						type="button"
						class="sg-carousel-dot<?php echo 0 === $sg_dot_index ? ' is-active' : ''; ?>"
						data-sg-carousel-dot="<?php echo esc_attr( $sg_dot_index ); ?>"
						aria-label="<?php echo esc_attr( sprintf( __( '第 %d 张', 'steamgrid' ), $sg_dot_index + 1 ) ); ?>"
					></button>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<?php if ( $sg_carousel_autoplay && count( $sg_carousel_slides ) > 1 ) : ?>
			<div class="sg-carousel-progress"><span data-sg-carousel-progress></span></div>
		<?php endif; ?>
	</div>
</section>
<?php elseif ( sg_on( 'hero_show' ) ) : ?>
<section class="sg-hero" <?php echo sg_hero_style_attr(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<div class="sg-container sg-hero-inner">
		<div class="sg-hero-copy">
			<h1 class="sg-hero-title"><?php echo esc_html( sg_get( 'hero_title', get_bloginfo( 'name' ) ) ); ?></h1>
			<?php $sg_hero_sub = sg_get( 'hero_subtitle' ); ?>
			<?php if ( $sg_hero_sub ) : ?>
				<p class="sg-hero-subtitle"><?php echo esc_html( $sg_hero_sub ); ?></p>
			<?php endif; ?>
			<?php $sg_hero_btn = sg_get( 'hero_btn_text' ); ?>
			<?php if ( $sg_hero_btn ) : ?>
				<a class="sg-btn sg-btn-hero" href="<?php echo esc_url( $sg_hero_btn_url ); ?>"><?php echo esc_html( $sg_hero_btn ); ?></a>
			<?php endif; ?>
		</div>
	</div>
</section>
<?php endif; ?>

<div class="sg-container sg-front">
	<div class="sg-main-grid">

		<div class="sg-content-area">
			<?php sg_ad( 'home_top' ); ?>

			<?php
			$sg_featured_ids = array();
			$sg_featured     = null;

			if ( 'category' === sg_get( 'featured_source', 'sticky' ) && sg_get( 'featured_category' ) ) {
				$sg_featured = new WP_Query(
					array(
						'cat'                 => absint( sg_get( 'featured_category' ) ),
						'posts_per_page'      => 8,
						'ignore_sticky_posts' => true,
					)
				);
			} else {
				$sg_sticky = get_option( 'sticky_posts' );
				if ( $sg_sticky ) {
					$sg_featured = new WP_Query(
						array(
							'post__in'            => $sg_sticky,
							'posts_per_page'      => 8,
							'ignore_sticky_posts' => true,
						)
					);
				}
			}

			$sg_featured_has = $sg_featured ? $sg_featured->have_posts() : false;

			if ( $sg_featured_has ) :
				?>
				<section class="sg-section">
					<div class="sg-section-head">
						<h2 class="sg-section-title"><?php echo esc_html( sg_get( 'featured_title', __( '特别推荐', 'steamgrid' ) ) ); ?></h2>
						<a class="sg-section-more" href="<?php echo esc_url( sg_posts_page_url() ); ?>"><?php esc_html_e( '查看更多', 'steamgrid' ); ?> →</a>
					</div>
					<div class="sg-grid">
						<?php
						while ( $sg_featured->have_posts() ) :
							$sg_featured->the_post();
							$sg_featured_ids[] = get_the_ID();
							get_template_part( 'template-parts/content', 'card' );
						endwhile;
						?>
					</div>
				</section>
			<?php endif; ?>
			<?php wp_reset_postdata(); ?>

			<?php
			$sg_per_page = max( 2, absint( sg_get( 'home_page_size', 12 ) ) );
			$sg_latest   = new WP_Query(
				array(
					'posts_per_page'      => $sg_per_page,
					'post__not_in'        => $sg_featured_ids,
					'ignore_sticky_posts' => true,
					'paged'               => 1,
				)
			);
			$sg_latest_has = $sg_latest->have_posts();

			if ( $sg_latest_has ) :
				?>
				<section class="sg-section">
					<div class="sg-section-head">
						<h2 class="sg-section-title"><?php echo esc_html( sg_get( 'latest_title', __( '最新上架', 'steamgrid' ) ) ); ?></h2>
						<a class="sg-section-more" href="<?php echo esc_url( sg_posts_page_url() ); ?>"><?php esc_html_e( '查看更多', 'steamgrid' ); ?> →</a>
					</div>

					<div class="sg-grid" data-sg-post-grid>
						<?php
						while ( $sg_latest->have_posts() ) :
							$sg_latest->the_post();
							get_template_part( 'template-parts/content', 'card' );
						endwhile;
						?>
					</div>

					<?php if ( sg_on( 'load_more' ) && $sg_latest->max_num_pages > 1 ) : ?>
						<div class="sg-load-more-wrap">
							<button type="button" class="sg-btn sg-load-more" data-sg-load-more data-paged="2" data-per-page="<?php echo esc_attr( $sg_per_page ); ?>" data-exclude="<?php echo esc_attr( implode( ',', $sg_featured_ids ) ); ?>">
								<?php esc_html_e( '加载更多', 'steamgrid' ); ?>
							</button>
						</div>
					<?php endif; ?>
				</section>
			<?php endif; ?>
			<?php wp_reset_postdata(); ?>

			<?php if ( ! $sg_featured_has && ! $sg_latest_has ) : ?>
				<div class="sg-none">
					<h2><?php esc_html_e( '还没有内容', 'steamgrid' ); ?></h2>
					<p><?php esc_html_e( '发布几篇文章（并设置特色图片），它们就会出现在这里。', 'steamgrid' ); ?></p>
					<?php if ( current_user_can( 'edit_posts' ) ) : ?>
						<a class="sg-btn" href="<?php echo esc_url( admin_url( 'post-new.php' ) ); ?>"><?php esc_html_e( '发布第一篇文章', 'steamgrid' ); ?></a>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<?php sg_ad( 'home_bottom' ); ?>
		</div>

		<?php get_sidebar(); ?>
	</div>
</div>

<?php
get_footer();
