<?php
/**
 * 文章多级目录
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 解析正文标题并生成目录
 *
 * @param string $content 正文。
 * @return array [正文, 标题数组]
 */
function sg_build_toc( $content ) {
	$depth    = max( 2, min( 4, absint( sg_get( 'toc_depth', 3 ) ) ) );
	$headings = array();
	$used     = array();

	$pattern = '/<h([2-' . $depth . '])([^>]*)>(.*?)<\/h\1>/is';

	$content = preg_replace_callback(
		$pattern,
		function ( $matches ) use ( &$headings, &$used ) {
			$level = (int) $matches[1];
			$attrs = $matches[2];
			$inner = $matches[3];
			$text  = trim( wp_strip_all_tags( $inner ) );

			if ( '' === $text ) {
				return $matches[0];
			}

			$id = '';
			if ( preg_match( '/\bid\s*=\s*["\']([^"\']+)["\']/i', $attrs, $id_match ) ) {
				$id = sanitize_html_class( $id_match[1] );
			}

			if ( ! $id ) {
				$id = 'toc-' . sanitize_title( $text );
			}
			if ( ! $id || 'toc-' === $id ) {
				$id = 'toc-' . count( $headings );
			}

			$base = $id;
			$i    = 2;
			while ( isset( $used[ $id ] ) ) {
				$id = $base . '-' . $i;
				$i++;
			}
			$used[ $id ] = true;

			$headings[] = array(
				'level' => $level,
				'text'  => $text,
				'id'    => $id,
			);

			if ( false === strpos( $attrs, 'id=' ) ) {
				$attrs .= ' id="' . esc_attr( $id ) . '"';
			}

			return '<h' . $matches[1] . $attrs . '>' . $inner . '</h' . $matches[1] . '>';
		},
		$content
	);

	return array( $content, $headings );
}

/**
 * 递归生成嵌套目录
 *
 * @param array $headings 标题。
 * @param int   $index    当前索引。
 * @param int   $level    当前层级。
 * @return string
 */
function sg_toc_render_list( $headings, &$index, $level ) {
	$count = count( $headings );
	$html  = '<ul class="sg-toc-list">';

	while ( $index < $count ) {
		$heading = $headings[ $index ];

		if ( $heading['level'] < $level ) {
			break;
		}

		if ( $heading['level'] > $level ) {
			$html .= sg_toc_render_list( $headings, $index, $heading['level'] );
			continue;
		}

		$html .= '<li class="sg-toc-item sg-toc-level-' . (int) $heading['level'] . '">';
		$html .= '<a href="#' . esc_attr( $heading['id'] ) . '">' . esc_html( $heading['text'] ) . '</a>';
		$index++;

		if ( $index < $count && $headings[ $index ]['level'] > $level ) {
			$html .= sg_toc_render_list( $headings, $index, $headings[ $index ]['level'] );
		}

		$html .= '</li>';
	}

	$html .= '</ul>';

	return $html;
}

/**
 * 目录 HTML
 *
 * @param array $headings 标题数组。
 * @return string
 */
function sg_toc_html( $headings ) {
	if ( count( $headings ) < 2 ) {
		return '';
	}

	$index = 0;
	$list  = sg_toc_render_list( $headings, $index, $headings[0]['level'] );

	$html  = '<nav class="sg-toc" aria-label="' . esc_attr__( '文章目录', 'steamgrid' ) . '">';
	$html .= '<div class="sg-toc-head"><span class="sg-toc-title">' . esc_html__( '目录', 'steamgrid' ) . '</span>';
	$html .= '<button type="button" class="sg-toc-toggle" aria-expanded="true">' . esc_html__( '收起', 'steamgrid' ) . '</button></div>';
	$html .= $list;
	$html .= '</nav>';

	return $html;
}

/**
 * 注入目录
 *
 * @param string $content 正文。
 * @return string
 */
function sg_add_toc_to_content( $content ) {
	if ( ! is_singular() || is_feed() || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}
	if ( ! sg_on( 'toc_enable' ) || 'content' !== sg_get( 'toc_position', 'content' ) ) {
		return $content;
	}
	if ( get_post_meta( get_the_ID(), '_sg_toc_disable', true ) ) {
		return $content;
	}
	if ( is_page_template( array( 'page-templates/login.php', 'page-templates/register.php', 'page-templates/lost-password.php', 'page-templates/user-center.php', 'page-templates/sitemap.php' ) ) ) {
		return $content;
	}

	list( $content, $headings ) = sg_build_toc( $content );

	$GLOBALS['sg_current_toc'] = $headings;

	$toc = sg_toc_html( $headings );
	if ( ! $toc ) {
		return $content;
	}

	return $toc . $content;
}
add_filter( 'the_content', 'sg_add_toc_to_content', 9 );

/**
 * 供小工具调用：当前文章目录
 *
 * @return string
 */
function sg_get_current_toc() {
	if ( ! is_singular() ) {
		return '';
	}

	if ( ! empty( $GLOBALS['sg_current_toc'] ) ) {
		return sg_toc_html( $GLOBALS['sg_current_toc'] );
	}

	$content                = (string) get_post_field( 'post_content', get_the_ID() );
	list( $parsed, $headings ) = sg_build_toc( $content );
	$GLOBALS['sg_current_toc'] = $headings;

	return sg_toc_html( $headings );
}
