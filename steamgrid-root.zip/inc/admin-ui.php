<?php
/**
 * 后台主题设置面板（Vue3 + NaiveUI，构建缺失时回退原生表单）
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 读取用于后台的完整设置（仅结构内字段）
 *
 * @return array
 */
function sg_get_all_for_admin() {
	$values   = array();
	$defaults = sg_defaults();
	foreach ( $defaults as $key => $default ) {
		$values[ $key ] = sg_get( $key, $default );
	}
	return $values;
}

/* ------------------------------------------------------------
 * 菜单
 * ---------------------------------------------------------- */
function sg_admin_menu() {
	add_menu_page(
		__( 'SteamGrid 主题设置', 'steamgrid' ),
		__( 'SteamGrid 设置', 'steamgrid' ),
		'manage_options',
		'steamgrid-settings',
		'sg_render_admin_page',
		'dashicons-superhero-alt',
		59
	);
}
add_action( 'admin_menu', 'sg_admin_menu' );

/* ------------------------------------------------------------
 * 资源
 * ---------------------------------------------------------- */
/**
 * 获取后台面板资源地址（优先带版本号的文件名，绕过缓存与去查询字符串插件）
 *
 * @param string $type js|css。
 * @return string
 */
function sg_admin_asset_url( $type ) {
	$type = ( 'css' === $type ) ? 'css' : 'js';

	$versioned = SG_DIR . '/assets/admin/app-' . SG_VERSION . '.' . $type;
	if ( file_exists( $versioned ) ) {
		return SG_URI . '/assets/admin/app-' . SG_VERSION . '.' . $type;
	}

	$plain = SG_DIR . '/assets/admin/app.' . $type;
	if ( file_exists( $plain ) ) {
		return SG_URI . '/assets/admin/app.' . $type;
	}

	return '';
}

function sg_admin_assets( $hook ) {
	if ( 'toplevel_page_steamgrid-settings' !== $hook ) {
		return;
	}

	wp_enqueue_media();

	$css_url = sg_admin_asset_url( 'css' );
	if ( $css_url ) {
		wp_enqueue_style( 'sg-admin-app', $css_url, array(), SG_VERSION );
	}

	$js_url = sg_admin_asset_url( 'js' );
	if ( $js_url ) {
		wp_enqueue_script( 'sg-admin-app', $js_url, array(), SG_VERSION, true );
		wp_localize_script(
			'sg-admin-app',
			'SG_ADMIN',
			array(
				'schema'      => sg_schema(),
				'values'      => sg_get_all_for_admin(),
				'nonce'       => wp_create_nonce( 'sg_admin' ),
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'version'     => SG_VERSION,
				'build'       => SG_VERSION,
				'adminUrl'    => admin_url(),
				'mediaTitle'  => __( '选择图片', 'steamgrid' ),
				'mediaButton' => __( '使用这张图片', 'steamgrid' ),
			)
		);
	}
}
add_action( 'admin_enqueue_scripts', 'sg_admin_assets' );

/* ------------------------------------------------------------
 * 页面输出
 * ---------------------------------------------------------- */
function sg_render_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$has_app = (bool) sg_admin_asset_url( 'js' );

	echo '<div class="wrap sg-admin-page">';
	$sg_asset_name = basename( sg_admin_asset_url( 'js' ) );
	echo '<p class="sg-admin-version" style="margin:0 0 10px;color:#646970;font-size:12px">' . esc_html( 'SteamGrid v' . SG_VERSION . ( $sg_asset_name ? ' · 面板脚本 ' . $sg_asset_name : '' ) ) . '</p>';
	echo '<div id="sg-admin-app" class="sg-admin-app">';
	if ( ! $has_app ) {
		sg_render_native_form();
	} else {
		echo '<p class="sg-admin-loading">' . esc_html__( '正在加载配置面板…（若加载失败，会自动切换到下方原生表单）', 'steamgrid' ) . '</p>';
	}
	echo '</div>';

	if ( $has_app ) {
		?>
		<style>
			.sg-native-fallback {
				margin: 24px 0;
				padding: 0 18px;
				background: #fff;
				border: 1px solid #dcdcde;
				border-radius: 6px;
			}
			.sg-native-fallback > summary {
				cursor: pointer;
				padding: 14px 0;
				font-weight: 600;
			}
			.sg-native-fallback[open] > summary {
				border-bottom: 1px solid #f0f0f1;
				margin-bottom: 12px;
			}
		</style>
		<details class="sg-native-fallback">
			<summary><?php esc_html_e( 'Vue 面板无法加载？点此使用原生表单（功能一致）', 'steamgrid' ); ?></summary>
			<?php sg_render_native_form(); ?>
		</details>
		<script>
		(function () {
			var app = document.getElementById('sg-admin-app');
			if (!app) {
				return;
			}
			var errors = [];
			window.addEventListener('error', function (event) {
				errors.push((event.message || 'error') + (event.filename ? ' @ ' + event.filename : ''));
			}, true);
			window.setTimeout(function () {
				if (document.querySelector('.sg-panel')) {
					return;
				}
				var scriptTag = document.querySelector('script[src*="assets/admin/app.js"]');
				var box = document.createElement('div');
				box.className = 'notice notice-error';
				box.innerHTML =
					'<p><strong><?php echo esc_js( __( 'Vue 配置面板未能加载。', 'steamgrid' ) ); ?></strong>' +
					'<?php echo esc_js( __( '已自动展开下方原生表单，可直接保存设置。', 'steamgrid' ) ); ?></p>' +
					'<p><?php echo esc_js( __( '诊断：', 'steamgrid' ) ); ?> SG_ADMIN=' + (typeof window.SG_ADMIN) +
					'；<?php echo esc_js( __( '构建：', 'steamgrid' ) ); ?>' + (window.SG_ADMIN_BUILD || '<?php echo esc_js( __( '旧版/未执行', 'steamgrid' ) ); ?>') +
					'；<?php echo esc_js( __( '脚本：', 'steamgrid' ) ); ?>' + (scriptTag ? scriptTag.src : '<?php echo esc_js( __( '未输出', 'steamgrid' ) ); ?>') +
					'；<?php echo esc_js( __( '错误：', 'steamgrid' ) ); ?>' + (errors.length ? errors.join(' | ') : '<?php echo esc_js( __( '无', 'steamgrid' ) ); ?>') + '</p>';
				app.innerHTML = '';
				app.appendChild(box);
				var fallback = document.querySelector('.sg-native-fallback');
				if (fallback) {
					fallback.open = true;
				}
			}, 7000);
		})();
		</script>
		<noscript>
			<div class="notice notice-warning"><p><?php esc_html_e( '浏览器已禁用 JavaScript，请使用上方「原生表单」保存设置。', 'steamgrid' ); ?></p></div>
		</noscript>
		<?php
	}
	echo '</div>';
}

/**
 * 构建缺失时的原生回退表单
 */
function sg_render_native_form() {
	$schema = sg_schema();
	$values = sg_get_all_for_admin();
	?>
	<div class="notice notice-warning"><p><?php esc_html_e( '未检测到 Vue 后台构建文件（assets/admin/app.js），当前使用原生表单，功能一致。', 'steamgrid' ); ?></p></div>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="sg-native-form">
		<input type="hidden" name="action" value="sg_native_save" />
		<?php wp_nonce_field( 'sg_native_save' ); ?>
		<?php foreach ( $schema as $tab_key => $tab ) : ?>
			<h2><?php echo esc_html( $tab['label'] ); ?></h2>
			<?php foreach ( $tab['sections'] as $section ) : ?>
				<h3><?php echo esc_html( $section['label'] ); ?></h3>
				<table class="form-table" role="presentation">
					<tbody>
					<?php foreach ( $section['fields'] as $key => $field ) : ?>
						<?php $value = isset( $values[ $key ] ) ? $values[ $key ] : ''; ?>
						<tr>
							<th scope="row"><label for="sg-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?></label></th>
							<td>
								<?php
								$type = isset( $field['type'] ) ? $field['type'] : 'text';
								$id   = 'sg-' . $key;

								if ( 'switch' === $type ) :
									?>
									<label><input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="sg_settings[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( (bool) $value ); ?> /> <?php esc_html_e( '启用', 'steamgrid' ); ?></label>
									<?php
								elseif ( 'select' === $type ) :
									?>
									<select id="<?php echo esc_attr( $id ); ?>" name="sg_settings[<?php echo esc_attr( $key ); ?>]">
										<?php foreach ( $field['options'] as $opt_value => $opt_label ) : ?>
											<option value="<?php echo esc_attr( $opt_value ); ?>" <?php selected( (string) $value, (string) $opt_value ); ?>><?php echo esc_html( $opt_label ); ?></option>
										<?php endforeach; ?>
									</select>
									<?php
								elseif ( 'textarea' === $type || 'html' === $type || 'js' === $type || 'code' === $type ) :
									?>
									<textarea id="<?php echo esc_attr( $id ); ?>" name="sg_settings[<?php echo esc_attr( $key ); ?>]" rows="6" class="large-text code"><?php echo esc_textarea( (string) $value ); ?></textarea>
									<?php
								elseif ( 'color' === $type ) :
									?>
									<input type="color" id="<?php echo esc_attr( $id ); ?>" name="sg_settings[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>" />
									<?php
								elseif ( 'number' === $type ) :
									?>
									<input type="number" id="<?php echo esc_attr( $id ); ?>" name="sg_settings[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>" class="small-text" />
									<?php
								elseif ( 'password' === $type ) :
									?>
									<input type="password" id="<?php echo esc_attr( $id ); ?>" name="sg_settings[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>" class="regular-text" autocomplete="new-password" />
									<?php
								elseif ( 'url' === $type || 'image' === $type ) :
									?>
									<input type="url" id="<?php echo esc_attr( $id ); ?>" name="sg_settings[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>" class="large-text" />
									<?php
								elseif ( 'email' === $type ) :
									?>
									<input type="email" id="<?php echo esc_attr( $id ); ?>" name="sg_settings[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>" class="regular-text" />
									<?php
								elseif ( 'slides' === $type ) :
									?>
									<p class="description"><?php esc_html_e( '手动幻灯片请使用 Vue 面板编辑；在此保存不会修改已有的幻灯片条目。', 'steamgrid' ); ?></p>
									<?php
								else :
									?>
									<input type="text" id="<?php echo esc_attr( $id ); ?>" name="sg_settings[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>" class="regular-text" />
									<?php
								endif;
								?>
								<?php if ( ! empty( $field['desc'] ) ) : ?>
									<p class="description"><?php echo esc_html( $field['desc'] ); ?></p>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endforeach; ?>
		<?php endforeach; ?>
		<?php submit_button( __( '保存设置', 'steamgrid' ) ); ?>
	</form>
	<?php
}

/* ------------------------------------------------------------
 * 原生表单保存
 * ---------------------------------------------------------- */
function sg_handle_native_save() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( '权限不足。', 'steamgrid' ) );
	}
	check_admin_referer( 'sg_native_save' );

	$raw = isset( $_POST['sg_settings'] ) ? wp_unslash( $_POST['sg_settings'] ) : array();
	if ( is_array( $raw ) ) {
		$defaults = sg_defaults();
		$input    = array();
		foreach ( $defaults as $key => $default ) {
			if ( array_key_exists( $key, $raw ) ) {
				$input[ $key ] = $raw[ $key ];
			} else {
				$schema_field = sg_field_by_key( $key );
				if ( $schema_field && 'switch' === $schema_field['type'] ) {
					$input[ $key ] = false;
				}
			}
		}
		sg_save_settings( $input );
	}

	wp_safe_redirect( add_query_arg( 'sg-saved', '1', admin_url( 'admin.php?page=steamgrid-settings' ) ) );
	exit;
}
add_action( 'admin_post_sg_native_save', 'sg_handle_native_save' );

/**
 * 按 key 查找字段定义
 *
 * @param string $key 字段键。
 * @return array|null
 */
function sg_field_by_key( $key ) {
	foreach ( sg_schema() as $tab ) {
		foreach ( $tab['sections'] as $section ) {
			if ( isset( $section['fields'][ $key ] ) ) {
				return $section['fields'][ $key ];
			}
		}
	}
	return null;
}

/* ------------------------------------------------------------
 * AJAX：保存 / 重置 / 导入 / 导出
 * ---------------------------------------------------------- */
function sg_admin_ajax_guard() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => '权限不足' ), 403 );
	}
	check_ajax_referer( 'sg_admin', 'nonce' );
}

function sg_ajax_settings_save() {
	sg_admin_ajax_guard();

	$payload = isset( $_POST['settings'] ) ? json_decode( wp_unslash( $_POST['settings'] ), true ) : null;
	if ( ! is_array( $payload ) ) {
		wp_send_json_error( array( 'message' => '设置数据格式错误' ), 400 );
	}

	sg_save_settings( $payload );

	wp_send_json_success(
		array(
			'message' => '设置已保存',
			'values'  => sg_get_all_for_admin(),
		)
	);
}
add_action( 'wp_ajax_sg_admin_save', 'sg_ajax_settings_save' );

function sg_ajax_settings_reset() {
	sg_admin_ajax_guard();
	$defaults = sg_reset_settings();

	wp_send_json_success(
		array(
			'message' => '已恢复默认设置',
			'values'  => $defaults,
		)
	);
}
add_action( 'wp_ajax_sg_admin_reset', 'sg_ajax_settings_reset' );

function sg_ajax_settings_import() {
	sg_admin_ajax_guard();

	$payload = isset( $_POST['settings'] ) ? json_decode( wp_unslash( $_POST['settings'] ), true ) : null;
	if ( ! is_array( $payload ) ) {
		wp_send_json_error( array( 'message' => '导入内容不是有效的设置 JSON' ), 400 );
	}

	$clean = array_merge( sg_defaults(), sg_sanitize_settings( $payload ) );
	update_option( 'steamgrid_settings', $clean );
	set_transient( 'sg_flush_rewrite', 1, 60 );

	wp_send_json_success(
		array(
			'message' => '设置已导入',
			'values'  => sg_get_all_for_admin(),
		)
	);
}
add_action( 'wp_ajax_sg_admin_import', 'sg_ajax_settings_import' );

function sg_ajax_settings_export() {
	sg_admin_ajax_guard();

	wp_send_json_success(
		array(
			'values' => sg_get_all_for_admin(),
		)
	);
}
add_action( 'wp_ajax_sg_admin_export', 'sg_ajax_settings_export' );

/* ------------------------------------------------------------
 * 重写规则刷新
 * ---------------------------------------------------------- */
function sg_maybe_flush_rewrite() {
	if ( get_transient( 'sg_flush_rewrite' ) ) {
		flush_rewrite_rules( false );
		delete_transient( 'sg_flush_rewrite' );
	}
}
add_action( 'admin_init', 'sg_maybe_flush_rewrite', 20 );
