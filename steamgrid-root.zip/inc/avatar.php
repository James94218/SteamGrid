<?php
/**
 * 头像：自定义头像、本地首字母头像（不依赖 Gravatar）
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 生成首字母 SVG
 *
 * @param string $name 显示名。
 * @param string $seed 配色种子（邮箱哈希）。
 * @param int    $size 尺寸。
 * @return string
 */
function sg_letter_avatar_svg( $name, $seed = '', $size = 96 ) {
	$size   = max( 24, min( 256, absint( $size ) ) );
	$name   = trim( wp_strip_all_tags( (string) $name ) );
	$letter = mb_substr( $name, 0, 1 );
	if ( '' === $letter ) {
		$letter = '?';
	}

	$hash   = md5( (string) $seed . '|' . strtolower( $name ) );
	$hue    = hexdec( substr( $hash, 0, 2 ) ) % 360;
	$hue2   = ( $hue + 35 ) % 360;
	$font   = max( 12, (int) round( $size * 0.42 ) );
	$color  = 'hsl(' . $hue . ', 52%, 42%)';
	$color2 = 'hsl(' . $hue2 . ', 58%, 32%)';

	return '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size . '" viewBox="0 0 ' . $size . ' ' . $size . '">'
		. '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">'
		. '<stop offset="0" stop-color="' . $color . '"/>'
		. '<stop offset="1" stop-color="' . $color2 . '"/>'
		. '</linearGradient></defs>'
		. '<rect width="100%" height="100%" rx="' . ( $size / 2 ) . '" fill="url(#g)"/>'
		. '<text x="50%" y="50%" dy=".35em" text-anchor="middle" font-family="Segoe UI, Microsoft YaHei, sans-serif" font-size="' . $font . '" font-weight="600" fill="#ffffff">' . esc_html( $letter ) . '</text>'
		. '</svg>';
}

/**
 * 首字母头像地址（通过 admin-ajax 输出 SVG，避免 data URI 被 esc_url 过滤）
 *
 * @param string $name  显示名。
 * @param string $email 邮箱。
 * @param int    $size  尺寸。
 * @return string
 */
function sg_letter_avatar_url( $name, $email = '', $size = 96 ) {
	$size = max( 24, min( 256, absint( $size ) ) );
	$seed = substr( md5( strtolower( trim( (string) $email ) ) ), 0, 10 );

	return add_query_arg(
		array(
			'action' => 'sg_avatar',
			'n'      => $name,
			'e'      => $seed,
			's'      => $size,
		),
		admin_url( 'admin-ajax.php' )
	);
}

/**
 * 首字母头像输出接口
 */
function sg_avatar_endpoint() {
	$name = isset( $_GET['n'] ) ? sanitize_text_field( wp_unslash( $_GET['n'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$seed = isset( $_GET['e'] ) ? sanitize_text_field( wp_unslash( $_GET['e'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$size = isset( $_GET['s'] ) ? absint( $_GET['s'] ) : 96; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

	header( 'Content-Type: image/svg+xml; charset=UTF-8' );
	header( 'Cache-Control: public, max-age=2592000, immutable' );
	echo sg_letter_avatar_svg( $name, $seed, $size ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	exit;
}
add_action( 'wp_ajax_sg_avatar', 'sg_avatar_endpoint' );
add_action( 'wp_ajax_nopriv_sg_avatar', 'sg_avatar_endpoint' );

/**
 * 解析头像对象对应的名称 / 邮箱 / 用户 ID
 *
 * @param mixed $id_or_email 头像参数。
 * @return array
 */
function sg_avatar_identity( $id_or_email ) {
	$name    = '';
	$email   = '';
	$user_id = 0;

	if ( $id_or_email instanceof WP_Comment ) {
		$name    = (string) $id_or_email->comment_author;
		$email   = (string) $id_or_email->comment_author_email;
		$user_id = (int) $id_or_email->user_id;
	} elseif ( is_object( $id_or_email ) && ! empty( $id_or_email->comment_author_email ) ) {
		$name    = (string) $id_or_email->comment_author;
		$email   = (string) $id_or_email->comment_author_email;
		$user_id = ! empty( $id_or_email->user_id ) ? (int) $id_or_email->user_id : 0;
	} elseif ( $id_or_email instanceof WP_User ) {
		$user_id = (int) $id_or_email->ID;
	} elseif ( is_numeric( $id_or_email ) ) {
		$user_id = (int) $id_or_email;
	} elseif ( is_string( $id_or_email ) && is_email( $id_or_email ) ) {
		$email = $id_or_email;
		$user  = get_user_by( 'email', $email );
		if ( $user ) {
			$user_id = (int) $user->ID;
		}
	} elseif ( is_object( $id_or_email ) && ! empty( $id_or_email->user_id ) ) {
		$user_id = (int) $id_or_email->user_id;
	}

	if ( $user_id ) {
		$user = get_userdata( $user_id );
		if ( $user ) {
			if ( '' === $name ) {
				$name = $user->display_name;
			}
			if ( '' === $email ) {
				$email = $user->user_email;
			}
		}
	}

	return array( $name, $email, $user_id );
}

/**
 * 头像数据过滤：自定义头像优先，否则本地首字母头像
 *
 * @param array $args        头像参数。
 * @param mixed $id_or_email 头像对象。
 * @return array
 */
function sg_custom_avatar_data( $args, $id_or_email ) {
	list( $name, $email, $user_id ) = sg_avatar_identity( $id_or_email );

	if ( $user_id ) {
		$attachment_id = (int) get_user_meta( $user_id, '_sg_avatar', true );
		if ( $attachment_id ) {
			$url = wp_get_attachment_image_url( $attachment_id, 'thumbnail' );
			if ( $url ) {
				$args['url'] = $url;
				return $args;
			}
		}
	}

	if ( sg_on( 'local_avatar' ) ) {
		$size        = ! empty( $args['size'] ) ? absint( $args['size'] ) : 96;
		$label       = '' !== $name ? $name : __( '访客', 'steamgrid' );
		$args['url'] = sg_letter_avatar_url( $label, $email, $size );
	}

	return $args;
}
add_filter( 'get_avatar_data', 'sg_custom_avatar_data', 10, 2 );
