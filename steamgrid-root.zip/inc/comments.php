<?php
/**
 * 评论安全：图形/极验验证码、蜜罐、提交防护
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 在评论表单中加入验证码与蜜罐
 *
 * @param array $fields 字段。
 * @return array
 */
function sg_comment_security_field( $fields ) {
	if ( is_user_logged_in() ) {
		return $fields;
	}

	$captcha = sg_captcha_field( 'comment' );

	$fields['sg_security'] = '<div class="sg-comment-security">'
		. $captcha
		. '<input type="text" name="sg_hp" value="" class="sg-hp" tabindex="-1" autocomplete="off" aria-hidden="true" />'
		. '</div>';

	return $fields;
}
add_filter( 'comment_form_default_fields', 'sg_comment_security_field', 20 );

/**
 * 校验评论安全项
 *
 * @return true|WP_Error
 */
function sg_comment_security_check() {
	if ( is_user_logged_in() ) {
		return true;
	}

	if ( ! empty( $_POST['sg_hp'] ) ) {
		return new WP_Error( 'sg_spam', __( '评论被拦截，请勿使用自动化工具提交。', 'steamgrid' ) );
	}

	return sg_captcha_validate( 'comment' );
}

/**
 * 传统表单提交校验
 *
 * @param int $post_id 文章 ID。
 */
function sg_comment_submit_check( $post_id ) {
	if ( isset( $_POST['comment_type'] ) && 'comment' !== $_POST['comment_type'] ) {
		return;
	}

	$security = sg_comment_security_check();
	if ( ! is_wp_error( $security ) ) {
		return;
	}

	wp_die(
		'<p>' . esc_html( $security->get_error_message() ) . '</p>' .
		'<p><a href="' . esc_url( get_permalink( $post_id ) ) . '#respond">' . esc_html__( '← 返回重新评论', 'steamgrid' ) . '</a></p>',
		esc_html__( '评论验证失败', 'steamgrid' ),
		array(
			'response'  => 403,
			'back_link' => true,
		)
	);
}
add_action( 'pre_comment_on_post', 'sg_comment_submit_check' );

/**
 * 评论数量文本
 *
 * @param int $post_id 文章 ID。
 * @return string
 */
function sg_comment_count_text( $post_id = 0 ) {
	$count = (int) get_comments_number( $post_id );
	if ( 0 === $count ) {
		return __( '暂无评论', 'steamgrid' );
	}
	return sprintf( _n( '%s 条评论', '%s 条评论', $count, 'steamgrid' ), number_format_i18n( $count ) );
}

/**
 * 评论回调：头像 + 干净的头部 / 内容 / 操作区
 *
 * @param WP_Comment $comment 评论。
 * @param array      $args    参数。
 * @param int        $depth   层级。
 */
function sg_comment_callback( $comment, $args, $depth ) {
	$tag = ( 'div' === $args['style'] ) ? 'div' : 'li';
	?>
	<<?php echo $tag; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> id="comment-<?php comment_ID(); ?>" <?php comment_class( 'sg-comment' ); ?>>
		<div id="div-comment-<?php comment_ID(); ?>" class="sg-comment-body">
			<div class="sg-comment-avatar">
				<?php echo get_avatar( $comment, 44 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
			<div class="sg-comment-main">
				<div class="sg-comment-head">
					<span class="sg-comment-author"><?php echo get_comment_author_link( $comment ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<a class="sg-comment-date" href="<?php echo esc_url( get_comment_link( $comment ) ); ?>">
						<time datetime="<?php echo esc_attr( get_comment_time( 'c', false, true, $comment ) ); ?>">
							<?php echo esc_html( get_comment_date( '', $comment ) . ' ' . get_comment_time( '', false, true, $comment ) ); ?>
						</time>
					</a>
					<?php if ( '0' === (string) $comment->comment_approved ) : ?>
						<span class="sg-comment-pending"><?php esc_html_e( '待审核', 'steamgrid' ); ?></span>
					<?php endif; ?>
				</div>
				<div class="sg-comment-content"><?php comment_text( $comment ); ?></div>
				<div class="sg-comment-actions">
					<?php
					comment_reply_link(
						array_merge(
							$args,
							array(
								'add_below'  => 'div-comment',
								'depth'      => $depth,
								'max_depth'  => $args['max_depth'],
								'reply_text' => __( '回复', 'steamgrid' ),
							)
						),
						$comment
					);
					edit_comment_link( __( '编辑', 'steamgrid' ), ' <span class="sg-comment-edit">', '</span>' );
					?>
				</div>
			</div>
		</div>
	<?php
}
