<?php
/**
 * 广告位输出
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 输出广告位
 *
 * @param string $slot 位置：header|home_top|home_bottom|sidebar_top|sidebar_bottom|article_top|article_bottom|footer|float。
 */
function sg_ad( $slot ) {
	$html = (string) sg_get( 'ad_' . $slot );
	if ( ! $html ) {
		return;
	}

	echo '<div class="sg-ad-wrap sg-ad-' . esc_attr( $slot ) . '">';
	echo do_shortcode( $html ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '</div>';
}

/**
 * 悬浮广告
 */
function sg_ad_float() {
	$html = (string) sg_get( 'ad_float' );
	if ( ! $html ) {
		return;
	}
	?>
	<div class="sg-ad-wrap sg-ad-float" data-sg-float-ad>
		<button type="button" class="sg-ad-close" aria-label="<?php esc_attr_e( '关闭广告', 'steamgrid' ); ?>">×</button>
		<?php echo do_shortcode( $html ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</div>
	<?php
}
