<?php
/**
 * 登录安全：失败次数限制、错误提示、XML-RPC 与版本隐藏
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 客户端 IP
 *
 * @return string
 */
function sg_client_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
}

/**
 * 失败计数 key
 *
 * @return string
 */
function sg_login_fail_key() {
	return 'sg_login_fail_' . md5( sg_client_ip() );
}

/**
 * 失败次数
 *
 * @return int
 */
function sg_login_fail_count() {
	return (int) get_transient( sg_login_fail_key() );
}

/**
 * 认证前检查是否已锁定
 *
 * @param null|WP_User|WP_Error $user 用户。
 * @return null|WP_User|WP_Error
 */
function sg_login_lockout_check( $user ) {
	if ( ! sg_on( 'login_limit' ) ) {
		return $user;
	}
	if ( ! isset( $_POST['log'] ) ) {
		return $user;
	}

	$limit = max( 1, absint( sg_get( 'login_limit_count', 5 ) ) );
	$count = sg_login_fail_count();

	if ( $count >= $limit ) {
		$minutes = max( 1, absint( sg_get( 'login_lock_minutes', 15 ) ) );
		return new WP_Error(
			'sg_login_locked',
			sprintf(
				/* translators: %d: 分钟数 */
				esc_html__( '登录失败次数过多，请 %d 分钟后再试。', 'steamgrid' ),
				$minutes
			)
		);
	}

	return $user;
}
add_filter( 'authenticate', 'sg_login_lockout_check', 5, 1 );

/**
 * 记录登录失败
 */
function sg_record_login_failure() {
	if ( ! sg_on( 'login_limit' ) ) {
		return;
	}

	$key     = sg_login_fail_key();
	$count   = (int) get_transient( $key );
	$minutes = max( 1, absint( sg_get( 'login_lock_minutes', 15 ) ) );

	set_transient( $key, $count + 1, $minutes * MINUTE_IN_SECONDS );
}
add_action( 'wp_login_failed', 'sg_record_login_failure' );

/**
 * 登录成功后清空计数
 *
 * @param string  $user_login 用户名。
 * @param WP_User $user       用户。
 */
function sg_clear_login_failures( $user_login, $user ) {
	delete_transient( sg_login_fail_key() );
}
add_action( 'wp_login', 'sg_clear_login_failures', 10, 2 );

/**
 * 登录错误提示（避免暴露用户名是否存在）
 *
 * @param string $error 原始提示。
 * @return string
 */
function sg_login_error_message( $error ) {
	$custom = sg_get( 'login_error_msg' );
	if ( $custom ) {
		return esc_html( $custom );
	}
	return $error;
}
add_filter( 'login_errors', 'sg_login_error_message' );

/**
 * 关闭 XML-RPC
 */
function sg_disable_xmlrpc( $enabled ) {
	return sg_on( 'opt_xmlrpc' ) ? false : $enabled;
}
add_filter( 'xmlrpc_enabled', 'sg_disable_xmlrpc' );

/**
 * 移除 XML-RPC 方法
 *
 * @param array $methods 方法列表。
 * @return array
 */
function sg_xmlrpc_methods( $methods ) {
	if ( sg_on( 'opt_xmlrpc' ) ) {
		unset( $methods['pingback.ping'] );
		unset( $methods['pingback.extensions.getPingbacks'] );
		unset( $methods['wp.getUsersBlogs'] );
		unset( $methods['system.multicall'] );
	}
	return $methods;
}
add_filter( 'xmlrpc_methods', 'sg_xmlrpc_methods' );

/**
 * 阻止 ?author=N 用户枚举
 */
function sg_block_author_enumeration() {
	if ( is_admin() || is_user_logged_in() ) {
		return;
	}
	if ( isset( $_GET['author'] ) || isset( $_GET['author_name'] ) ) {
		wp_safe_redirect( home_url( '/' ), 301 );
		exit;
	}
}
add_action( 'template_redirect', 'sg_block_author_enumeration', 1 );

/**
 * 移除 RSD / wlwmanifest / 短链接 / 版本号
 */
function sg_clean_head() {
	if ( sg_on( 'opt_head_links' ) ) {
		remove_action( 'wp_head', 'rsd_link' );
		remove_action( 'wp_head', 'wlwmanifest_link' );
		remove_action( 'wp_head', 'wp_shortlink_wp_head' );
		remove_action( 'wp_head', 'wp_generator' );
		remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10 );
		remove_action( 'wp_head', 'index_rel_link' );
		remove_action( 'wp_head', 'start_post_rel_link' );
		remove_action( 'wp_head', 'parent_post_rel_link' );
	}
	if ( sg_on( 'opt_version' ) ) {
		remove_action( 'wp_head', 'wp_generator' );
		remove_filter( 'the_generator', '__return_empty_string' );
		add_filter( 'the_generator', '__return_empty_string' );
	}
}
add_action( 'init', 'sg_clean_head' );

/**
 * 移除静态资源版本参数
 *
 * @param string $src 资源地址。
 * @return string
 */
function sg_remove_ver_query( $src ) {
	if ( sg_on( 'opt_version' ) && $src ) {
		$src = remove_query_arg( 'ver', $src );
	}
	return $src;
}
add_filter( 'script_loader_src', 'sg_remove_ver_query', 15 );
add_filter( 'style_loader_src', 'sg_remove_ver_query', 15 );
