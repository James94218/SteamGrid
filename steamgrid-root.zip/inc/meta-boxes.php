<?php
/**
 * 文章卡片图片、跳转链接、SEO 描述与目录开关
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function sg_add_card_meta_box() {
	add_meta_box(
		'sg-card-settings',
		__( '文章设置（SteamGrid）', 'steamgrid' ),
		'sg_card_meta_box_html',
		array( 'post', 'page' ),
		'side',
		'default'
	);
}
add_action( 'add_meta_boxes', 'sg_add_card_meta_box' );

function sg_card_meta_box_html( $post ) {
	wp_nonce_field( 'sg_card_meta', 'sg_card_meta_nonce' );

	$image  = get_post_meta( $post->ID, '_sg_card_image', true );
	$link   = get_post_meta( $post->ID, '_sg_card_link', true );
	$seo    = get_post_meta( $post->ID, '_sg_seo_desc', true );
	$no_toc = get_post_meta( $post->ID, '_sg_toc_disable', true );
	?>
	<p>
		<label for="sg-card-image"><strong><?php esc_html_e( '卡片图片', 'steamgrid' ); ?></strong></label>
		<input type="url" id="sg-card-image" name="sg_card_image" class="widefat sg-card-image-url" value="<?php echo esc_url( $image ); ?>" placeholder="https://…" />
		<span class="description"><?php esc_html_e( '填写图片链接或从媒体库选择；留空使用特色图片。', 'steamgrid' ); ?></span>
	</p>
	<p>
		<button type="button" class="button sg-media-select"><?php esc_html_e( '从媒体库选择', 'steamgrid' ); ?></button>
		<button type="button" class="button sg-media-clear"><?php esc_html_e( '清除', 'steamgrid' ); ?></button>
	</p>
	<p>
		<label for="sg-card-link"><strong><?php esc_html_e( '自定义跳转链接', 'steamgrid' ); ?></strong></label>
		<input type="url" id="sg-card-link" name="sg_card_link" class="widefat" value="<?php echo esc_url( $link ); ?>" placeholder="https://…" />
		<span class="description"><?php esc_html_e( '留空跳转到文章页面。', 'steamgrid' ); ?></span>
	</p>
	<p>
		<label for="sg-seo-desc"><strong><?php esc_html_e( 'SEO 描述', 'steamgrid' ); ?></strong></label>
		<textarea id="sg-seo-desc" name="sg_seo_desc" class="widefat" rows="3"><?php echo esc_textarea( $seo ); ?></textarea>
	</p>
	<p>
		<label>
			<input type="checkbox" name="sg_toc_disable" value="1" <?php checked( $no_toc, '1' ); ?> />
			<?php esc_html_e( '本文不生成目录', 'steamgrid' ); ?>
		</label>
	</p>
	<?php
}

function sg_save_card_meta( $post_id ) {
	if ( ! isset( $_POST['sg_card_meta_nonce'] ) || ! wp_verify_nonce( $_POST['sg_card_meta_nonce'], 'sg_card_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$fields = array(
		'_sg_card_image' => 'esc_url_raw',
		'_sg_card_link'  => 'esc_url_raw',
		'_sg_seo_desc'   => 'sanitize_textarea_field',
	);

	foreach ( $fields as $meta_key => $sanitize ) {
		$field = substr( $meta_key, 1 );
		if ( isset( $_POST[ $field ] ) ) {
			update_post_meta( $post_id, $meta_key, call_user_func( $sanitize, wp_unslash( $_POST[ $field ] ) ) );
		}
	}

	if ( isset( $_POST['sg_toc_disable'] ) ) {
		update_post_meta( $post_id, '_sg_toc_disable', '1' );
	} else {
		delete_post_meta( $post_id, '_sg_toc_disable' );
	}
}
add_action( 'save_post', 'sg_save_card_meta' );

/* ------------------------------------------------------------
 * 读取辅助
 * ---------------------------------------------------------- */
function sg_card_image_url( $post_id = 0 ) {
	$post_id = $post_id ? (int) $post_id : get_the_ID();
	$meta    = get_post_meta( $post_id, '_sg_card_image', true );

	if ( $meta ) {
		return $meta;
	}

	if ( has_post_thumbnail( $post_id ) ) {
		if ( sg_on( 'thumb_enable' ) ) {
			$thumb = sg_thumb_url( $post_id, 480, 270 );
			if ( $thumb ) {
				return $thumb;
			}
		}
		return (string) get_the_post_thumbnail_url( $post_id, 'sg-card' );
	}

	return '';
}

function sg_card_link_url( $post_id = 0 ) {
	$post_id = $post_id ? (int) $post_id : get_the_ID();
	$meta    = get_post_meta( $post_id, '_sg_card_link', true );

	return $meta ? $meta : get_permalink( $post_id );
}
