<?php
/**
 * 前台用户系统：登录 / 注册 / 找回密码 / 邮箱验证 / 用户中心
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ------------------------------------------------------------
 * 页面与消息
 * ---------------------------------------------------------- */
function sg_auth_templates() {
	return array(
		'page-templates/login.php',
		'page-templates/register.php',
		'page-templates/lost-password.php',
		'page-templates/user-center.php',
	);
}

/**
 * 用户中心必须登录
 */
function sg_require_login_user_center() {
	if ( is_page_template( 'page-templates/user-center.php' ) && ! is_user_logged_in() ) {
		wp_safe_redirect( add_query_arg( 'redirect_to', rawurlencode( get_permalink() ), sg_auth_url( 'login' ) ) );
		exit;
	}
}
add_action( 'template_redirect', 'sg_require_login_user_center', 3 );

function sg_maybe_create_auth_pages() {
	if ( ! get_option( 'steamgrid_pages' ) ) {
		sg_create_auth_pages();
	}
}
add_action( 'admin_init', 'sg_maybe_create_auth_pages', 30 );

/**
 * 带提示信息的跳转
 *
 * @param string $page   login|register|lostpass|user_center。
 * @param string $code   消息代码。
 * @param string $detail 详细提示。
 */
function sg_redirect_with_msg( $page, $code, $detail = '' ) {
	$args = array( 'sg_msg' => $code );

	if ( $detail ) {
		$key = wp_generate_password( 16, false, false );
		set_transient( 'sg_msg_' . $key, $detail, 5 * MINUTE_IN_SECONDS );
		$args['sg_key'] = $key;
	}

	wp_safe_redirect( add_query_arg( $args, sg_auth_url( $page ) ) );
	exit;
}

/**
 * 读取提示信息
 *
 * @return array
 */
function sg_get_auth_message() {
	$code = isset( $_GET['sg_msg'] ) ? sanitize_key( wp_unslash( $_GET['sg_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( ! $code ) {
		return array(
			'type' => '',
			'text' => '',
		);
	}

	$detail = '';
	if ( ! empty( $_GET['sg_key'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$key    = sanitize_text_field( wp_unslash( $_GET['sg_key'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$detail = (string) get_transient( 'sg_msg_' . $key );
		delete_transient( 'sg_msg_' . $key );
	}

	$map = array(
		'registered'      => array( 'success', __( '注册成功，请登录。', 'steamgrid' ) ),
		'verify_sent'     => array( 'success', __( '注册成功，请查收邮箱中的验证链接后再登录。', 'steamgrid' ) ),
		'verified'        => array( 'success', __( '邮箱验证成功，请登录。', 'steamgrid' ) ),
		'verify_invalid'  => array( 'error', __( '验证链接无效或已过期，请重新注册或联系管理员。', 'steamgrid' ) ),
		'unverified'      => array( 'error', __( '该账号尚未验证邮箱，请先完成邮箱验证。', 'steamgrid' ) ),
		'failed'          => array( 'error', __( '登录失败，请检查用户名和密码。', 'steamgrid' ) ),
		'captcha'         => array( 'error', __( '验证码错误，请重试。', 'steamgrid' ) ),
		'mail_sent'       => array( 'success', __( '重置密码邮件已发送，请查收。', 'steamgrid' ) ),
		'mail_failed'     => array( 'error', __( '重置密码邮件发送失败，请稍后再试。', 'steamgrid' ) ),
		'profile_saved'   => array( 'success', __( '资料已保存。', 'steamgrid' ) ),
		'need_login'      => array( 'error', __( '请先登录。', 'steamgrid' ) ),
		'disabled'        => array( 'error', __( '该功能暂未开启。', 'steamgrid' ) ),
		'user_exists'     => array( 'error', __( '用户名已存在，请更换。', 'steamgrid' ) ),
		'email_exists'    => array( 'error', __( '该邮箱已被注册。', 'steamgrid' ) ),
		'password_short'  => array( 'error', __( '密码至少需要 6 位。', 'steamgrid' ) ),
		'password_mismatch' => array( 'error', __( '两次输入的密码不一致。', 'steamgrid' ) ),
		'invalid_input'   => array( 'error', __( '请完整填写信息。', 'steamgrid' ) ),
		'nonce'           => array( 'error', __( '页面已过期，请重试。', 'steamgrid' ) ),
	);

	$message = isset( $map[ $code ] ) ? $map[ $code ] : array( 'error', __( '操作失败，请重试。', 'steamgrid' ) );

	if ( $detail ) {
		$message[1] = $detail;
	}

	return array(
		'type' => $message[0],
		'text' => $message[1],
	);
}

/* ------------------------------------------------------------
 * 已登录用户访问登录页时跳转
 * ---------------------------------------------------------- */
function sg_auth_redirect_logged_in() {
	if ( ! is_user_logged_in() ) {
		return;
	}
	if ( is_page_template( array( 'page-templates/login.php', 'page-templates/register.php', 'page-templates/lost-password.php' ) ) ) {
		wp_safe_redirect( sg_auth_url( 'user_center' ) );
		exit;
	}
}
add_action( 'template_redirect', 'sg_auth_redirect_logged_in', 4 );

/* ------------------------------------------------------------
 * 处理表单
 * ---------------------------------------------------------- */
function sg_handle_auth_actions() {
	if ( 'POST' !== strtoupper( isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '' ) ) {
		return;
	}

	if ( ! is_page_template( sg_auth_templates() ) ) {
		return;
	}

	$action = isset( $_POST['sg_action'] ) ? sanitize_key( wp_unslash( $_POST['sg_action'] ) ) : '';
	if ( ! $action ) {
		return;
	}

	if ( ! isset( $_POST['sg_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['sg_nonce'] ) ), 'sg_auth' ) ) {
		sg_redirect_with_msg( 'login', 'nonce' );
	}

	switch ( $action ) {
		case 'login':
			sg_handle_login();
			break;
		case 'register':
			sg_handle_register();
			break;
		case 'lostpass':
			sg_handle_lostpass();
			break;
		case 'profile':
			sg_handle_profile();
			break;
		case 'password':
			sg_handle_password();
			break;
	}
}
add_action( 'template_redirect', 'sg_handle_auth_actions', 5 );

function sg_handle_login() {
	if ( ! sg_on( 'auth_enable' ) ) {
		sg_redirect_with_msg( 'login', 'disabled' );
	}

	$username = isset( $_POST['log'] ) ? sanitize_user( wp_unslash( $_POST['log'] ) ) : '';
	$password = isset( $_POST['pwd'] ) ? (string) wp_unslash( $_POST['pwd'] ) : '';
	$remember = ! empty( $_POST['remember'] );

	$captcha = sg_captcha_validate( 'login' );
	if ( is_wp_error( $captcha ) ) {
		sg_redirect_with_msg( 'login', 'captcha', $captcha->get_error_message() );
	}

	if ( ! $username || ! $password ) {
		sg_redirect_with_msg( 'login', 'failed' );
	}

	$user = wp_signon(
		array(
			'user_login'    => $username,
			'user_password' => $password,
			'remember'      => $remember,
		),
		is_ssl()
	);

	if ( is_wp_error( $user ) ) {
		sg_redirect_with_msg( 'login', 'failed', wp_strip_all_tags( $user->get_error_message() ) );
	}

	if ( sg_on( 'email_verify' ) && '1' === (string) get_user_meta( $user->ID, '_sg_email_required', true ) && '1' !== (string) get_user_meta( $user->ID, '_sg_email_verified', true ) ) {
		wp_logout();
		sg_redirect_with_msg( 'login', 'unverified' );
	}

	$redirect = sg_get( 'login_redirect' );
	if ( ! $redirect ) {
		$redirect = sg_auth_url( 'user_center' );
	}

	wp_safe_redirect( $redirect );
	exit;
}

function sg_handle_register() {
	if ( ! sg_on( 'auth_enable' ) || ! sg_on( 'register_enable' ) ) {
		sg_redirect_with_msg( 'register', 'disabled' );
	}

	$captcha = sg_captcha_validate( 'register' );
	if ( is_wp_error( $captcha ) ) {
		sg_redirect_with_msg( 'register', 'captcha', $captcha->get_error_message() );
	}

	$username = isset( $_POST['user_login'] ) ? sanitize_user( wp_unslash( $_POST['user_login'] ), true ) : '';
	$email    = isset( $_POST['user_email'] ) ? sanitize_email( wp_unslash( $_POST['user_email'] ) ) : '';
	$pass     = isset( $_POST['user_pass'] ) ? (string) wp_unslash( $_POST['user_pass'] ) : '';
	$pass2    = isset( $_POST['user_pass2'] ) ? (string) wp_unslash( $_POST['user_pass2'] ) : '';

	if ( ! $username || ! $email || ! $pass ) {
		sg_redirect_with_msg( 'register', 'invalid_input' );
	}
	if ( ! is_email( $email ) ) {
		sg_redirect_with_msg( 'register', 'invalid_input', __( '邮箱格式不正确。', 'steamgrid' ) );
	}
	if ( strlen( $pass ) < 6 ) {
		sg_redirect_with_msg( 'register', 'password_short' );
	}
	if ( $pass !== $pass2 ) {
		sg_redirect_with_msg( 'register', 'password_mismatch' );
	}
	if ( username_exists( $username ) ) {
		sg_redirect_with_msg( 'register', 'user_exists' );
	}
	if ( email_exists( $email ) ) {
		sg_redirect_with_msg( 'register', 'email_exists' );
	}

	$user_id = wp_create_user( $username, $pass, $email );
	if ( is_wp_error( $user_id ) ) {
		sg_redirect_with_msg( 'register', 'failed', wp_strip_all_tags( $user_id->get_error_message() ) );
	}

	wp_update_user(
		array(
			'ID'           => $user_id,
			'display_name' => $username,
			'nickname'     => $username,
			'role'         => 'subscriber',
		)
	);

	if ( sg_on( 'email_verify' ) ) {
		update_user_meta( $user_id, '_sg_email_required', '1' );
		update_user_meta( $user_id, '_sg_email_verified', '0' );

		$token = wp_generate_password( 40, false, false );
		update_user_meta( $user_id, '_sg_verify_token', wp_hash_password( $token ) );

		$link = add_query_arg(
			array(
				'sg_verify_uid'   => $user_id,
				'sg_verify_token' => rawurlencode( $token ),
			),
			home_url( '/' )
		);

		$subject = '[' . get_bloginfo( 'name' ) . '] ' . __( '请验证您的邮箱', 'steamgrid' );
		$message = '您好，' . $username . "：\n\n"
			. '感谢注册 ' . get_bloginfo( 'name' ) . "，请点击以下链接完成邮箱验证：\n"
			. $link . "\n\n"
			. "链接 24 小时内有效，若非本人操作请忽略此邮件。\n";

		wp_mail( $email, $subject, $message );

		sg_redirect_with_msg( 'login', 'verify_sent' );
	}

	update_user_meta( $user_id, '_sg_email_verified', '1' );
	sg_redirect_with_msg( 'login', 'registered' );
}

function sg_handle_lostpass() {
	if ( ! sg_on( 'auth_enable' ) ) {
		sg_redirect_with_msg( 'lostpass', 'disabled' );
	}

	$login = isset( $_POST['user_login'] ) ? sanitize_text_field( wp_unslash( $_POST['user_login'] ) ) : '';
	if ( ! $login ) {
		sg_redirect_with_msg( 'lostpass', 'invalid_input' );
	}

	$result = retrieve_password( $login );

	if ( is_wp_error( $result ) ) {
		sg_redirect_with_msg( 'lostpass', 'mail_failed', wp_strip_all_tags( $result->get_error_message() ) );
	}

	if ( true !== $result ) {
		sg_redirect_with_msg( 'lostpass', 'mail_failed' );
	}

	sg_redirect_with_msg( 'lostpass', 'mail_sent' );
}

function sg_handle_profile() {
	if ( ! is_user_logged_in() ) {
		sg_redirect_with_msg( 'login', 'need_login' );
	}

	$user_id = get_current_user_id();

	$display_name = isset( $_POST['display_name'] ) ? sanitize_text_field( wp_unslash( $_POST['display_name'] ) ) : '';
	$description  = isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : '';
	$user_url     = isset( $_POST['user_url'] ) ? esc_url_raw( wp_unslash( $_POST['user_url'] ) ) : '';

	$args = array(
		'ID'          => $user_id,
		'description' => $description,
		'user_url'    => $user_url,
	);

	if ( $display_name ) {
		$args['display_name'] = $display_name;
	}

	wp_update_user( $args );

	if ( ! empty( $_FILES['sg_avatar']['name'] ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$attachment_id = media_handle_upload( 'sg_avatar', 0 );
		if ( ! is_wp_error( $attachment_id ) ) {
			update_user_meta( $user_id, '_sg_avatar', (int) $attachment_id );
		}
	}

	sg_redirect_with_msg( 'user_center', 'profile_saved' );
}

function sg_handle_password() {
	if ( ! is_user_logged_in() ) {
		sg_redirect_with_msg( 'login', 'need_login' );
	}

	$user_id  = get_current_user_id();
	$user     = get_userdata( $user_id );
	$current  = isset( $_POST['current_password'] ) ? (string) wp_unslash( $_POST['current_password'] ) : '';
	$new      = isset( $_POST['new_password'] ) ? (string) wp_unslash( $_POST['new_password'] ) : '';
	$confirm  = isset( $_POST['confirm_password'] ) ? (string) wp_unslash( $_POST['confirm_password'] ) : '';

	if ( ! $user || ! wp_check_password( $current, $user->user_pass, $user_id ) ) {
		sg_redirect_with_msg( 'user_center', 'password_mismatch', __( '当前密码不正确。', 'steamgrid' ) );
	}
	if ( strlen( $new ) < 6 ) {
		sg_redirect_with_msg( 'user_center', 'password_short' );
	}
	if ( $new !== $confirm ) {
		sg_redirect_with_msg( 'user_center', 'password_mismatch' );
	}

	wp_set_password( $new, $user_id );
	wp_set_auth_cookie( $user_id, true, is_ssl() );

	sg_redirect_with_msg( 'user_center', 'profile_saved' );
}

/* ------------------------------------------------------------
 * 邮箱验证
 * ---------------------------------------------------------- */
function sg_handle_email_verify() {
	if ( ! isset( $_GET['sg_verify_uid'], $_GET['sg_verify_token'] ) ) {
		return;
	}

	$user_id = absint( $_GET['sg_verify_uid'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$token   = sanitize_text_field( wp_unslash( $_GET['sg_verify_token'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

	$hash = $user_id ? get_user_meta( $user_id, '_sg_verify_token', true ) : '';

	if ( ! $user_id || ! $hash ) {
		sg_redirect_with_msg( 'login', 'verify_invalid' );
	}

	if ( ! wp_check_password( $token, $hash, $user_id ) ) {
		sg_redirect_with_msg( 'login', 'verify_invalid' );
	}

	update_user_meta( $user_id, '_sg_email_verified', '1' );
	delete_user_meta( $user_id, '_sg_verify_token' );

	sg_redirect_with_msg( 'login', 'verified' );
}
add_action( 'template_redirect', 'sg_handle_email_verify', 2 );

/**
 * 当前用户头像 URL
 *
 * @param int $user_id 用户 ID。
 * @param int $size    尺寸。
 * @return string
 */
function sg_user_avatar_url( $user_id = 0, $size = 96 ) {
	$user_id = $user_id ? (int) $user_id : get_current_user_id();
	if ( ! $user_id ) {
		return '';
	}

	$attachment_id = (int) get_user_meta( $user_id, '_sg_avatar', true );
	if ( $attachment_id ) {
		$url = wp_get_attachment_image_url( $attachment_id, array( $size, $size ) );
		if ( $url ) {
			return $url;
		}
	}

	return (string) get_avatar_url( $user_id, array( 'size' => $size ) );
}

/**
 * 用户中心 tab 地址
 *
 * @param string $tab 标签。
 * @return string
 */
function sg_user_center_tab_url( $tab = '' ) {
	$url = sg_auth_url( 'user_center' );
	return $tab ? add_query_arg( 'tab', $tab, $url ) : $url;
}
