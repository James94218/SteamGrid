<?php
/**
 * 验证码：内置图形验证码（SVG，无 GD 依赖）与极验 v4
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 判断某场景是否启用验证码
 *
 * @param string $context comment|login|register。
 * @return bool
 */
function sg_captcha_enabled( $context = 'comment' ) {
	$mode = sg_get( 'captcha_mode', 'svg' );
	if ( 'off' === $mode ) {
		return false;
	}

	$toggles = array(
		'comment'  => 'comment_captcha',
		'login'    => 'login_captcha',
		'register' => 'register_captcha',
	);

	if ( ! isset( $toggles[ $context ] ) || ! sg_on( $toggles[ $context ] ) ) {
		return false;
	}

	if ( 'geetest' === $mode && ( ! sg_get( 'geetest_id' ) || ! sg_get( 'geetest_key' ) ) ) {
		// 未配置极验密钥时自动降级为图形验证码。
		return true;
	}

	return true;
}

/**
 * 当前是否使用极验
 *
 * @return bool
 */
function sg_use_geetest() {
	return 'geetest' === sg_get( 'captcha_mode' ) && sg_get( 'geetest_id' ) && sg_get( 'geetest_key' );
}

/**
 * 加密密钥
 *
 * @return string
 */
function sg_captcha_key() {
	return hash( 'sha256', wp_salt( 'auth' ) . '|steamgrid-captcha', true );
}

/**
 * 加密验证码答案
 *
 * @param string $plain 答案。
 * @return string
 */
function sg_captcha_encrypt( $plain ) {
	if ( ! function_exists( 'openssl_encrypt' ) ) {
		return '';
	}

	$iv = '';
	try {
		$iv = random_bytes( 16 );
	} catch ( Exception $e ) {
		return '';
	}

	$cipher = openssl_encrypt( $plain, 'aes-256-cbc', sg_captcha_key(), OPENSSL_RAW_DATA, $iv );
	if ( false === $cipher ) {
		return '';
	}

	return rtrim( strtr( base64_encode( $iv . $cipher ), '+/', '-_' ), '=' );
}

/**
 * 解密
 *
 * @param string $token 令牌。
 * @return string
 */
function sg_captcha_decrypt( $token ) {
	if ( ! function_exists( 'openssl_decrypt' ) ) {
		return '';
	}

	$token = strtr( (string) $token, '-_', '+/' );
	$pad   = strlen( $token ) % 4;
	if ( $pad ) {
		$token .= str_repeat( '=', 4 - $pad );
	}

	$raw = base64_decode( $token, true );
	if ( false === $raw || strlen( $raw ) <= 16 ) {
		return '';
	}

	$iv     = substr( $raw, 0, 16 );
	$cipher = substr( $raw, 16 );
	$plain  = openssl_decrypt( $cipher, 'aes-256-cbc', sg_captcha_key(), OPENSSL_RAW_DATA, $iv );

	return false === $plain ? '' : (string) $plain;
}

/**
 * 生成一组验证码
 *
 * @return array
 */
function sg_captcha_new() {
	$alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
	$answer   = '';
	for ( $i = 0; $i < 4; $i++ ) {
		$answer .= $alphabet[ wp_rand( 0, strlen( $alphabet ) - 1 ) ];
	}

	$token = sg_captcha_encrypt( $answer );
	if ( '' === $token ) {
		$token = wp_generate_password( 24, false, false );
		set_transient( 'sg_cap_' . $token, strtoupper( $answer ), 10 * MINUTE_IN_SECONDS );
	}

	return array(
		'answer' => $answer,
		'token'  => $token,
	);
}

/**
 * 生成 SVG 验证码（data URI）
 *
 * @param string $answer 答案字符。
 * @return string
 */
function sg_captcha_svg( $answer ) {
	$width   = 132;
	$height  = 44;
	$colors  = array( '#66c0f4', '#a4d007', '#f5b942', '#ff7b72', '#c9a7ff', '#7ee2c4' );
	$svg     = '<svg xmlns="http://www.w3.org/2000/svg" width="' . $width . '" height="' . $height . '" viewBox="0 0 ' . $width . ' ' . $height . '">';
	$svg    .= '<rect width="' . $width . '" height="' . $height . '" rx="6" fill="#0f161f"/>';

	for ( $i = 0; $i < 7; $i++ ) {
		$x1 = wp_rand( 0, $width );
		$y1 = wp_rand( 0, $height );
		$x2 = wp_rand( 0, $width );
		$y2 = wp_rand( 0, $height );
		$color = $colors[ wp_rand( 0, count( $colors ) - 1 ) ];
		$opacity = wp_rand( 10, 35 ) / 100;
		$svg .= '<line x1="' . $x1 . '" y1="' . $y1 . '" x2="' . $x2 . '" y2="' . $y2 . '" stroke="' . $color . '" stroke-width="1.3" opacity="' . $opacity . '"/>';
	}

	for ( $i = 0; $i < 26; $i++ ) {
		$svg .= '<circle cx="' . wp_rand( 0, $width ) . '" cy="' . wp_rand( 0, $height ) . '" r="1" fill="#66c0f4" opacity="' . ( wp_rand( 10, 40 ) / 100 ) . '"/>';
	}

	$length = strlen( $answer );
	for ( $i = 0; $i < $length; $i++ ) {
		$char  = $answer[ $i ];
		$color = $colors[ wp_rand( 0, count( $colors ) - 1 ) ];
		$x     = 16 + $i * 26 + wp_rand( -3, 3 );
		$y     = 30 + wp_rand( -3, 3 );
		$angle = wp_rand( -16, 16 );
		$size  = wp_rand( 20, 25 );
		$svg  .= '<text x="' . $x . '" y="' . $y . '" fill="' . $color . '" font-family="Georgia, serif" font-weight="700" font-size="' . $size . '" transform="rotate(' . $angle . ' ' . $x . ' ' . $y . ')">' . esc_html( $char ) . '</text>';
	}

	$svg .= '</svg>';

	return 'data:image/svg+xml;base64,' . base64_encode( $svg );
}

/**
 * 校验验证码答案
 *
 * @param string $input 用户输入。
 * @param string $token 令牌。
 * @return bool
 */
function sg_captcha_check( $input, $token ) {
	$input = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $input ) );
	if ( '' === $input || '' === $token ) {
		return false;
	}

	$answer = sg_captcha_decrypt( $token );
	if ( '' === $answer ) {
		$transient = 'sg_cap_' . $token;
		$answer    = (string) get_transient( $transient );
		delete_transient( $transient );
	}

	return '' !== $answer && hash_equals( strtoupper( $answer ), $input );
}

/**
 * 输出验证码字段
 *
 * @param string $context 场景。
 * @return string
 */
function sg_captcha_field( $context = 'comment' ) {
	if ( ! sg_captcha_enabled( $context ) ) {
		return '';
	}

	if ( sg_use_geetest() ) {
		return '<div class="sg-captcha sg-captcha-geetest" data-sg-geetest="1" data-context="' . esc_attr( $context ) . '">'
			. '<div class="sg-geetest-box"></div>'
			. '<input type="hidden" name="sg_geetest_lot" value="" />'
			. '<input type="hidden" name="sg_geetest_output" value="" />'
			. '<input type="hidden" name="sg_geetest_pass" value="" />'
			. '<input type="hidden" name="sg_geetest_gen" value="" />'
			. '</div>';
	}

	$captcha = sg_captcha_new();

	return '<div class="sg-captcha sg-captcha-svg" data-context="' . esc_attr( $context ) . '">'
		. '<label for="sg-captcha-' . esc_attr( $context ) . '">' . esc_html__( '验证码', 'steamgrid' ) . ' <span class="required">*</span></label>'
		. '<div class="sg-captcha-row">'
		. '<img class="sg-captcha-img" src="' . esc_attr( sg_captcha_svg( $captcha['answer'] ) ) . '" alt="' . esc_attr__( '验证码图片', 'steamgrid' ) . '" width="132" height="44" />'
		. '<button type="button" class="sg-captcha-refresh" data-sg-captcha-refresh="1">' . esc_html__( '换一张', 'steamgrid' ) . '</button>'
		. '<input type="hidden" name="sg_captcha_token" value="' . esc_attr( $captcha['token'] ) . '" />'
		. '<input id="sg-captcha-' . esc_attr( $context ) . '" class="sg-captcha-input" type="text" name="sg_captcha" size="6" required autocomplete="off" inputmode="text" placeholder="' . esc_attr__( '输入图中字符', 'steamgrid' ) . '" />'
		. '</div></div>';
}

/**
 * 校验当前请求的验证码
 *
 * @param string $context 场景。
 * @return true|WP_Error
 */
function sg_captcha_validate( $context = 'comment' ) {
	if ( ! sg_captcha_enabled( $context ) ) {
		return true;
	}

	if ( sg_use_geetest() ) {
		$lot    = isset( $_POST['sg_geetest_lot'] ) ? sanitize_text_field( wp_unslash( $_POST['sg_geetest_lot'] ) ) : '';
		$output = isset( $_POST['sg_geetest_output'] ) ? sanitize_text_field( wp_unslash( $_POST['sg_geetest_output'] ) ) : '';
		$pass   = isset( $_POST['sg_geetest_pass'] ) ? sanitize_text_field( wp_unslash( $_POST['sg_geetest_pass'] ) ) : '';
		$gen    = isset( $_POST['sg_geetest_gen'] ) ? sanitize_text_field( wp_unslash( $_POST['sg_geetest_gen'] ) ) : '';

		if ( ! $lot || ! $output || ! $pass ) {
			return new WP_Error( 'sg_captcha', __( '请先完成人机验证。', 'steamgrid' ) );
		}

		$id      = sg_get( 'geetest_id' );
		$key     = sg_get( 'geetest_key' );
		$sign    = hash_hmac( 'sha256', $lot, $key );
		$request = add_query_arg(
			array(
				'captcha_id'     => rawurlencode( $id ),
				'lot_number'     => rawurlencode( $lot ),
				'captcha_output' => rawurlencode( $output ),
				'pass_token'     => rawurlencode( $pass ),
				'gen_time'       => rawurlencode( $gen ),
				'sign_token'     => rawurlencode( $sign ),
			),
			'https://gcaptcha4.geetest.com/validate'
		);

		$response = wp_remote_get( $request, array( 'timeout' => 8 ) );
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'sg_captcha', __( '验证码服务暂不可用，请稍后重试。', 'steamgrid' ) );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( is_array( $body ) && isset( $body['result'] ) && 'success' === $body['result'] ) {
			return true;
		}

		return new WP_Error( 'sg_captcha', __( '人机验证失败，请重试。', 'steamgrid' ) );
	}

	$input = isset( $_POST['sg_captcha'] ) ? sanitize_text_field( wp_unslash( $_POST['sg_captcha'] ) ) : '';
	$token = isset( $_POST['sg_captcha_token'] ) ? sanitize_text_field( wp_unslash( $_POST['sg_captcha_token'] ) ) : '';

	if ( sg_captcha_check( $input, $token ) ) {
		return true;
	}

	return new WP_Error( 'sg_captcha', __( '验证码错误，请重新输入。', 'steamgrid' ) );
}

/**
 * 刷新验证码（AJAX，无需登录）
 */
function sg_ajax_captcha_refresh() {
	$captcha = sg_captcha_new();

	wp_send_json_success(
		array(
			'token' => $captcha['token'],
			'img'   => sg_captcha_svg( $captcha['answer'] ),
		)
	);
}
add_action( 'wp_ajax_sg_captcha_refresh', 'sg_ajax_captcha_refresh' );
add_action( 'wp_ajax_nopriv_sg_captcha_refresh', 'sg_ajax_captcha_refresh' );

/**
 * 登录表单验证码
 */
function sg_login_captcha_field() {
	if ( sg_captcha_enabled( 'login' ) ) {
		echo sg_captcha_field( 'login' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
add_action( 'login_form', 'sg_login_captcha_field' );

/**
 * 登录页验证码所需脚本（wp-login.php 不加载主题前端脚本）
 */
function sg_login_captcha_assets() {
	if ( ! sg_captcha_enabled( 'login' ) ) {
		return;
	}

	if ( sg_use_geetest() ) {
		wp_enqueue_script( 'sg-geetest', 'https://static.geetest.com/v4/gt4.js', array(), null, true );
	}

	wp_enqueue_script( 'sg-login-captcha', SG_URI . '/assets/js/login-captcha.js', array(), SG_VERSION, true );
	wp_localize_script(
		'sg-login-captcha',
		'SG_LOGIN_CAPTCHA',
		array(
			'mode'    => sg_get( 'captcha_mode' ),
			'id'      => sg_get( 'geetest_id' ),
			'keySet'  => (bool) ( sg_get( 'geetest_id' ) && sg_get( 'geetest_key' ) ),
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
		)
	);
}
add_action( 'login_enqueue_scripts', 'sg_login_captcha_assets' );

/**
 * 登录时校验验证码
 *
 * @param null|WP_User|WP_Error $user     用户。
 * @param string                $username 用户名。
 * @param string                $password 密码。
 * @return null|WP_User|WP_Error
 */
function sg_login_captcha_check( $user, $username, $password ) {
	if ( ! sg_captcha_enabled( 'login' ) ) {
		return $user;
	}
	if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
		return $user;
	}
	if ( ! isset( $_POST['log'] ) ) {
		return $user;
	}

	$check = sg_captcha_validate( 'login' );
	if ( is_wp_error( $check ) ) {
		return $check;
	}

	return $user;
}
add_filter( 'authenticate', 'sg_login_captcha_check', 25, 3 );
