<?php
/**
 * 短代码集合
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 是否允许输出短代码
 *
 * @return bool
 */
function sg_shortcodes_ready() {
	return sg_on( 'shortcodes_enable' );
}

/* ------------------------------------------------------------
 * 提示框
 * ---------------------------------------------------------- */
function sg_sc_box( $atts, $content = '' ) {
	if ( ! sg_shortcodes_ready() ) {
		return $content;
	}

	$atts = shortcode_atts(
		array(
			'type'  => 'info',
			'title' => '',
		),
		$atts,
		'box'
	);

	$type = in_array( $atts['type'], array( 'info', 'success', 'warning', 'danger', 'tip' ), true ) ? $atts['type'] : 'info';
	$icon = 'tip' === $type ? 'quote' : ( 'danger' === $type ? 'warning' : $type );

	$html  = '<div class="sg-notice sg-notice-' . esc_attr( $type ) . '">';
	$html .= '<span class="sg-notice-icon">' . sg_svg_icon( $icon ) . '</span>';
	$html .= '<div class="sg-notice-body">';
	if ( $atts['title'] ) {
		$html .= '<div class="sg-notice-title">' . esc_html( $atts['title'] ) . '</div>';
	}
	$html .= do_shortcode( wpautop( $content ) );
	$html .= '</div></div>';

	return $html;
}
add_shortcode( 'box', 'sg_sc_box' );

/* ------------------------------------------------------------
 * 下载按钮
 * ---------------------------------------------------------- */
function sg_sc_download( $atts, $content = '' ) {
	if ( ! sg_shortcodes_ready() ) {
		return $content;
	}

	$atts = shortcode_atts(
		array(
			'url'      => '',
			'size'     => '',
			'password' => '',
			'title'    => __( '下载地址', 'steamgrid' ),
			'button'   => __( '立即下载', 'steamgrid' ),
			'blank'    => '1',
		),
		$atts,
		'download'
	);

	if ( ! $atts['url'] ) {
		return '';
	}

	$target = $atts['blank'] ? ' target="_blank" rel="noopener nofollow"' : '';

	$html  = '<div class="sg-download">';
	$html .= '<div class="sg-download-head">' . sg_svg_icon( 'download' );
	$html .= '<span class="sg-download-title">' . esc_html( $atts['title'] ) . '</span>';
	if ( $atts['size'] ) {
		$html .= '<span class="sg-download-size">' . esc_html( $atts['size'] ) . '</span>';
	}
	$html .= '</div>';

	if ( $content ) {
		$html .= '<div class="sg-download-desc">' . do_shortcode( wpautop( $content ) ) . '</div>';
	}

	$html .= '<div class="sg-download-actions">';
	$html .= '<a class="sg-btn sg-download-btn" href="' . esc_url( $atts['url'] ) . '"' . $target . '>' . esc_html( $atts['button'] ) . '</a>';
	if ( $atts['password'] ) {
		$html .= '<span class="sg-download-password">' . esc_html__( '提取码：', 'steamgrid' ) . '<code>' . esc_html( $atts['password'] ) . '</code></span>';
	}
	$html .= '</div></div>';

	return $html;
}
add_shortcode( 'download', 'sg_sc_download' );

/* ------------------------------------------------------------
 * 可见性控制
 * ---------------------------------------------------------- */
function sg_visitor_has_commented() {
	if ( is_user_logged_in() ) {
		return true;
	}
	foreach ( array_keys( $_COOKIE ) as $cookie_name ) {
		if ( 0 === strpos( $cookie_name, 'comment_author_email' ) ) {
			return true;
		}
	}
	return false;
}

function sg_visibility_notice( $text, $link = '' ) {
	$html  = '<div class="sg-locked">';
	$html .= '<span class="sg-locked-icon">' . sg_svg_icon( 'lock' ) . '</span>';
	$html .= '<div class="sg-locked-text">' . esc_html( $text ) . '</div>';
	$html .= '</div>';
	return $html;
}

function sg_sc_reply( $atts, $content = '' ) {
	if ( sg_visitor_has_commented() ) {
		return '<div class="sg-hidden-content">' . do_shortcode( $content ) . '</div>';
	}
	return sg_visibility_notice( __( '此处内容需要评论后才能查看。', 'steamgrid' ) );
}
add_shortcode( 'reply', 'sg_sc_reply' );

function sg_sc_login( $atts, $content = '' ) {
	if ( is_user_logged_in() ) {
		return '<div class="sg-hidden-content">' . do_shortcode( $content ) . '</div>';
	}
	$link = '<a href="' . esc_url( sg_auth_url( 'login' ) ) . '">' . esc_html__( '立即登录', 'steamgrid' ) . '</a>';
	return sg_visibility_notice( sprintf( __( '此处内容需要登录后查看，%s。', 'steamgrid' ), $link ) );
}
add_shortcode( 'login', 'sg_sc_login' );

function sg_sc_guest( $atts, $content = '' ) {
	if ( ! is_user_logged_in() ) {
		return '<div class="sg-hidden-content">' . do_shortcode( $content ) . '</div>';
	}
	return '';
}
add_shortcode( 'guest', 'sg_sc_guest' );

function sg_sc_login_email( $atts, $content = '' ) {
	if ( is_user_logged_in() && sg_is_email_verified() ) {
		return '<div class="sg-hidden-content">' . do_shortcode( $content ) . '</div>';
	}
	if ( is_user_logged_in() ) {
		return sg_visibility_notice( __( '此处内容需要验证邮箱后才能查看。', 'steamgrid' ) );
	}
	$link = '<a href="' . esc_url( sg_auth_url( 'login' ) ) . '">' . esc_html__( '登录', 'steamgrid' ) . '</a> / <a href="' . esc_url( sg_auth_url( 'register' ) ) . '">' . esc_html__( '注册', 'steamgrid' ) . '</a>';
	return sg_visibility_notice( sprintf( __( '此处内容需要登录并验证邮箱后查看，请先%s。', 'steamgrid' ), $link ) );
}
add_shortcode( 'login_email', 'sg_sc_login_email' );

/* ------------------------------------------------------------
 * GitHub 仓库卡片
 * ---------------------------------------------------------- */
function sg_sc_github( $atts ) {
	if ( ! sg_shortcodes_ready() ) {
		return '';
	}

	$atts = shortcode_atts(
		array(
			'repo' => '',
		),
		$atts,
		'github'
	);

	$repo = trim( $atts['repo'] );
	if ( ! preg_match( '#^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$#', $repo ) ) {
		return '';
	}

	$cache_key = 'sg_gh_' . md5( $repo );
	$data      = get_transient( $cache_key );

	if ( false === $data ) {
		$args = array(
			'timeout' => 6,
			'headers' => array(
				'Accept'     => 'application/vnd.github+json',
				'User-Agent' => 'SteamGrid-Theme',
			),
		);

		$token = sg_get( 'github_token' );
		if ( $token ) {
			$args['headers']['Authorization'] = 'Bearer ' . $token;
		}

		$response = wp_remote_get( 'https://api.github.com/repos/' . $repo, $args );
		$data     = array();

		if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
			$json = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( is_array( $json ) ) {
				$data = array(
					'name'  => isset( $json['full_name'] ) ? $json['full_name'] : $repo,
					'desc'  => isset( $json['description'] ) ? (string) $json['description'] : '',
					'stars' => isset( $json['stargazers_count'] ) ? (int) $json['stargazers_count'] : 0,
					'forks' => isset( $json['forks_count'] ) ? (int) $json['forks_count'] : 0,
					'lang'  => isset( $json['language'] ) ? (string) $json['language'] : '',
					'url'   => isset( $json['html_url'] ) ? $json['html_url'] : 'https://github.com/' . $repo,
				);
			}
		}

		set_transient( $cache_key, $data ? $data : array( 'error' => 1 ), 6 * HOUR_IN_SECONDS );
	}

	if ( empty( $data ) || ! empty( $data['error'] ) ) {
		return '<a class="sg-gh-card sg-gh-fallback" href="https://github.com/' . esc_attr( $repo ) . '" target="_blank" rel="noopener nofollow">' . sg_svg_icon( 'github' ) . ' GitHub · ' . esc_html( $repo ) . '</a>';
	}

	$html  = '<a class="sg-gh-card" href="' . esc_url( $data['url'] ) . '" target="_blank" rel="noopener nofollow">';
	$html .= '<span class="sg-gh-icon">' . sg_svg_icon( 'github' ) . '</span>';
	$html .= '<span class="sg-gh-body">';
	$html .= '<span class="sg-gh-name">' . esc_html( $data['name'] ) . '</span>';
	if ( $data['desc'] ) {
		$html .= '<span class="sg-gh-desc">' . esc_html( $data['desc'] ) . '</span>';
	}
	$html .= '<span class="sg-gh-meta">';
	$html .= '<span class="sg-gh-stat">★ ' . esc_html( number_format_i18n( $data['stars'] ) ) . '</span>';
	$html .= '<span class="sg-gh-stat">⑂ ' . esc_html( number_format_i18n( $data['forks'] ) ) . '</span>';
	if ( $data['lang'] ) {
		$html .= '<span class="sg-gh-lang">' . esc_html( $data['lang'] ) . '</span>';
	}
	$html .= '</span></span></a>';

	return $html;
}
add_shortcode( 'github', 'sg_sc_github' );

/* ------------------------------------------------------------
 * DPlayer
 * ---------------------------------------------------------- */
function sg_sc_dplayer( $atts ) {
	if ( ! sg_shortcodes_ready() ) {
		return '';
	}

	$atts = shortcode_atts(
		array(
			'url'    => '',
			'poster' => '',
			'type'   => 'auto',
			'title'  => '',
		),
		$atts,
		'dplayer'
	);

	if ( ! $atts['url'] ) {
		return '';
	}

	return '<div class="sg-dplayer" data-src="' . esc_url( $atts['url'] ) . '" data-poster="' . esc_url( $atts['poster'] ) . '" data-type="' . esc_attr( $atts['type'] ) . '" data-title="' . esc_attr( $atts['title'] ) . '"></div>';
}
add_shortcode( 'dplayer', 'sg_sc_dplayer' );

/* ------------------------------------------------------------
 * 折叠面板
 * ---------------------------------------------------------- */
function sg_sc_collapse( $atts, $content = '' ) {
	$atts = shortcode_atts(
		array(
			'title' => __( '展开查看', 'steamgrid' ),
		),
		$atts,
		'collapse'
	);

	return '<details class="sg-collapse"><summary>' . esc_html( $atts['title'] ) . '</summary><div class="sg-collapse-body">' . do_shortcode( $content ) . '</div></details>';
}
add_shortcode( 'collapse', 'sg_sc_collapse' );

/* ------------------------------------------------------------
 * 目录
 * ---------------------------------------------------------- */
function sg_sc_toc() {
	return sg_get_current_toc();
}
add_shortcode( 'sg_toc', 'sg_sc_toc' );

/* ------------------------------------------------------------
 * 站点名片
 * ---------------------------------------------------------- */
function sg_sc_site_card( $atts ) {
	$atts = shortcode_atts(
		array(
			'avatar' => '',
			'name'   => '',
			'bio'    => '',
			'social' => '1',
		),
		$atts,
		'site_card'
	);

	return sg_site_card_html(
		array(
			'avatar'      => $atts['avatar'] ? esc_url_raw( $atts['avatar'] ) : '',
			'name'        => $atts['name'] ? sanitize_text_field( $atts['name'] ) : '',
			'bio'         => $atts['bio'] ? sanitize_textarea_field( $atts['bio'] ) : '',
			'show_social' => '0' !== (string) $atts['social'],
		)
	);
}
add_shortcode( 'site_card', 'sg_sc_site_card' );
