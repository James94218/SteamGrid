<?php
/**
 * WP 优化策略、HTML 压缩、懒加载、缓存清理联动
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ------------------------------------------------------------
 * 移除 Emoji 脚本
 * ---------------------------------------------------------- */
function sg_disable_emojis() {
	if ( ! sg_on( 'opt_emojis' ) ) {
		return;
	}
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
	add_filter( 'emoji_svg_url', '__return_false' );
}
add_action( 'init', 'sg_disable_emojis' );

/* ------------------------------------------------------------
 * 隐藏前台 WordPress 工具栏
 * ---------------------------------------------------------- */
function sg_hide_admin_bar( $show ) {
	return sg_on( 'hide_admin_bar' ) ? false : $show;
}
add_filter( 'show_admin_bar', 'sg_hide_admin_bar' );

/* ------------------------------------------------------------
 * 移除 wp-embed
 * ---------------------------------------------------------- */
function sg_disable_embed() {
	if ( ! sg_on( 'opt_embed' ) ) {
		return;
	}
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
	remove_action( 'wp_head', 'wp_oembed_add_host_js' );
}
add_action( 'init', 'sg_disable_embed' );

/* ------------------------------------------------------------
 * DNS 预解析
 * ---------------------------------------------------------- */
function sg_resource_hints( $hints, $relation_type ) {
	if ( sg_on( 'opt_dns_prefetch' ) && 'dns-prefetch' === $relation_type ) {
		$hints[] = 'https://cdn.jsdelivr.net';
		if ( 'geetest' === sg_get( 'captcha_mode' ) ) {
			$hints[] = 'https://static.geetest.com';
			$hints[] = 'https://gcaptcha4.geetest.com';
		}
	}
	return $hints;
}
add_filter( 'wp_resource_hints', 'sg_resource_hints', 10, 2 );

/* ------------------------------------------------------------
 * 图片与头像懒加载
 * ---------------------------------------------------------- */
function sg_lazy_image_attributes( $attr ) {
	if ( sg_on( 'lazy_load' ) ) {
		if ( empty( $attr['loading'] ) ) {
			$attr['loading'] = 'lazy';
		}
		$attr['decoding'] = 'async';
	}
	return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'sg_lazy_image_attributes' );

function sg_lazy_avatar( $avatar ) {
	if ( sg_on( 'lazy_load' ) && false !== strpos( $avatar, '<img' ) ) {
		$avatar = preg_replace( '/<img\s/', '<img loading="lazy" decoding="async" ', $avatar, 1 );
	}
	return $avatar;
}
add_filter( 'get_avatar', 'sg_lazy_avatar' );

/* ------------------------------------------------------------
 * HTML 压缩为一行
 * ---------------------------------------------------------- */
function sg_minify_html( $html ) {
	if ( '' === trim( $html ) ) {
		return $html;
	}

	$blocks = array();
	$html   = preg_replace_callback(
		'#<(pre|textarea|script|style)\b[^>]*>.*?</\1>#is',
		function ( $matches ) use ( &$blocks ) {
			$key            = '###SG_BLOCK_' . count( $blocks ) . '###';
			$blocks[ $key ] = $matches[0];
			return $key;
		},
		$html
	);

	// 移除 HTML 注释（保留条件注释）。
	$html = preg_replace( '/<!--(?!\[if).*?-->/s', '', $html );

	// 合并空白，压成一行，同时保留必要的单个空格。
	$html = preg_replace( '/[ \t]*\r?\n[ \t]*/', ' ', $html );
	$html = preg_replace( '/[ \t]{2,}/', ' ', $html );

	if ( $blocks ) {
		$html = strtr( $html, $blocks );
	}

	return trim( $html );
}

function sg_start_minify_buffer() {
	if ( ! sg_on( 'html_minify' ) ) {
		return;
	}
	if ( is_admin() || is_feed() || is_trackback() || is_robots() ) {
		return;
	}
	if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
		return;
	}
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
		return;
	}
	if ( isset( $_GET['sg_no_minify'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}

	// 图片、站点地图为二进制或 XML，不参与 HTML 压缩。
	if ( get_query_var( 'sg_thumb' ) || get_query_var( 'sg_sitemap' ) ) {
		return;
	}

	ob_start( 'sg_minify_html' );
}
add_action( 'template_redirect', 'sg_start_minify_buffer', 1 );

/* ------------------------------------------------------------
 * 缓存清理联动
 * ---------------------------------------------------------- */
function sg_purge_cache( $post_id = 0 ) {
	if ( ! sg_on( 'cache_purge' ) ) {
		return;
	}

	$post_id = (int) $post_id;

	do_action( 'sg_purge_cache', $post_id );

	if ( $post_id ) {
		if ( function_exists( 'rocket_clean_post' ) ) {
			rocket_clean_post( $post_id );
		}
		if ( function_exists( 'w3tc_flush_post' ) ) {
			w3tc_flush_post( $post_id );
		}
		if ( function_exists( 'wp_cache_post_change' ) ) {
			wp_cache_post_change( $post_id );
		}
		if ( function_exists( 'litespeed_purge_post' ) ) {
			litespeed_purge_post( $post_id );
		}
		if ( function_exists( 'breeze_clear_all_cache' ) ) {
			breeze_clear_all_cache();
		}
	}

	if ( function_exists( 'rocket_clean_home' ) ) {
		rocket_clean_home();
	}
	if ( function_exists( 'w3tc_flush_all' ) ) {
		w3tc_flush_all();
	}
	if ( function_exists( 'wp_cache_clear_cache' ) ) {
		wp_cache_clear_cache();
	}
}

function sg_purge_on_save( $post_id ) {
	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
		return;
	}
	sg_purge_cache( $post_id );
}
add_action( 'save_post', 'sg_purge_on_save', 30 );
add_action( 'deleted_post', 'sg_purge_cache' );

function sg_purge_on_comment( $comment_id, $comment ) {
	if ( ! empty( $comment->comment_post_ID ) ) {
		sg_purge_cache( (int) $comment->comment_post_ID );
	}
}
add_action( 'wp_insert_comment', 'sg_purge_on_comment', 10, 2 );

function sg_purge_on_comment_status( $new_status, $old_status, $comment ) {
	if ( $new_status === $old_status ) {
		return;
	}
	if ( ! empty( $comment->comment_post_ID ) ) {
		sg_purge_cache( (int) $comment->comment_post_ID );
	}
}
add_action( 'transition_comment_status', 'sg_purge_on_comment_status', 10, 3 );

/* ------------------------------------------------------------
 * 自定义 JS 输出
 * ---------------------------------------------------------- */
function sg_output_custom_js() {
	$js = (string) sg_get( 'custom_js' );
	if ( $js ) {
		echo '<script>' . $js . '</script>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
add_action( 'wp_footer', 'sg_output_custom_js', 98 );
