<?php
/**
 * 统一设置存储与读取
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 读取设置结构
 *
 * @return array
 */
function sg_schema() {
	static $schema = null;
	if ( null === $schema ) {
		$schema = include SG_DIR . '/inc/options-schema.php';
	}
	return $schema;
}

/**
 * 所有默认值
 *
 * @return array
 */
function sg_defaults() {
	static $defaults = null;
	if ( null !== $defaults ) {
		return $defaults;
	}
	$defaults = array();
	foreach ( sg_schema() as $tab ) {
		foreach ( $tab['sections'] as $section ) {
			foreach ( $section['fields'] as $key => $field ) {
				$defaults[ $key ] = array_key_exists( 'default', $field ) ? $field['default'] : '';
			}
		}
	}
	return $defaults;
}

/**
 * 获取单个设置
 *
 * @param string $key     设置键。
 * @param mixed  $default 备用默认值。
 * @return mixed
 */
function sg_get( $key, $default = null ) {
	static $options = null;

	if ( null === $options ) {
		$stored = get_option( 'steamgrid_settings', array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		$options = wp_parse_args( $stored, sg_defaults() );
	}

	if ( array_key_exists( $key, $options ) ) {
		$value = $options[ $key ];
	} else {
		$defaults = sg_defaults();
		$value    = array_key_exists( $key, $defaults ) ? $defaults[ $key ] : $default;
	}

	return $value;
}

/**
 * 布尔便捷读取
 *
 * @param string $key 设置键。
 * @return bool
 */
function sg_on( $key ) {
	return (bool) sg_get( $key );
}

/**
 * 写入部分设置
 *
 * @param array $values 键值对。
 * @return array
 */
function sg_save_settings( $values ) {
	$current = get_option( 'steamgrid_settings', array() );
	if ( ! is_array( $current ) ) {
		$current = array();
	}

	$old_thumb = ! empty( $current['thumb_enable'] );
	$sanitized = sg_sanitize_settings( $values );
	$merged    = array_merge( $current, $sanitized );
	update_option( 'steamgrid_settings', $merged );

	// 缩略图伪静态开关变化时刷新重写规则。
	if ( array_key_exists( 'thumb_enable', $sanitized ) && $old_thumb !== (bool) $sanitized['thumb_enable'] ) {
		flush_rewrite_rules( false );
	}

	return $merged;
}

/**
 * 按字段类型清洗设置
 *
 * @param array $input 原始输入。
 * @return array
 */
function sg_sanitize_settings( $input ) {
	$schema = sg_schema();
	$clean  = array();

	if ( ! is_array( $input ) ) {
		return $clean;
	}

	foreach ( $schema as $tab ) {
		foreach ( $tab['sections'] as $section ) {
			foreach ( $section['fields'] as $key => $field ) {
				if ( ! array_key_exists( $key, $input ) ) {
					continue;
				}

				$value = $input[ $key ];
				$type  = isset( $field['type'] ) ? $field['type'] : 'text';

				// 名片 HTML 原样输出（仅管理员可保存）。
				if ( 'card_html' === $key ) {
					$clean[ $key ] = wp_unslash( (string) $value );
					continue;
				}

				// 幻灯片条目（数组结构）。
				if ( 'slides' === $type ) {
					$clean[ $key ] = array();
					if ( is_array( $value ) ) {
						foreach ( $value as $slide ) {
							if ( ! is_array( $slide ) ) {
								continue;
							}
							$clean[ $key ][] = array(
								'image'  => esc_url_raw( isset( $slide['image'] ) ? $slide['image'] : '' ),
								'title'  => sanitize_text_field( isset( $slide['title'] ) ? $slide['title'] : '' ),
								'text'   => sanitize_textarea_field( isset( $slide['text'] ) ? $slide['text'] : '' ),
								'link'   => esc_url_raw( isset( $slide['link'] ) ? $slide['link'] : '' ),
								'button' => sanitize_text_field( isset( $slide['button'] ) ? $slide['button'] : '' ),
								'tags'   => sanitize_text_field( isset( $slide['tags'] ) ? $slide['tags'] : '' ),
							);
						}
					}
					continue;
				}

				// 广告位允许第三方脚本，仅管理员可保存。
				if ( 0 === strpos( $key, 'ad_' ) ) {
					$clean[ $key ] = sg_sanitize_ad_code( $value );
					continue;
				}

				switch ( $type ) {
					case 'switch':
						$clean[ $key ] = ( '1' === (string) $value || true === $value || 'true' === $value || 'on' === $value );
						break;

					case 'number':
						$clean[ $key ] = is_numeric( $value ) ? (float) $value : 0;
						break;

					case 'select':
						$options       = isset( $field['options'] ) ? array_keys( $field['options'] ) : array();
						$clean[ $key ] = in_array( (string) $value, array_map( 'strval', $options ), true ) ? (string) $value : ( isset( $field['default'] ) ? $field['default'] : '' );
						break;

					case 'color':
						$color         = sanitize_hex_color( (string) $value );
						$clean[ $key ] = $color ? $color : ( isset( $field['default'] ) ? $field['default'] : '' );
						break;

					case 'url':
					case 'image':
						$clean[ $key ] = esc_url_raw( (string) $value );
						break;

					case 'email':
						$clean[ $key ] = sanitize_email( (string) $value );
						break;

					case 'html':
						$clean[ $key ] = wp_kses_post( (string) $value );
						break;

					case 'js':
						$clean[ $key ] = sg_sanitize_js( (string) $value );
						break;

					case 'code':
						$clean[ $key ] = wp_strip_all_tags( (string) $value );
						break;

					case 'password':
						$clean[ $key ] = sanitize_text_field( (string) $value );
						break;

					case 'textarea':
						$clean[ $key ] = sanitize_textarea_field( (string) $value );
						break;

					default:
						$clean[ $key ] = sanitize_text_field( (string) $value );
				}
			}
		}
	}

	return $clean;
}

/**
 * 过滤自定义 JS，避免提前闭合 script
 *
 * @param string $value JS。
 * @return string
 */
function sg_sanitize_js( $value ) {
	$value = wp_unslash( (string) $value );
	return preg_replace( '#</script#i', '<\\/script', $value );
}

/**
 * 广告代码清洗：广告位需要支持 script / iframe，仅管理员可写入
 *
 * @param string $value 广告 HTML。
 * @return string
 */
function sg_sanitize_ad_code( $value ) {
	return wp_unslash( (string) $value );
}

/**
 * 重置全部设置
 *
 * @return array
 */
function sg_reset_settings() {
	delete_option( 'steamgrid_settings' );
	delete_option( 'sg_settings_migrated' );
	set_transient( 'sg_flush_rewrite', 1, 60 );
	return sg_defaults();
}

/**
 * 从旧版 theme_mod 迁移设置（一次性）
 */
function sg_migrate_legacy_settings() {
	if ( get_option( 'sg_settings_migrated' ) ) {
		return;
	}

	$stored = get_option( 'steamgrid_settings', null );
	if ( ! is_array( $stored ) ) {
		$map = array(
			'accent_color'     => 'sg_accent_color',
			'font_size'        => 'sg_font_size',
			'font_weight'      => 'sg_font_weight',
			'heading_weight'   => 'sg_heading_weight',
			'container_width'  => 'sg_container_width',
			'grid_cols'        => 'sg_grid_cols',
			'card_style'       => 'sg_card_style',
			'card_radius'      => 'sg_card_radius',
			'layout_mode'      => 'sg_layout_mode',
			'sidebar_position' => 'sg_sidebar_position',
			'hero_show'        => 'sg_hero_show',
			'hero_title'       => 'sg_hero_title',
			'hero_subtitle'    => 'sg_hero_subtitle',
			'hero_btn_text'    => 'sg_hero_btn_text',
			'hero_btn_url'     => 'sg_hero_btn_url',
			'hero_bg'          => 'sg_hero_bg',
			'featured_title'   => 'sg_section_featured_title',
			'latest_title'     => 'sg_section_latest_title',
			'copyright'        => 'sg_copyright',
			'icp'              => 'sg_icp',
			'icp_link'         => 'sg_icp_link',
			'beian'            => 'sg_beian',
			'beian_link'       => 'sg_beian_link',
			'footer_html'      => 'sg_footer_html',
			'footer_js'        => 'sg_footer_js',
			'social_github'    => 'sg_social_github',
			'social_weibo'     => 'sg_social_weibo',
			'social_bilibili'  => 'sg_social_bilibili',
			'social_email'     => 'sg_social_email',
		);

		$data = array();
		foreach ( $map as $new_key => $old_key ) {
			$value = get_theme_mod( $old_key, null );
			if ( null !== $value && '' !== $value ) {
				$data[ $new_key ] = $value;
			}
		}

		if ( ! empty( $data['social_email'] ) ) {
			$data['social_email'] = sanitize_email( $data['social_email'] );
		}

		// 旧版横幅背景图为附件 ID，转换为 URL。
		$old_hero = get_theme_mod( 'sg_hero_image', 0 );
		if ( $old_hero ) {
			if ( is_numeric( $old_hero ) ) {
				$hero_url = wp_get_attachment_image_url( (int) $old_hero, 'full' );
				if ( $hero_url ) {
					$data['hero_image'] = $hero_url;
				}
			} elseif ( filter_var( $old_hero, FILTER_VALIDATE_URL ) ) {
				$data['hero_image'] = $old_hero;
			}
		}

		if ( $data ) {
			update_option( 'steamgrid_settings', array_merge( sg_defaults(), $data ) );
		}
	}

	update_option( 'sg_settings_migrated', 1 );
}
add_action( 'admin_init', 'sg_migrate_legacy_settings' );

/**
 * 主题自带页面（登录 / 注册 / 找回密码 / 用户中心）的创建与地址
 *
 * @return array
 */
function sg_auth_pages() {
	$pages = get_option( 'steamgrid_pages', array() );
	return is_array( $pages ) ? $pages : array();
}

/**
 * 创建缺失的用户页面
 */
function sg_create_auth_pages() {
	$pages = sg_auth_pages();

	$definitions = array(
		'login'       => array(
			'title'    => '登录',
			'template' => 'page-templates/login.php',
		),
		'register'    => array(
			'title'    => '注册',
			'template' => 'page-templates/register.php',
		),
		'lostpass'    => array(
			'title'    => '找回密码',
			'template' => 'page-templates/lost-password.php',
		),
		'user_center' => array(
			'title'    => '用户中心',
			'template' => 'page-templates/user-center.php',
		),
	);

	$changed = false;

	foreach ( $definitions as $key => $definition ) {
		if ( ! empty( $pages[ $key ] ) && get_post( $pages[ $key ] ) ) {
			continue;
		}

		$existing = new WP_Query(
			array(
				'post_type'      => 'page',
				'post_status'    => 'any',
				'meta_key'       => '_wp_page_template',
				'meta_value'     => $definition['template'],
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);

		if ( $existing->have_posts() ) {
			$pages[ $key ] = (int) $existing->posts[0];
			$changed       = true;
			continue;
		}

		$page_id = wp_insert_post(
			array(
				'post_title'   => $definition['title'],
				'post_content' => '',
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_author'  => 1,
			)
		);

		if ( $page_id && ! is_wp_error( $page_id ) ) {
			update_post_meta( $page_id, '_wp_page_template', $definition['template'] );
			$pages[ $key ] = (int) $page_id;
			$changed       = true;
		}
	}

	if ( $changed ) {
		update_option( 'steamgrid_pages', $pages );
	}
}

/**
 * 用户页面地址
 *
 * @param string $key login|register|lostpass|user_center。
 * @return string
 */
function sg_auth_url( $key ) {
	$pages = sg_auth_pages();
	if ( ! empty( $pages[ $key ] ) ) {
		$url = get_permalink( (int) $pages[ $key ] );
		if ( $url ) {
			return $url;
		}
	}

	$templates = array(
		'login'       => 'page-templates/login.php',
		'register'    => 'page-templates/register.php',
		'lostpass'    => 'page-templates/lost-password.php',
		'user_center' => 'page-templates/user-center.php',
	);

	if ( isset( $templates[ $key ] ) ) {
		$found = get_pages(
			array(
				'meta_key'   => '_wp_page_template',
				'meta_value' => $templates[ $key ],
				'number'     => 1,
			)
		);
		if ( ! empty( $found ) ) {
			return get_permalink( $found[0]->ID );
		}
	}

	return home_url( '/' );
}

/**
 * 邮箱是否已验证
 *
 * @param int $user_id 用户 ID。
 * @return bool
 */
function sg_is_email_verified( $user_id = 0 ) {
	$user_id = $user_id ? (int) $user_id : get_current_user_id();
	if ( ! $user_id ) {
		return false;
	}
	if ( ! sg_on( 'email_verify' ) ) {
		return true;
	}
	// 旧账号未经过主题注册流程，不强制邮箱验证，避免被锁在内容之外。
	if ( '1' !== (string) get_user_meta( $user_id, '_sg_email_required', true ) ) {
		return true;
	}
	return '1' === (string) get_user_meta( $user_id, '_sg_email_verified', true );
}

/**
 * 底部社交链接（Steam / 网易云 / 微博 等）
 *
 * @return array
 */
function sg_social_links() {
	$items = array(
		'steam'    => array(
			'url'      => sg_get( 'social_steam' ),
			'label'    => 'Steam',
			'enabled'  => sg_on( 'social_steam_enable' ),
			'fallback' => 'https://store.steampowered.com/',
		),
		'netease'  => array(
			'url'      => sg_get( 'social_netease' ),
			'label'    => '网易云音乐',
			'enabled'  => sg_on( 'social_netease_enable' ),
			'fallback' => 'https://music.163.com/',
		),
		'github'   => array(
			'url'     => sg_get( 'social_github' ),
			'label'   => 'GitHub',
			'enabled' => true,
		),
		'weibo'    => array(
			'url'     => sg_get( 'social_weibo' ),
			'label'   => '微博',
			'enabled' => true,
		),
		'bilibili' => array(
			'url'     => sg_get( 'social_bilibili' ),
			'label'   => '哔哩哔哩',
			'enabled' => true,
		),
	);

	$links = array();
	foreach ( $items as $icon => $item ) {
		if ( empty( $item['enabled'] ) ) {
			continue;
		}

		$url = trim( (string) $item['url'] );
		if ( ! $url && ! empty( $item['fallback'] ) ) {
			$url = $item['fallback'];
		}
		if ( ! $url ) {
			continue;
		}

		$links[] = array(
			'icon'  => $icon,
			'url'   => $url,
			'label' => $item['label'],
		);
	}

	$email = sg_get( 'social_email' );
	if ( $email && is_email( $email ) ) {
		$links[] = array(
			'icon'  => 'mail',
			'url'   => 'mailto:' . $email,
			'label' => '邮箱',
		);
	}

	return $links;
}

/**
 * 解析页脚文字链接（名称|链接 每行一个）
 *
 * @return array
 */
function sg_footer_links_parse() {
	$raw   = (string) sg_get( 'footer_links' );
	$lines = preg_split( '/\r\n|\r|\n/', $raw );
	$links = array();

	foreach ( $lines as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$parts = explode( '|', $line, 2 );
		$name  = trim( $parts[0] );
		$url   = isset( $parts[1] ) ? trim( $parts[1] ) : '#';
		if ( '' === $name ) {
			continue;
		}
		$links[] = array(
			'name' => $name,
			'url'  => $url,
		);
	}

	return $links;
}
