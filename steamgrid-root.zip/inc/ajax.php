<?php
/**
 * AJAX：首页加载更多、点赞、评论提交
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 校验 AJAX nonce
 */
function sg_ajax_verify() {
	check_ajax_referer( 'sg_ajax', 'nonce' );
}

/* ------------------------------------------------------------
 * 加载更多
 * ---------------------------------------------------------- */
function sg_ajax_load_more() {
	sg_ajax_verify();

	$paged    = isset( $_POST['paged'] ) ? max( 2, absint( $_POST['paged'] ) ) : 2;
	$per_page = isset( $_POST['per_page'] ) ? max( 1, min( 50, absint( $_POST['per_page'] ) ) ) : max( 1, absint( sg_get( 'home_page_size', 12 ) ) );
	$exclude  = array();

	if ( ! empty( $_POST['exclude'] ) ) {
		$raw = sanitize_text_field( wp_unslash( $_POST['exclude'] ) );
		$exclude = array_filter( array_map( 'absint', explode( ',', $raw ) ) );
	}

	$query = new WP_Query(
		array(
			'posts_per_page'      => $per_page,
			'paged'               => $paged,
			'post__not_in'        => $exclude,
			'ignore_sticky_posts' => true,
		)
	);

	ob_start();
	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) {
			$query->the_post();
			get_template_part( 'template-parts/content', 'card' );
		}
	}
	$html = ob_get_clean();

	$has_more = $paged < (int) $query->max_num_pages;
	wp_reset_postdata();

	wp_send_json_success(
		array(
			'html'    => $html,
			'hasMore' => $has_more,
			'next'    => $paged + 1,
		)
	);
}
add_action( 'wp_ajax_sg_load_more', 'sg_ajax_load_more' );
add_action( 'wp_ajax_nopriv_sg_load_more', 'sg_ajax_load_more' );

/* ------------------------------------------------------------
 * 点赞
 * ---------------------------------------------------------- */
function sg_ajax_like() {
	sg_ajax_verify();

	$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
	if ( ! $post_id || 'publish' !== get_post_status( $post_id ) ) {
		wp_send_json_error( array( 'message' => __( '文章不存在。', 'steamgrid' ) ), 404 );
	}

	$ip_key = 'sg_like_' . md5( sg_client_ip() . '|' . $post_id );
	if ( get_transient( $ip_key ) ) {
		wp_send_json_error( array( 'message' => __( '您已经点过赞了。', 'steamgrid' ) ), 429 );
	}

	$likes = (int) get_post_meta( $post_id, '_sg_likes', true );
	$likes++;
	update_post_meta( $post_id, '_sg_likes', $likes );
	set_transient( $ip_key, 1, DAY_IN_SECONDS );

	wp_send_json_success( array( 'likes' => $likes ) );
}
add_action( 'wp_ajax_sg_like', 'sg_ajax_like' );
add_action( 'wp_ajax_nopriv_sg_like', 'sg_ajax_like' );

/* ------------------------------------------------------------
 * 评论提交
 * ---------------------------------------------------------- */
function sg_ajax_comment() {
	sg_ajax_verify();

	$post_id = isset( $_POST['comment_post_ID'] ) ? absint( $_POST['comment_post_ID'] ) : 0;
	if ( ! $post_id || ! get_post( $post_id ) ) {
		wp_send_json_error( array( 'message' => __( '文章不存在。', 'steamgrid' ) ), 404 );
	}
	if ( ! comments_open( $post_id ) ) {
		wp_send_json_error( array( 'message' => __( '评论已关闭。', 'steamgrid' ) ), 403 );
	}

	$security = sg_comment_security_check();
	if ( is_wp_error( $security ) ) {
		wp_send_json_error( array( 'message' => $security->get_error_message() ), 400 );
	}

	$data = wp_unslash( $_POST );
	if ( empty( $data['comment'] ) || '' === trim( $data['comment'] ) ) {
		wp_send_json_error( array( 'message' => __( '评论内容不能为空。', 'steamgrid' ) ), 400 );
	}

	$result = wp_handle_comment_submission( $data );

	if ( is_wp_error( $result ) ) {
		wp_send_json_error( array( 'message' => wp_strip_all_tags( $result->get_error_message() ) ), 400 );
	}

	$comment = $result['comment'];
	$user    = $result['user'];

	if ( function_exists( 'wp_set_comment_cookies' ) ) {
		wp_set_comment_cookies( $comment, $user );
	}

	$approved = '1' === (string) $comment->comment_approved;

	wp_send_json_success(
		array(
			'message'  => $approved ? __( '评论已提交。', 'steamgrid' ) : __( '评论已提交，等待审核。', 'steamgrid' ),
			'approved' => $approved,
			'count'    => (int) get_comments_number( $post_id ),
		)
	);
}
add_action( 'wp_ajax_sg_comment', 'sg_ajax_comment' );
add_action( 'wp_ajax_nopriv_sg_comment', 'sg_ajax_comment' );
