<?php
/**
 * SteamGrid 设置面板结构（同时作为默认值来源）
 *
 * 字段类型：text / textarea / html / js / url / email / color / number / switch / select / image / password
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'general'  => array(
		'label'    => '基础设置',
		'sections' => array(
			'global'        => array(
				'label'  => '全局外观',
				'fields' => array(
					'accent_color' => array(
						'label'   => '主题主色调',
						'type'    => 'color',
						'default' => '#66c0f4',
						'desc'    => '按钮、链接、高亮等强调色。',
					),
					'color_mode'   => array(
						'label'   => '色彩模式',
						'type'    => 'select',
						'default' => 'auto',
						'options' => array(
							'auto'  => '跟随系统',
							'light' => '白天模式',
							'dark'  => '暗黑模式',
						),
						'desc'    => '跟随系统时，访客可手动切换并记住选择。',
					),
					'gray_mode'    => array(
						'label'   => '一键全站变灰',
						'type'    => 'switch',
						'default' => false,
						'desc'    => '纪念日等场景使用，全站滤镜变灰。',
					),
					'logo_shine'   => array(
						'label'   => 'LOGO 扫光动画',
						'type'    => 'switch',
						'default' => true,
						'desc'    => '站点名称/LOGO 上循环扫光。',
					),
				),
			),
			'card'          => array(
				'label'  => '站点名片',
				'fields' => array(
					'card_avatar' => array(
						'label'   => '名片头像',
						'type'    => 'image',
						'default' => '',
						'desc'    => '留空时显示站点 LOGO 或站点名首字母。',
					),
					'card_name'   => array(
						'label'   => '名片名称',
						'type'    => 'text',
						'default' => '',
						'desc'    => '留空时显示站点名称。',
					),
					'card_bio'    => array(
						'label'   => '个人资料说明',
						'type'    => 'textarea',
						'default' => '',
						'desc'    => '显示在名片中的个人/站点简介，留空时显示站点副标题。',
					),
					'card_html'   => array(
						'label'   => '名片自定义 HTML',
						'type'    => 'html',
						'default' => '',
						'desc'    => '原样输出（支持 style / iframe / script），仅管理员可保存。显示在名片简介下方。',
					),
					'card_js'     => array(
						'label'   => '名片自定义 JS',
						'type'    => 'js',
						'default' => '',
						'desc'    => '无需 script 标签，输出在名片末尾。',
					),
				),
			),
			'announcement'  => array(
				'label'  => '顶部滚动公告',
				'fields' => array(
					'announcement_enable' => array(
						'label'   => '启用公告',
						'type'    => 'switch',
						'default' => true,
					),
					'announcement_text'   => array(
						'label'   => '公告内容',
						'type'    => 'text',
						'default' => '欢迎来到 SteamGrid：一个仿 Steam 商店风格的 WordPress 主题。',
					),
					'announcement_link'   => array(
						'label'   => '公告链接',
						'type'    => 'url',
						'default' => '',
					),
					'announcement_speed'  => array(
						'label'   => '滚动时长（秒）',
						'type'    => 'number',
						'default' => 30,
						'desc'    => '数值越大滚动越慢。',
					),
					'announcement_close'  => array(
						'label'   => '允许关闭公告',
						'type'    => 'switch',
						'default' => true,
					),
				),
			),
		),
	),
	'layout'   => array(
		'label'    => '布局外观',
		'sections' => array(
			'typography' => array(
				'label'  => '字体与容器',
				'fields' => array(
					'font_size'       => array(
						'label'   => '正文字号（px）',
						'type'    => 'number',
						'default' => 16,
					),
					'font_weight'     => array(
						'label'   => '正文字重',
						'type'    => 'select',
						'default' => '400',
						'options' => array(
							'300' => '细体 300',
							'400' => '常规 400',
							'500' => '中等 500',
							'600' => '半粗 600',
							'700' => '粗体 700',
						),
					),
					'heading_weight'  => array(
						'label'   => '标题字重',
						'type'    => 'select',
						'default' => '700',
						'options' => array(
							'400' => '400',
							'600' => '600',
							'700' => '700',
							'900' => '900',
						),
					),
					'container_width' => array(
						'label'   => '内容宽度（px）',
						'type'    => 'select',
						'default' => '1200',
						'options' => array(
							'1000' => '1000',
							'1200' => '1200',
							'1440' => '1440',
							'1600' => '1600',
						),
					),
				),
			),
			'cards'      => array(
				'label'  => '卡片与宫格',
				'fields' => array(
					'grid_cols'   => array(
						'label'   => '宫格列数',
						'type'    => 'select',
						'default' => '4',
						'options' => array(
							'2' => '2 列',
							'3' => '3 列',
							'4' => '4 列',
							'5' => '5 列',
							'6' => '6 列',
						),
					),
					'card_style'  => array(
						'label'   => '卡片风格',
						'type'    => 'select',
						'default' => 'default',
						'options' => array(
							'default'  => '经典',
							'bordered' => '描边',
							'shadow'   => '投影',
						),
					),
					'card_radius' => array(
						'label'   => '卡片圆角（px）',
						'type'    => 'number',
						'default' => 4,
					),
					'layout_mode'  => array(
						'label'   => '列表排版',
						'type'    => 'select',
						'default' => 'grid',
						'options' => array(
							'grid' => '宫格',
							'list' => '横向列表',
						),
					),
					'sidebar_position' => array(
						'label'   => '侧边栏位置',
						'type'    => 'select',
						'default' => 'right',
						'options' => array(
							'right' => '右侧',
							'left'  => '左侧',
							'none'  => '不显示',
						),
					),
					'home_sidebar' => array(
						'label'   => '首页显示侧边栏',
						'type'    => 'switch',
						'default' => true,
					),
					'sidebar_sticky' => array(
						'label'   => '侧边栏粘性滚动',
						'type'    => 'switch',
						'default' => true,
					),
					'mobile_sidebar' => array(
						'label'   => '移动端侧边栏抽屉',
						'type'    => 'switch',
						'default' => true,
					),
				),
			),
			'hero'       => array(
				'label'  => '首页横幅',
				'fields' => array(
					'hero_show'     => array(
						'label'   => '显示横幅',
						'type'    => 'switch',
						'default' => true,
					),
					'hero_title'    => array(
						'label'   => '主标题',
						'type'    => 'text',
						'default' => '发现你的下一款游戏',
					),
					'hero_subtitle' => array(
						'label'   => '副标题',
						'type'    => 'text',
						'default' => '精选游戏、资源与作品，用 Steam 的方式陈列。',
					),
					'hero_btn_text' => array(
						'label'   => '按钮文字',
						'type'    => 'text',
						'default' => '立即探索',
					),
					'hero_btn_url'  => array(
						'label'   => '按钮链接',
						'type'    => 'url',
						'default' => '',
					),
					'hero_bg'       => array(
						'label'   => '横幅背景色',
						'type'    => 'color',
						'default' => '#1b2838',
					),
					'hero_image'    => array(
						'label'   => '横幅背景图',
						'type'    => 'image',
						'default' => '',
					),
				),
			),
			'carousel'   => array(
				'label'  => '首页幻灯片',
				'desc'   => '替代原首页横幅，支持多张图片文章、自动播放、鼠标滚轮切换。',
				'fields' => array(
					'carousel_enable'       => array(
						'label'   => '启用首页幻灯片',
						'type'    => 'switch',
						'default' => true,
					),
					'carousel_source'       => array(
						'label'   => '幻灯片来源',
						'type'    => 'select',
						'default' => 'posts',
						'options' => array(
							'posts'  => '自动提取文章',
							'manual' => '手动添加幻灯片',
						),
						'desc'    => '自动提取时使用文章特色图片、标题、摘要与标签。',
					),
					'carousel_category'     => array(
						'label'   => '文章分类 ID',
						'type'    => 'number',
						'default' => 0,
						'desc'    => '0 表示最新文章；填写分类 ID 则只取该分类。',
					),
					'carousel_posts'        => array(
						'label'   => '指定文章 ID',
						'type'    => 'text',
						'default' => '',
						'desc'    => '可选，多个 ID 用英文逗号分隔，优先于分类。',
					),
					'carousel_count'        => array(
						'label'   => '自动提取数量',
						'type'    => 'number',
						'default' => 5,
					),
					'carousel_speed'        => array(
						'label'   => '自动播放速度（秒）',
						'type'    => 'number',
						'default' => 6,
					),
					'carousel_transition'   => array(
						'label'   => '切换形式',
						'type'    => 'select',
						'default' => 'fade',
						'options' => array(
							'fade'  => '淡入淡出',
							'slide' => '左右滑动',
							'zoom'  => '缩放淡入',
						),
					),
					'carousel_autoplay'     => array(
						'label'   => '自动播放',
						'type'    => 'switch',
						'default' => true,
					),
					'carousel_wheel'        => array(
						'label'   => '鼠标滚轮切换',
						'type'    => 'switch',
						'default' => true,
					),
					'carousel_pause_hover'  => array(
						'label'   => '悬停时暂停',
						'type'    => 'switch',
						'default' => true,
					),
					'carousel_arrows'       => array(
						'label'   => '显示左右箭头',
						'type'    => 'switch',
						'default' => true,
					),
					'carousel_dots'         => array(
						'label'   => '显示指示点',
						'type'    => 'switch',
						'default' => true,
					),
					'carousel_button_text'  => array(
						'label'   => '默认按钮文字',
						'type'    => 'text',
						'default' => '查看详情',
					),
					'slides'                => array(
						'label'   => '手动幻灯片',
						'type'    => 'slides',
						'default' => array(),
						'desc'    => '仅在“幻灯片来源 = 手动添加幻灯片”时生效；图片建议 16:9。',
					),
				),
			),
			'home'       => array(
				'label'  => '首页内容',
				'fields' => array(
					'featured_title'    => array(
						'label'   => '推荐区块标题',
						'type'    => 'text',
						'default' => '特别推荐',
					),
					'latest_title'      => array(
						'label'   => '最新区块标题',
						'type'    => 'text',
						'default' => '最新上架',
					),
					'featured_source'   => array(
						'label'   => '推荐内容来源',
						'type'    => 'select',
						'default' => 'sticky',
						'options' => array(
							'sticky'   => '置顶文章',
							'category' => '指定分类',
						),
					),
					'featured_category' => array(
						'label'   => '指定分类 ID',
						'type'    => 'number',
						'default' => 0,
						'desc'    => '推荐来源选择「指定分类」时生效。',
					),
					'home_page_size'    => array(
						'label'   => '每页文章数',
						'type'    => 'number',
						'default' => 12,
					),
					'load_more'         => array(
						'label'   => '首页加载更多',
						'type'    => 'switch',
						'default' => true,
					),
				),
			),
		),
	),
	'features' => array(
		'label'    => '功能开关',
		'sections' => array(
			'browse'   => array(
				'label'  => '浏览体验',
				'fields' => array(
					'pjax'          => array(
						'label'   => '全局无刷新加载',
						'type'    => 'switch',
						'default' => true,
					),
					'skeleton'      => array(
						'label'   => '骨架屏加载',
						'type'    => 'switch',
						'default' => true,
					),
					'lazy_load'     => array(
						'label'   => '图片/头像懒加载',
						'type'    => 'switch',
						'default' => true,
					),
					'next_prefetch' => array(
						'label'   => '链接预取',
						'type'    => 'switch',
						'default' => false,
						'desc'    => '鼠标悬停时预取站内链接，流量敏感站点可关闭。',
					),
					'theme_toggle'  => array(
						'label'   => '显示昼夜切换按钮',
						'type'    => 'switch',
						'default' => true,
					),
				),
			),
			'comments' => array(
				'label'  => '评论与验证',
				'fields' => array(
					'comments_ajax'   => array(
						'label'   => '评论 AJAX 加载',
						'type'    => 'switch',
						'default' => true,
					),
					'captcha_mode'    => array(
						'label'   => '验证码方式',
						'type'    => 'select',
						'default' => 'svg',
						'options' => array(
							'svg'     => '图形验证码（内置）',
							'geetest' => '极验验证码 v4',
							'off'     => '关闭',
						),
					),
					'comment_captcha' => array(
						'label'   => '评论启用验证码',
						'type'    => 'switch',
						'default' => true,
					),
					'login_captcha'   => array(
						'label'   => '登录启用验证码',
						'type'    => 'switch',
						'default' => false,
					),
					'register_captcha' => array(
						'label'   => '注册启用验证码',
						'type'    => 'switch',
						'default' => true,
					),
					'geetest_id'      => array(
						'label'   => '极验 Captcha ID',
						'type'    => 'text',
						'default' => '',
						'desc'    => '极验后台获取，需与 Key 同时填写。',
					),
					'geetest_key'     => array(
						'label'   => '极验 Key',
						'type'    => 'password',
						'default' => '',
					),
				),
			),
			'post'     => array(
				'label'  => '文章增强',
				'fields' => array(
					'reading_time'   => array(
						'label'   => '阅读时间与字数',
						'type'    => 'switch',
						'default' => true,
					),
					'toc_enable'     => array(
						'label'   => '文章多级目录',
						'type'    => 'switch',
						'default' => true,
					),
					'toc_depth'      => array(
						'label'   => '目录层级',
						'type'    => 'select',
						'default' => '3',
						'options' => array(
							'2' => 'H2',
							'3' => 'H2-H3',
							'4' => 'H2-H4',
						),
					),
					'toc_position'   => array(
						'label'   => '目录位置',
						'type'    => 'select',
						'default' => 'content',
						'options' => array(
							'content' => '正文顶部',
							'sidebar' => '侧边栏小工具',
						),
					),
					'like_enable'    => array(
						'label'   => '文章点赞',
						'type'    => 'switch',
						'default' => true,
					),
					'reward_enable'  => array(
						'label'   => '文章打赏',
						'type'    => 'switch',
						'default' => true,
					),
					'reward_qr'      => array(
						'label'   => '打赏二维码',
						'type'    => 'image',
						'default' => '',
					),
					'reward_text'    => array(
						'label'   => '打赏说明',
						'type'    => 'text',
						'default' => '感谢您的支持，我会继续努力！',
					),
					'share_enable'   => array(
						'label'   => '文章分享',
						'type'    => 'switch',
						'default' => true,
					),
					'poster_enable'  => array(
						'label'   => '海报生成',
						'type'    => 'switch',
						'default' => true,
					),
					'poster_qr'      => array(
						'label'   => '海报包含二维码',
						'type'    => 'switch',
						'default' => true,
						'desc'    => '二维码组件从 CDN 动态加载，加载失败时自动省略。',
					),
					'code_copy'      => array(
						'label'   => '代码块拷贝按钮',
						'type'    => 'switch',
						'default' => true,
					),
					'twemoji'        => array(
						'label'   => 'Twemoji 表情',
						'type'    => 'switch',
						'default' => true,
					),
					'twemoji_cdn'    => array(
						'label'   => 'Twemoji 脚本地址',
						'type'    => 'url',
						'default' => 'https://cdn.jsdelivr.net/npm/twemoji@14.0.2/dist/twemoji.min.js',
					),
					'dplayer_cdn'    => array(
						'label'   => 'DPlayer 脚本地址',
						'type'    => 'url',
						'default' => 'https://cdn.jsdelivr.net/npm/dplayer@1.27.1/dist/DPlayer.min.js',
					),
					'dplayer_css'    => array(
						'label'   => 'DPlayer 样式地址',
						'type'    => 'url',
						'default' => 'https://cdn.jsdelivr.net/npm/dplayer@1.27.1/dist/DPlayer.min.css',
					),
				),
			),
			'shortcodes' => array(
				'label'  => '短代码',
				'fields' => array(
					'shortcodes_enable' => array(
						'label'   => '启用短代码',
						'type'    => 'switch',
						'default' => true,
					),
					'github_token'      => array(
						'label'   => 'GitHub Token（可选）',
						'type'    => 'password',
						'default' => '',
						'desc'    => '用于提高 GitHub 卡片接口限额。',
					),
				),
			),
		),
	),
	'optimize' => array(
		'label'    => '性能优化',
		'sections' => array(
			'wp'       => array(
				'label'  => 'WP 优化策略',
				'fields' => array(
					'opt_emojis'    => array(
						'label'   => '移除 Emoji 脚本',
						'type'    => 'switch',
						'default' => true,
					),
					'opt_embed'     => array(
						'label'   => '移除 wp-embed',
						'type'    => 'switch',
						'default' => true,
					),
					'opt_head_links' => array(
						'label'   => '清理头部冗余标签',
						'type'    => 'switch',
						'default' => true,
						'desc'    => 'RSD、wlwmanifest、短链接、版本号等。',
					),
					'opt_xmlrpc'    => array(
						'label'   => '关闭 XML-RPC',
						'type'    => 'switch',
						'default' => true,
					),
					'opt_version'   => array(
						'label'   => '隐藏 WP 版本',
						'type'    => 'switch',
						'default' => true,
					),
					'opt_dns_prefetch' => array(
						'label'   => 'DNS 预解析',
						'type'    => 'switch',
						'default' => false,
					),
					'hide_admin_bar'   => array(
						'label'   => '隐藏前台 WordPress 工具栏',
						'type'    => 'switch',
						'default' => true,
						'desc'    => '登录后前台不显示顶部管理条（后台不受影响）。',
					),
				),
			),
			'html'     => array(
				'label'  => '页面输出',
				'fields' => array(
					'html_minify'   => array(
						'label'   => 'HTML 压缩（一行输出）',
						'type'    => 'switch',
						'default' => true,
					),
					'cache_purge'   => array(
						'label'   => '缓存插件联动清理',
						'type'    => 'switch',
						'default' => true,
						'desc'    => '兼容 WP Rocket / LiteSpeed / W3TC / Super Cache。',
					),
					'custom_css'    => array(
						'label'   => '自定义 CSS',
						'type'    => 'code',
						'default' => '',
					),
					'custom_js'     => array(
						'label'   => '自定义 JS',
						'type'    => 'js',
						'default' => '',
						'desc'    => '输出在页面底部，无需 script 标签。',
					),
				),
			),
			'thumbs'   => array(
				'label'  => '缩略图',
				'fields' => array(
					'thumb_enable'  => array(
						'label'   => '缩略图伪静态',
						'type'    => 'switch',
						'default' => false,
						'desc'    => '需固定链接设置为非朴素模式（如「文章名」）。启用后自动生成 /sg-thumb/ 地址并缓存。',
					),
					'thumb_quality' => array(
						'label'   => '缩略图质量（30-100）',
						'type'    => 'number',
						'default' => 82,
					),
				),
			),
		),
	),
	'security' => array(
		'label'    => '安全登录',
		'sections' => array(
			'login' => array(
				'label'  => '后台防恶意登录',
				'fields' => array(
					'login_limit'        => array(
						'label'   => '启用登录失败限制',
						'type'    => 'switch',
						'default' => true,
					),
					'login_limit_count'  => array(
						'label'   => '允许失败次数',
						'type'    => 'number',
						'default' => 5,
					),
					'login_lock_minutes' => array(
						'label'   => '锁定时长（分钟）',
						'type'    => 'number',
						'default' => 15,
					),
					'login_error_msg'    => array(
						'label'   => '登录错误提示',
						'type'    => 'text',
						'default' => '用户名或密码错误。',
					),
				),
			),
		),
	),
	'seo'      => array(
		'label'    => 'SEO 优化',
		'sections' => array(
			'meta'    => array(
				'label'  => '元信息',
				'fields' => array(
					'seo_enable'  => array(
						'label'   => '启用 SEO 功能',
						'type'    => 'switch',
						'default' => true,
					),
					'seo_desc'    => array(
						'label'   => '站点描述',
						'type'    => 'textarea',
						'default' => '',
					),
					'seo_og'      => array(
						'label'   => 'Open Graph / Twitter',
						'type'    => 'switch',
						'default' => true,
					),
					'seo_jsonld'  => array(
						'label'   => '结构化数据 JSON-LD',
						'type'    => 'switch',
						'default' => true,
					),
					'canonical'   => array(
						'label'   => '规范化链接 canonical',
						'type'    => 'switch',
						'default' => true,
					),
					'noindex_search' => array(
						'label'   => '搜索结果页 noindex',
						'type'    => 'switch',
						'default' => true,
					),
				),
			),
			'sitemap' => array(
				'label'  => '站点地图与提交',
				'fields' => array(
					'sitemap_enable' => array(
						'label'   => '启用 /sitemap.xml',
						'type'    => 'switch',
						'default' => true,
					),
					'baidu_push'     => array(
						'label'   => '自动百度链接提交',
						'type'    => 'switch',
						'default' => false,
					),
					'baidu_token'    => array(
						'label'   => '百度推送 Token',
						'type'    => 'text',
						'default' => '',
					),
				),
			),
		),
	),
	'ads'      => array(
		'label'    => '广告位',
		'sections' => array(
			'slots' => array(
				'label'  => '广告代码',
				'desc'   => '填写 HTML 广告代码，留空不显示。',
				'fields' => array(
					'ad_header'        => array(
						'label'   => '页头下方',
						'type'    => 'html',
						'default' => '',
					),
					'ad_home_top'      => array(
						'label'   => '首页顶部',
						'type'    => 'html',
						'default' => '',
					),
					'ad_home_bottom'   => array(
						'label'   => '首页底部',
						'type'    => 'html',
						'default' => '',
					),
					'ad_sidebar_top'   => array(
						'label'   => '侧边栏顶部',
						'type'    => 'html',
						'default' => '',
					),
					'ad_sidebar_bottom' => array(
						'label'   => '侧边栏底部',
						'type'    => 'html',
						'default' => '',
					),
					'ad_article_top'   => array(
						'label'   => '文章顶部',
						'type'    => 'html',
						'default' => '',
					),
					'ad_article_bottom' => array(
						'label'   => '文章底部',
						'type'    => 'html',
						'default' => '',
					),
					'ad_footer'        => array(
						'label'   => '页脚',
						'type'    => 'html',
						'default' => '',
					),
					'ad_float'         => array(
						'label'   => '悬浮广告',
						'type'    => 'html',
						'default' => '',
						'desc'    => '显示在右下角，可关闭。',
					),
				),
			),
		),
	),
	'footer'   => array(
		'label'    => '页脚设置',
		'sections' => array(
			'info'   => array(
				'label'  => '版权与备案',
				'fields' => array(
					'copyright'   => array(
						'label'   => '版权文字',
						'type'    => 'text',
						'default' => '保留所有权利',
					),
					'icp'         => array(
						'label'   => 'ICP 备案号',
						'type'    => 'text',
						'default' => '',
					),
					'icp_link'    => array(
						'label'   => 'ICP 查询链接',
						'type'    => 'url',
						'default' => 'https://beian.miit.gov.cn/',
					),
					'beian'       => array(
						'label'   => '公安备案号',
						'type'    => 'text',
						'default' => '',
					),
					'beian_link'  => array(
						'label'   => '公安备案查询链接',
						'type'    => 'url',
						'default' => 'https://beian.mps.gov.cn/',
					),
					'footer_html' => array(
						'label'   => '底部自定义 HTML',
						'type'    => 'html',
						'default' => '',
					),
					'footer_js'   => array(
						'label'   => '底部自定义 JS',
						'type'    => 'js',
						'default' => '',
					),
				),
			),
			'social' => array(
				'label'  => '社交与链接',
				'fields' => array(
					'social_steam_enable' => array(
						'label'   => '显示 Steam 图标',
						'type'    => 'switch',
						'default' => true,
						'desc'    => '默认开启；关闭后页脚与名片中不显示 Steam 图标。',
					),
					'social_steam'    => array(
						'label'   => 'Steam 链接',
						'type'    => 'url',
						'default' => '',
						'desc'    => '留空时默认链接到 https://store.steampowered.com/，可改成个人主页。',
					),
					'social_netease_enable' => array(
						'label'   => '显示网易云图标',
						'type'    => 'switch',
						'default' => true,
						'desc'    => '默认开启；关闭后不显示网易云音乐图标。',
					),
					'social_netease'  => array(
						'label'   => '网易云音乐链接',
						'type'    => 'url',
						'default' => '',
						'desc'    => '留空时默认链接到 https://music.163.com/。',
					),
					'social_github'   => array(
						'label'   => 'GitHub 链接',
						'type'    => 'url',
						'default' => '',
					),
					'social_weibo'    => array(
						'label'   => '微博链接',
						'type'    => 'url',
						'default' => '',
					),
					'social_bilibili' => array(
						'label'   => '哔哩哔哩链接',
						'type'    => 'url',
						'default' => '',
					),
					'social_email'    => array(
						'label'   => '联系邮箱',
						'type'    => 'email',
						'default' => '',
					),
					'footer_links'    => array(
						'label'   => '底部链接',
						'type'    => 'textarea',
						'default' => '',
						'desc'    => '每行一个，格式：名称|链接',
					),
				),
			),
		),
	),
	'user'     => array(
		'label'    => '用户系统',
		'sections' => array(
			'auth' => array(
				'label'  => '登录注册',
				'fields' => array(
					'auth_enable'     => array(
						'label'   => '启用前台登录注册',
						'type'    => 'switch',
						'default' => true,
					),
					'register_enable' => array(
						'label'   => '允许注册',
						'type'    => 'switch',
						'default' => true,
					),
					'email_verify'    => array(
						'label'   => '注册需邮箱验证',
						'type'    => 'switch',
						'default' => true,
					),
					'user_center'     => array(
						'label'   => '启用前台用户中心',
						'type'    => 'switch',
						'default' => true,
					),
					'login_redirect'  => array(
						'label'   => '登录后跳转链接',
						'type'    => 'url',
						'default' => '',
						'desc'    => '留空跳转用户中心或来源页。',
					),
					'local_avatar'    => array(
						'label'   => '本地首字母头像',
						'type'    => 'switch',
						'default' => true,
						'desc'    => '不依赖 Gravatar，按昵称首字母生成头像；已上传头像的用户仍优先显示自定义头像。',
					),
				),
			),
		),
	),
	'content'  => array(
		'label'    => '页面模板',
		'sections' => array(
			'pages' => array(
				'label'  => '模板参数',
				'fields' => array(
					'books_category' => array(
						'label'   => '书籍推荐分类别名',
						'type'    => 'text',
						'default' => 'books',
					),
					'readers_limit'  => array(
						'label'   => '读者墙显示人数',
						'type'    => 'number',
						'default' => 20,
					),
					'tags_limit'     => array(
						'label'   => '标签页显示数量',
						'type'    => 'number',
						'default' => 120,
					),
					'archive_months' => array(
						'label'   => '归档最多月份',
						'type'    => 'number',
						'default' => 60,
					),
				),
			),
		),
	),
);
