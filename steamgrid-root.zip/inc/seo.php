<?php
/**
 * SEO：描述、canonical、OG、JSON-LD、sitemap.xml、百度自动提交
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ------------------------------------------------------------
 * 描述与 canonical
 * ---------------------------------------------------------- */
function sg_seo_description() {
	$desc = '';

	if ( is_singular() ) {
		$custom = get_post_meta( get_queried_object_id(), '_sg_seo_desc', true );
		if ( $custom ) {
			$desc = $custom;
		} else {
			$desc = wp_strip_all_tags( get_the_excerpt() );
			if ( ! $desc ) {
				$desc = wp_strip_all_tags( get_the_content() );
			}
		}
	} elseif ( is_category() || is_tag() || is_tax() ) {
		$desc = wp_strip_all_tags( term_description() );
	} elseif ( is_author() ) {
		$desc = (string) get_the_author_meta( 'description', get_queried_object_id() );
	} elseif ( is_home() || is_front_page() ) {
		$desc = (string) sg_get( 'seo_desc' );
		if ( ! $desc ) {
			$desc = get_bloginfo( 'description' );
		}
	}

	$desc = trim( preg_replace( '/\s+/u', ' ', (string) $desc ) );
	$desc = wp_strip_all_tags( $desc );

	if ( mb_strlen( $desc ) > 160 ) {
		$desc = mb_substr( $desc, 0, 158 ) . '…';
	}

	if ( ! $desc ) {
		$desc = get_bloginfo( 'name' ) . ' - ' . get_bloginfo( 'description' );
	}

	return $desc;
}

function sg_canonical_url() {
	$url = '';

	if ( is_singular() ) {
		$url = wp_get_canonical_url();
	} elseif ( is_front_page() ) {
		$url = home_url( '/' );
	} elseif ( is_home() ) {
		$page = (int) get_option( 'page_for_posts' );
		$url  = $page ? get_permalink( $page ) : home_url( '/?post_type=post' );
	} elseif ( is_category() || is_tag() || is_tax() ) {
		$url = get_term_link( get_queried_object() );
	} elseif ( is_author() ) {
		$url = get_author_posts_url( get_queried_object_id() );
	} elseif ( is_post_type_archive() ) {
		$url = get_post_type_archive_link( get_query_var( 'post_type' ) );
	} elseif ( is_search() ) {
		$url = home_url( '/?s=' . rawurlencode( get_search_query() ) );
	}

	if ( is_wp_error( $url ) ) {
		$url = '';
	}

	if ( $url && is_paged() ) {
		$paged = max( 1, (int) get_query_var( 'paged' ) );
		$url   = get_pagenum_link( $paged, false );
	}

	return $url;
}

/* ------------------------------------------------------------
 * 头部输出
 * ---------------------------------------------------------- */
function sg_seo_meta_tags() {
	if ( ! sg_on( 'seo_enable' ) ) {
		return;
	}

	$desc = sg_seo_description();
	$url  = sg_canonical_url();

	if ( $desc ) {
		echo '<meta name="description" content="' . esc_attr( $desc ) . '" />' . "\n";
	}
	if ( is_singular() && has_tag() ) {
		$tags = get_the_tags();
		if ( $tags ) {
			echo '<meta name="keywords" content="' . esc_attr( implode( ',', wp_list_pluck( $tags, 'name' ) ) ) . '" />' . "\n";
		}
	}

	if ( sg_on( 'canonical' ) && $url ) {
		echo '<link rel="canonical" href="' . esc_url( $url ) . '" />' . "\n";
	}

	if ( ! sg_on( 'seo_og' ) ) {
		return;
	}

	$title = wp_get_document_title();
	$image = '';

	if ( is_singular() && has_post_thumbnail() ) {
		$image = get_the_post_thumbnail_url( get_queried_object_id(), 'large' );
	}
	if ( ! $image && sg_get( 'hero_image' ) ) {
		$image = sg_get( 'hero_image' );
	}

	$og_type = is_singular() ? 'article' : 'website';

	echo '<meta property="og:type" content="' . esc_attr( $og_type ) . '" />' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $title ) . '" />' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $desc ) . '" />' . "\n";
	echo '<meta property="og:url" content="' . esc_url( $url ? $url : home_url( '/' ) ) . '" />' . "\n";
	echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '" />' . "\n";
	echo '<meta property="og:locale" content="' . esc_attr( get_locale() ) . '" />' . "\n";
	if ( $image ) {
		echo '<meta property="og:image" content="' . esc_url( $image ) . '" />' . "\n";
	}
	echo '<meta name="twitter:card" content="' . ( $image ? 'summary_large_image' : 'summary' ) . '" />' . "\n";
	echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '" />' . "\n";
	echo '<meta name="twitter:description" content="' . esc_attr( $desc ) . '" />' . "\n";
	if ( $image ) {
		echo '<meta name="twitter:image" content="' . esc_url( $image ) . '" />' . "\n";
	}
}
add_action( 'wp_head', 'sg_seo_meta_tags', 2 );

/**
 * 关闭 WP 默认 canonical，避免重复
 */
function sg_remove_core_canonical() {
	if ( sg_on( 'seo_enable' ) && sg_on( 'canonical' ) ) {
		remove_action( 'wp_head', 'rel_canonical' );
	}
}
add_action( 'wp', 'sg_remove_core_canonical' );

/**
 * robots 控制
 *
 * @param array $robots 指令。
 * @return array
 */
function sg_robots( $robots ) {
	if ( sg_on( 'noindex_search' ) && ( is_search() || is_404() ) ) {
		$robots['noindex'] = true;
		$robots['follow']  = true;
	}
	if ( is_paged() && sg_on( 'noindex_search' ) ) {
		$robots['noindex'] = true;
	}
	return $robots;
}
add_filter( 'wp_robots', 'sg_robots' );

/* ------------------------------------------------------------
 * JSON-LD
 * ---------------------------------------------------------- */
function sg_json_ld() {
	if ( ! sg_on( 'seo_enable' ) || ! sg_on( 'seo_jsonld' ) ) {
		return;
	}

	$graph = array();

	if ( is_front_page() || is_home() ) {
		$graph[] = array(
			'@context'        => 'https://schema.org',
			'@type'           => 'WebSite',
			'name'            => get_bloginfo( 'name' ),
			'description'     => sg_seo_description(),
			'url'             => home_url( '/' ),
			'potentialAction' => array(
				'@type'       => 'SearchAction',
				'target'      => home_url( '/?s={search_term_string}' ),
				'query-input' => 'required name=search_term_string',
			),
		);
	}

	if ( is_singular() ) {
		$post_id = get_queried_object_id();
		$image   = has_post_thumbnail( $post_id ) ? get_the_post_thumbnail_url( $post_id, 'large' ) : sg_get( 'hero_image' );

		$article = array(
			'@context'      => 'https://schema.org',
			'@type'         => is_page() ? 'WebPage' : 'Article',
			'headline'      => get_the_title( $post_id ),
			'description'   => sg_seo_description(),
			'url'           => get_permalink( $post_id ),
			'datePublished' => get_the_date( 'c', $post_id ),
			'dateModified'  => get_the_modified_date( 'c', $post_id ),
			'author'        => array(
				'@type' => 'Person',
				'name'  => get_the_author_meta( 'display_name', get_post_field( 'post_author', $post_id ) ),
			),
			'publisher'     => array(
				'@type' => 'Organization',
				'name'  => get_bloginfo( 'name' ),
			),
		);
		if ( $image ) {
			$article['image'] = $image;
		}
		$graph[] = $article;

		$breadcrumb = array(
			'@context'        => 'https://schema.org',
			'@type'           => 'BreadcrumbList',
			'itemListElement' => array(
				array(
					'@type'    => 'ListItem',
					'position' => 1,
					'name'     => get_bloginfo( 'name' ),
					'item'     => home_url( '/' ),
				),
				array(
					'@type'    => 'ListItem',
					'position' => 2,
					'name'     => get_the_title( $post_id ),
					'item'     => get_permalink( $post_id ),
				),
			),
		);
		$graph[] = $breadcrumb;
	}

	if ( $graph ) {
		echo '<script type="application/ld+json">' . wp_json_encode( $graph, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
	}
}
add_action( 'wp_head', 'sg_json_ld', 3 );

/* ------------------------------------------------------------
 * sitemap.xml
 * ---------------------------------------------------------- */
function sg_sitemap_rewrite() {
	add_rewrite_rule( '^sitemap\.xml$', 'index.php?sg_sitemap=1', 'top' );
}
add_action( 'init', 'sg_sitemap_rewrite' );

function sg_sitemap_query_var( $vars ) {
	$vars[] = 'sg_sitemap';
	return $vars;
}
add_filter( 'query_vars', 'sg_sitemap_query_var' );

function sg_sitemap_xml() {
	$urls = array();

	$urls[] = array(
		'loc'        => home_url( '/' ),
		'lastmod'    => gmdate( 'c' ),
		'changefreq' => 'daily',
		'priority'   => '1.0',
	);

	$posts = get_posts(
		array(
			'post_type'      => array( 'post', 'page' ),
			'post_status'    => 'publish',
			'posts_per_page' => 500,
			'orderby'        => 'modified',
			'order'          => 'DESC',
		)
	);

	foreach ( $posts as $post ) {
		$urls[] = array(
			'loc'        => get_permalink( $post ),
			'lastmod'    => gmdate( 'c', strtotime( $post->post_modified_gmt ) ),
			'changefreq' => 'weekly',
			'priority'   => 'post' === $post->post_type ? '0.8' : '0.6',
		);
	}

	$terms = get_terms(
		array(
			'taxonomy'   => array( 'category', 'post_tag' ),
			'hide_empty' => true,
			'number'     => 200,
		)
	);

	if ( ! is_wp_error( $terms ) ) {
		foreach ( $terms as $term ) {
			$urls[] = array(
				'loc'        => get_term_link( $term ),
				'lastmod'    => gmdate( 'c' ),
				'changefreq' => 'weekly',
				'priority'   => '0.4',
			);
		}
	}

	$xml  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
	$xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
	foreach ( $urls as $url ) {
		if ( empty( $url['loc'] ) || is_wp_error( $url['loc'] ) ) {
			continue;
		}
		$xml .= '<url>';
		$xml .= '<loc>' . esc_url( $url['loc'] ) . '</loc>';
		$xml .= '<lastmod>' . esc_html( $url['lastmod'] ) . '</lastmod>';
		$xml .= '<changefreq>' . esc_html( $url['changefreq'] ) . '</changefreq>';
		$xml .= '<priority>' . esc_html( $url['priority'] ) . '</priority>';
		$xml .= '</url>' . "\n";
	}
	$xml .= '</urlset>';

	return $xml;
}

function sg_sitemap_output() {
	if ( ! get_query_var( 'sg_sitemap' ) ) {
		return;
	}
	if ( ! sg_on( 'sitemap_enable' ) ) {
		wp_die( esc_html__( '站点地图未启用。', 'steamgrid' ), '', array( 'response' => 404 ) );
	}

	status_header( 200 );
	header( 'Content-Type: application/xml; charset=UTF-8' );
	echo sg_sitemap_xml(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	exit;
}
add_action( 'template_redirect', 'sg_sitemap_output', 1 );

function sg_robots_txt( $output ) {
	if ( sg_on( 'sitemap_enable' ) ) {
		$output .= "\nSitemap: " . home_url( '/sitemap.xml' ) . "\n";
	}
	return $output;
}
add_filter( 'robots_txt', 'sg_robots_txt' );

/* ------------------------------------------------------------
 * 百度自动链接提交
 * ---------------------------------------------------------- */
function sg_baidu_push( $post_id ) {
	if ( ! sg_on( 'baidu_push' ) ) {
		return;
	}

	$token = sg_get( 'baidu_token' );
	if ( ! $token ) {
		return;
	}

	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
		return;
	}

	$post = get_post( $post_id );
	if ( ! $post || 'publish' !== $post->post_status || 'post' !== $post->post_type ) {
		return;
	}

	$site = home_url( '/' );
	$site = preg_replace( '#^https?://#i', '', rtrim( $site, '/' ) );

	$api = 'http://data.zz.baidu.com/urls?site=' . rawurlencode( $site ) . '&token=' . rawurlencode( $token );

	wp_remote_post(
		$api,
		array(
			'body'     => get_permalink( $post_id ),
			'headers'  => array( 'Content-Type' => 'text/plain' ),
			'timeout'  => 5,
			'blocking' => false,
		)
	);
}
add_action( 'save_post', 'sg_baidu_push', 40, 1 );
