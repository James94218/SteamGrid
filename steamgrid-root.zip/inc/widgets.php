<?php
/**
 * 自定义小工具
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ------------------------------------------------------------
 * 热门文章
 * ---------------------------------------------------------- */
class SG_Widget_Hot_Posts extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'sg_hot_posts',
			__( 'SteamGrid · 热门文章', 'steamgrid' ),
			array( 'description' => __( '按浏览量排序的热门文章。', 'steamgrid' ) )
		);
	}

	public function widget( $args, $instance ) {
		$number = ! empty( $instance['number'] ) ? absint( $instance['number'] ) : 5;
		$title  = ! empty( $instance['title'] ) ? $instance['title'] : __( '热门文章', 'steamgrid' );

		$query = new WP_Query(
			array(
				'posts_per_page'      => $number,
				'meta_key'            => '_sg_views',
				'orderby'             => 'meta_value_num',
				'order'               => 'DESC',
				'ignore_sticky_posts' => true,
			)
		);

		if ( ! $query->have_posts() ) {
			$query = new WP_Query(
				array(
					'posts_per_page'      => $number,
					'ignore_sticky_posts' => true,
				)
			);
		}

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $args['before_title'] . esc_html( $title ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		echo '<ul class="sg-widget-hot">';
		$index = 0;
		while ( $query->have_posts() ) {
			$query->the_post();
			$index++;
			echo '<li>';
			echo '<span class="sg-hot-index' . ( $index <= 3 ? ' is-top' : '' ) . '">' . esc_html( $index ) . '</span>';
			echo '<a class="sg-hot-title" href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a>';
			echo '<span class="sg-hot-views">' . sg_svg_icon( 'eye' ) . esc_html( sg_get_views() ) . '</span>';
			echo '</li>';
		}
		wp_reset_postdata();
		echo '</ul>';

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public function form( $instance ) {
		$title  = isset( $instance['title'] ) ? $instance['title'] : __( '热门文章', 'steamgrid' );
		$number = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( '标题', 'steamgrid' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( '数量', 'steamgrid' ); ?></label>
			<input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="number" min="1" max="20" value="<?php echo esc_attr( $number ); ?>" />
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		return array(
			'title'  => sanitize_text_field( $new_instance['title'] ),
			'number' => absint( $new_instance['number'] ),
		);
	}
}

/* ------------------------------------------------------------
 * 最新评论
 * ---------------------------------------------------------- */
class SG_Widget_Recent_Comments extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'sg_recent_comments',
			__( 'SteamGrid · 最新评论', 'steamgrid' ),
			array( 'description' => __( '带头像的最新评论。', 'steamgrid' ) )
		);
	}

	public function widget( $args, $instance ) {
		$number = ! empty( $instance['number'] ) ? absint( $instance['number'] ) : 5;
		$title  = ! empty( $instance['title'] ) ? $instance['title'] : __( '最新评论', 'steamgrid' );

		$comments = get_comments(
			array(
				'number' => $number,
				'status' => 'approve',
			)
		);

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $args['before_title'] . esc_html( $title ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( $comments ) {
			echo '<ul class="sg-widget-comments">';
			foreach ( $comments as $comment ) {
				$link = get_comment_link( $comment );
				echo '<li>';
				echo '<a class="sg-comment-avatar" href="' . esc_url( $link ) . '">' . get_avatar( $comment, 36 ) . '</a>';
				echo '<div class="sg-comment-text">';
				echo '<a class="sg-comment-author" href="' . esc_url( $link ) . '">' . esc_html( get_comment_author( $comment ) ) . '</a>';
				echo '<span class="sg-comment-excerpt">' . esc_html( wp_trim_words( get_comment_text( $comment ), 12 ) ) . '</span>';
				echo '</div></li>';
			}
			echo '</ul>';
		} else {
			echo '<p class="sg-widget-empty">' . esc_html__( '暂无评论。', 'steamgrid' ) . '</p>';
		}

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public function form( $instance ) {
		$title  = isset( $instance['title'] ) ? $instance['title'] : __( '最新评论', 'steamgrid' );
		$number = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( '标题', 'steamgrid' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( '数量', 'steamgrid' ); ?></label>
			<input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="number" min="1" max="20" value="<?php echo esc_attr( $number ); ?>" />
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		return array(
			'title'  => sanitize_text_field( $new_instance['title'] ),
			'number' => absint( $new_instance['number'] ),
		);
	}
}

/* ------------------------------------------------------------
 * 文章目录
 * ---------------------------------------------------------- */
class SG_Widget_Toc extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'sg_toc',
			__( 'SteamGrid · 文章目录', 'steamgrid' ),
			array( 'description' => __( '在文章页显示多级目录。', 'steamgrid' ) )
		);
	}

	public function widget( $args, $instance ) {
		if ( ! is_singular() ) {
			return;
		}

		$toc = sg_get_current_toc();
		if ( ! $toc ) {
			return;
		}

		$title = ! empty( $instance['title'] ) ? $instance['title'] : __( '文章目录', 'steamgrid' );

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $args['before_title'] . esc_html( $title ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $toc; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? $instance['title'] : __( '文章目录', 'steamgrid' );
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( '标题', 'steamgrid' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		return array( 'title' => sanitize_text_field( $new_instance['title'] ) );
	}
}

/* ------------------------------------------------------------
 * 广告位
 * ---------------------------------------------------------- */
class SG_Widget_Ads extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'sg_ads',
			__( 'SteamGrid · 广告位', 'steamgrid' ),
			array( 'description' => __( '输出后台设置的广告代码。', 'steamgrid' ) )
		);
	}

	public function widget( $args, $instance ) {
		$slot = isset( $instance['slot'] ) ? $instance['slot'] : 'sidebar_top';
		$html = (string) sg_get( 'ad_' . $slot );
		if ( ! $html ) {
			return;
		}

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo do_shortcode( $html ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? $instance['title'] : '';
		$slot  = isset( $instance['slot'] ) ? $instance['slot'] : 'sidebar_top';
		$slots = array(
			'ad_sidebar_top'    => __( '侧边栏顶部', 'steamgrid' ),
			'ad_sidebar_bottom' => __( '侧边栏底部', 'steamgrid' ),
			'ad_header'         => __( '页头下方', 'steamgrid' ),
			'ad_footer'         => __( '页脚', 'steamgrid' ),
		);
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( '标题（可留空）', 'steamgrid' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'slot' ) ); ?>"><?php esc_html_e( '广告位置', 'steamgrid' ); ?></label>
			<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'slot' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'slot' ) ); ?>">
				<?php foreach ( $slots as $value => $label ) : ?>
					<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $slot, $value ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		return array(
			'title' => sanitize_text_field( $new_instance['title'] ),
			'slot'  => sanitize_key( $new_instance['slot'] ),
		);
	}
}

/* ------------------------------------------------------------
 * 站点统计
 * ---------------------------------------------------------- */
class SG_Widget_Stats extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'sg_stats',
			__( 'SteamGrid · 站点统计', 'steamgrid' ),
			array( 'description' => __( '文章、评论、用户与浏览量。', 'steamgrid' ) )
		);
	}

	public function widget( $args, $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : __( '站点统计', 'steamgrid' );

		$post_count    = wp_count_posts()->publish;
		$comment_count = wp_count_comments()->approved;
		$user_count    = count_users()['total_users'];

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $args['before_title'] . esc_html( $title ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		echo '<ul class="sg-widget-stats">';
		echo '<li><span>' . esc_html__( '文章', 'steamgrid' ) . '</span><strong>' . esc_html( number_format_i18n( $post_count ) ) . '</strong></li>';
		echo '<li><span>' . esc_html__( '评论', 'steamgrid' ) . '</span><strong>' . esc_html( number_format_i18n( $comment_count ) ) . '</strong></li>';
		echo '<li><span>' . esc_html__( '用户', 'steamgrid' ) . '</span><strong>' . esc_html( number_format_i18n( $user_count ) ) . '</strong></li>';
		echo '<li><span>' . esc_html__( '运行天数', 'steamgrid' ) . '</span><strong>' . esc_html( number_format_i18n( max( 1, (int) floor( ( time() - strtotime( get_option( 'site_created' ) ?: '2024-01-01' ) ) / DAY_IN_SECONDS ) ) ) ) . '</strong></li>';
		echo '</ul>';

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? $instance['title'] : __( '站点统计', 'steamgrid' );
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( '标题', 'steamgrid' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		return array( 'title' => sanitize_text_field( $new_instance['title'] ) );
	}
}

/* ------------------------------------------------------------
 * 站点名片
 * ---------------------------------------------------------- */
class SG_Widget_Profile extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'sg_profile',
			__( 'SteamGrid · 站点名片', 'steamgrid' ),
			array( 'description' => __( '可自定义头像、名称、个人资料说明、HTML 与 JS。', 'steamgrid' ) )
		);
	}

	public function widget( $args, $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : '';

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( $title ) {
			echo $args['before_title'] . esc_html( $title ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		echo sg_site_card_html( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			array(
				'avatar' => ! empty( $instance['avatar'] ) ? $instance['avatar'] : '',
				'name'   => ! empty( $instance['name'] ) ? $instance['name'] : '',
				'bio'    => ! empty( $instance['bio'] ) ? $instance['bio'] : '',
				'html'   => ! empty( $instance['html'] ) ? $instance['html'] : '',
				'js'     => ! empty( $instance['js'] ) ? $instance['js'] : '',
			)
		);

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public function form( $instance ) {
		$title  = isset( $instance['title'] ) ? $instance['title'] : '';
		$avatar = isset( $instance['avatar'] ) ? $instance['avatar'] : '';
		$name   = isset( $instance['name'] ) ? $instance['name'] : '';
		$bio    = isset( $instance['bio'] ) ? $instance['bio'] : '';
		$html   = isset( $instance['html'] ) ? $instance['html'] : '';
		$js     = isset( $instance['js'] ) ? $instance['js'] : '';
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( '标题（可留空）', 'steamgrid' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'avatar' ) ); ?>"><?php esc_html_e( '头像图片地址', 'steamgrid' ); ?></label>
			<input class="widefat sg-widget-avatar" id="<?php echo esc_attr( $this->get_field_id( 'avatar' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'avatar' ) ); ?>" type="url" value="<?php echo esc_url( $avatar ); ?>" placeholder="https://…" />
			<button type="button" class="button sg-widget-media"><?php esc_html_e( '从媒体库选择', 'steamgrid' ); ?></button>
			<span class="description"><?php esc_html_e( '留空时使用「主题设置 → 基础设置 → 站点名片」中的头像。', 'steamgrid' ); ?></span>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'name' ) ); ?>"><?php esc_html_e( '名称', 'steamgrid' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'name' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'name' ) ); ?>" type="text" value="<?php echo esc_attr( $name ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'bio' ) ); ?>"><?php esc_html_e( '个人资料说明', 'steamgrid' ); ?></label>
			<textarea class="widefat" rows="4" id="<?php echo esc_attr( $this->get_field_id( 'bio' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'bio' ) ); ?>"><?php echo esc_textarea( $bio ); ?></textarea>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'html' ) ); ?>"><?php esc_html_e( '自定义 HTML', 'steamgrid' ); ?></label>
			<textarea class="widefat code" rows="4" id="<?php echo esc_attr( $this->get_field_id( 'html' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'html' ) ); ?>"><?php echo esc_textarea( $html ); ?></textarea>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'js' ) ); ?>"><?php esc_html_e( '自定义 JS', 'steamgrid' ); ?></label>
			<textarea class="widefat code" rows="4" id="<?php echo esc_attr( $this->get_field_id( 'js' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'js' ) ); ?>"><?php echo esc_textarea( $js ); ?></textarea>
			<span class="description"><?php esc_html_e( '无需 script 标签，直接填写脚本内容。', 'steamgrid' ); ?></span>
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		return array(
			'title'  => sanitize_text_field( $new_instance['title'] ),
			'avatar' => esc_url_raw( $new_instance['avatar'] ),
			'name'   => sanitize_text_field( $new_instance['name'] ),
			'bio'    => sanitize_textarea_field( $new_instance['bio'] ),
			'html'   => wp_unslash( (string) $new_instance['html'] ),
			'js'     => sg_sanitize_js( $new_instance['js'] ),
		);
	}
}

/**
 * 注册小工具
 */
function sg_register_widgets() {
	register_widget( 'SG_Widget_Hot_Posts' );
	register_widget( 'SG_Widget_Recent_Comments' );
	register_widget( 'SG_Widget_Toc' );
	register_widget( 'SG_Widget_Ads' );
	register_widget( 'SG_Widget_Stats' );
	register_widget( 'SG_Widget_Profile' );
}
add_action( 'widgets_init', 'sg_register_widgets' );

/**
 * 小工具页加载媒体库，用于站点名片选择头像
 *
 * @param string $hook 当前页面。
 */
function sg_widgets_admin_assets( $hook ) {
	if ( 'widgets.php' !== $hook ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_script( 'sg-widgets-admin', SG_URI . '/assets/js/widgets-admin.js', array( 'jquery' ), SG_VERSION, true );
}
add_action( 'admin_enqueue_scripts', 'sg_widgets_admin_assets' );
