<?php
/**
 * 站点名片渲染（主题设置、小工具与 [site_card] 短代码共用）
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 名片数据（参数优先于主题设置）
 *
 * @param array $args 参数。
 * @return array
 */
function sg_site_card_data( $args = array() ) {
	$args = wp_parse_args(
		$args,
		array(
			'avatar'      => '',
			'name'        => '',
			'bio'         => '',
			'html'        => '',
			'js'          => '',
			'show_social' => true,
		)
	);

	$avatar = $args['avatar'] ? $args['avatar'] : sg_get( 'card_avatar' );
	$name   = $args['name'] ? $args['name'] : sg_get( 'card_name' );
	$bio    = $args['bio'] ? $args['bio'] : sg_get( 'card_bio' );
	$html   = $args['html'] ? $args['html'] : sg_get( 'card_html' );
	$js     = $args['js'] ? $args['js'] : sg_get( 'card_js' );

	if ( ! $name ) {
		$name = get_bloginfo( 'name' );
	}
	if ( ! $bio ) {
		$bio = get_bloginfo( 'description' );
	}

	return array(
		'avatar'      => $avatar,
		'name'        => $name,
		'bio'         => $bio,
		'html'        => $html,
		'js'          => $js,
		'show_social' => (bool) $args['show_social'],
	);
}

/**
 * 站点名片 HTML
 *
 * @param array $args 参数。
 * @return string
 */
function sg_site_card_html( $args = array() ) {
	static $rendering = false;

	if ( $rendering ) {
		return '';
	}

	$rendering = true;
	$data      = sg_site_card_data( $args );

	$html = '<div class="sg-profile-card">';

	if ( $data['avatar'] ) {
		$html .= '<div class="sg-profile-avatar"><img src="' . esc_url( $data['avatar'] ) . '" alt="' . esc_attr( $data['name'] ) . '" loading="lazy" width="72" height="72" /></div>';
	} elseif ( has_custom_logo() ) {
		$html .= '<div class="sg-profile-logo">' . get_custom_logo() . '</div>';
	} else {
		$html .= '<div class="sg-profile-mark">' . esc_html( mb_substr( get_bloginfo( 'name' ), 0, 1 ) ) . '</div>';
	}

	$html .= '<div class="sg-profile-name">' . esc_html( $data['name'] ) . '</div>';

	if ( $data['bio'] ) {
		$html .= '<p class="sg-profile-desc">' . nl2br( esc_html( $data['bio'] ) ) . '</p>';
	}

	if ( $data['show_social'] ) {
		$social = sg_social_links();
		if ( $social ) {
			$html .= '<div class="sg-profile-social">';
			foreach ( $social as $item ) {
				$html .= '<a href="' . esc_url( $item['url'] ) . '" target="_blank" rel="noopener nofollow" aria-label="' . esc_attr( $item['label'] ) . '">' . sg_svg_icon( $item['icon'] ) . '</a>';
			}
			$html .= '</div>';
		}
	}

	if ( $data['html'] ) {
		$html .= '<div class="sg-profile-html">' . do_shortcode( $data['html'] ) . '</div>';
	}

	$html .= '</div>';

	if ( $data['js'] ) {
		$html .= '<script>' . sg_sanitize_js( $data['js'] ) . '</script>';
	}

	$rendering = false;

	return $html;
}
