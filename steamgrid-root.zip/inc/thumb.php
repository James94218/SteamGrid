<?php
/**
 * 缩略图伪静态：/sg-thumb/{附件ID}-{宽}x{高}.jpg
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function sg_thumb_rewrite() {
	add_rewrite_rule(
		'^sg-thumb/([0-9]+)-([0-9]+)x([0-9]+)\.(jpg|jpeg|png|webp)$',
		'index.php?sg_thumb=1&sg_thumb_id=$matches[1]&sg_thumb_w=$matches[2]&sg_thumb_h=$matches[3]',
		'top'
	);
}
add_action( 'init', 'sg_thumb_rewrite' );

function sg_thumb_query_vars( $vars ) {
	$vars[] = 'sg_thumb';
	$vars[] = 'sg_thumb_id';
	$vars[] = 'sg_thumb_w';
	$vars[] = 'sg_thumb_h';
	return $vars;
}
add_filter( 'query_vars', 'sg_thumb_query_vars' );

/**
 * 缩略图地址
 *
 * @param int $post_id 文章或附件 ID。
 * @param int $width   宽。
 * @param int $height  高。
 * @return string
 */
function sg_thumb_url( $post_id = 0, $width = 480, $height = 270 ) {
	$post_id   = $post_id ? (int) $post_id : get_the_ID();
	$thumb_id  = get_post_thumbnail_id( $post_id );
	$is_attach = 'attachment' === get_post_type( $post_id );

	if ( $is_attach ) {
		$thumb_id = $post_id;
	}

	if ( ! $thumb_id ) {
		return '';
	}

	if ( ! sg_on( 'thumb_enable' ) || ! get_option( 'permalink_structure' ) ) {
		$url = wp_get_attachment_image_url( $thumb_id, array( $width, $height ) );
		if ( $url ) {
			return $url;
		}
		return (string) wp_get_attachment_url( $thumb_id );
	}

	return home_url( '/sg-thumb/' . $thumb_id . '-' . (int) $width . 'x' . (int) $height . '.jpg' );
}

/**
 * 输出伪静态缩略图
 */
function sg_thumb_maybe_serve() {
	if ( ! get_query_var( 'sg_thumb' ) ) {
		return;
	}

	if ( ! sg_on( 'thumb_enable' ) ) {
		status_header( 404 );
		exit;
	}

	$id     = absint( get_query_var( 'sg_thumb_id' ) );
	$width  = min( 2400, max( 16, absint( get_query_var( 'sg_thumb_w' ) ) ) );
	$height = min( 2400, max( 16, absint( get_query_var( 'sg_thumb_h' ) ) ) );

	if ( ! $id || ! $width || ! $height ) {
		status_header( 404 );
		exit;
	}

	$post = get_post( $id );
	if ( ! $post ) {
		status_header( 404 );
		exit;
	}

	if ( 'attachment' === $post->post_type ) {
		$file = get_attached_file( $id );
	} else {
		$thumb_id = get_post_thumbnail_id( $id );
		$file     = $thumb_id ? get_attached_file( $thumb_id ) : '';
	}

	if ( ! $file || ! file_exists( $file ) ) {
		status_header( 404 );
		exit;
	}

	$uploads = wp_upload_dir();
	if ( ! empty( $uploads['error'] ) ) {
		status_header( 500 );
		exit;
	}

	$dir = trailingslashit( $uploads['basedir'] ) . 'sg-thumb';
	if ( ! wp_mkdir_p( $dir ) ) {
		status_header( 500 );
		exit;
	}

	$cache_file = trailingslashit( $dir ) . $id . '-' . $width . 'x' . $height . '.jpg';

	if ( ! file_exists( $cache_file ) || filemtime( $cache_file ) < filemtime( $file ) ) {
		$editor = wp_get_image_editor( $file );
		if ( is_wp_error( $editor ) ) {
			status_header( 500 );
			exit;
		}

		$editor->resize( $width, $height, true );
		$editor->set_quality( min( 100, max( 30, absint( sg_get( 'thumb_quality', 82 ) ) ) ) );

		$saved = $editor->save( $cache_file, 'image/jpeg' );
		if ( is_wp_error( $saved ) ) {
			status_header( 500 );
			exit;
		}
	}

	$mime = 'image/jpeg';
	$size = filesize( $cache_file );

	nocache_headers();
	header( 'Content-Type: ' . $mime );
	header( 'Content-Length: ' . $size );
	header( 'Cache-Control: public, max-age=2592000, immutable' );
	header( 'X-SG-Thumb: 1' );

	readfile( $cache_file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_readfile
	exit;
}
add_action( 'template_redirect', 'sg_thumb_maybe_serve', 2 );
