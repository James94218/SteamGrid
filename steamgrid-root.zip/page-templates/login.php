<?php
/**
 * Template Name: 用户登录
 * Template Post Type: page
 *
 * @package SteamGrid
 */

get_header();

$sg_msg = sg_get_auth_message();
?>
<div class="sg-container sg-page sg-auth-page">
	<div class="sg-auth-card">
		<div class="sg-auth-brand">
			<span class="sg-auth-mark"><?php echo esc_html( mb_substr( get_bloginfo( 'name' ), 0, 1 ) ); ?></span>
			<h1 class="sg-auth-title"><?php esc_html_e( '登录', 'steamgrid' ); ?></h1>
			<p class="sg-auth-desc"><?php echo esc_html( get_bloginfo( 'description' ) ); ?></p>
		</div>

		<?php if ( $sg_msg['text'] ) : ?>
			<div class="sg-auth-alert sg-auth-alert-<?php echo esc_attr( $sg_msg['type'] ); ?>"><?php echo esc_html( $sg_msg['text'] ); ?></div>
		<?php endif; ?>

		<?php if ( ! sg_on( 'auth_enable' ) ) : ?>
			<p class="sg-auth-alert sg-auth-alert-error"><?php esc_html_e( '前台登录功能未开启。', 'steamgrid' ); ?></p>
		<?php else : ?>
			<form method="post" class="sg-form sg-auth-form" action="<?php echo esc_url( get_permalink() ); ?>">
				<?php wp_nonce_field( 'sg_auth', 'sg_nonce' ); ?>
				<input type="hidden" name="sg_action" value="login" />

				<p class="sg-form-item">
					<label for="sg-login-user"><?php esc_html_e( '用户名或邮箱', 'steamgrid' ); ?></label>
					<input type="text" id="sg-login-user" name="log" required autocomplete="username" placeholder="<?php esc_attr_e( '请输入用户名或邮箱', 'steamgrid' ); ?>" />
				</p>

				<p class="sg-form-item">
					<label for="sg-login-pass"><?php esc_html_e( '密码', 'steamgrid' ); ?></label>
					<input type="password" id="sg-login-pass" name="pwd" required autocomplete="current-password" placeholder="<?php esc_attr_e( '请输入密码', 'steamgrid' ); ?>" />
				</p>

				<?php echo sg_captcha_field( 'login' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

				<div class="sg-form-row">
					<label class="sg-checkbox"><input type="checkbox" name="remember" value="1" /> <?php esc_html_e( '记住我', 'steamgrid' ); ?></label>
					<a href="<?php echo esc_url( sg_auth_url( 'lostpass' ) ); ?>"><?php esc_html_e( '忘记密码？', 'steamgrid' ); ?></a>
				</div>

				<button type="submit" class="sg-btn sg-btn-block"><?php esc_html_e( '登录', 'steamgrid' ); ?></button>
			</form>

			<?php if ( sg_on( 'register_enable' ) ) : ?>
				<p class="sg-auth-switch"><?php esc_html_e( '还没有账号？', 'steamgrid' ); ?><a href="<?php echo esc_url( sg_auth_url( 'register' ) ); ?>"><?php esc_html_e( '立即注册', 'steamgrid' ); ?></a></p>
			<?php endif; ?>
		<?php endif; ?>
	</div>
</div>
<?php
get_footer();
