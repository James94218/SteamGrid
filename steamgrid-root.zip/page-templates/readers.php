<?php
/**
 * Template Name: 读者墙
 * Template Post Type: page
 *
 * @package SteamGrid
 */

get_header();

$sg_limit    = max( 5, absint( sg_get( 'readers_limit', 20 ) ) );
$sg_comments = get_comments(
	array(
		'number' => 500,
		'status' => 'approve',
		'type'   => 'comment',
	)
);

$sg_readers = array();
foreach ( $sg_comments as $sg_comment ) {
	$sg_email = $sg_comment->comment_author_email;
	$sg_key   = $sg_email ? md5( strtolower( $sg_email ) ) : md5( $sg_comment->comment_author );
	if ( ! isset( $sg_readers[ $sg_key ] ) ) {
		$sg_readers[ $sg_key ] = array(
			'name'    => $sg_comment->comment_author,
			'email'   => $sg_email,
			'url'     => $sg_comment->comment_author_url,
			'count'   => 0,
			'avatar'  => get_avatar_url( $sg_comment, array( 'size' => 96 ) ),
			'post_id' => (int) $sg_comment->comment_post_ID,
		);
	}
	$sg_readers[ $sg_key ]['count']++;
}

uasort(
	$sg_readers,
	function ( $a, $b ) {
		return $b['count'] <=> $a['count'];
	}
);

$sg_readers = array_slice( $sg_readers, 0, $sg_limit, true );
?>
<div class="sg-container sg-page">
	<div class="sg-page-head">
		<h1 class="sg-page-title"><?php esc_html_e( '读者墙', 'steamgrid' ); ?></h1>
		<p class="sg-page-desc"><?php esc_html_e( '最活跃的评论读者，按评论数量排序。', 'steamgrid' ); ?></p>
	</div>

	<?php if ( $sg_readers ) : ?>
		<div class="sg-readers-grid">
			<?php foreach ( $sg_readers as $sg_reader ) : ?>
				<div class="sg-reader">
					<img class="sg-reader-avatar" src="<?php echo esc_url( $sg_reader['avatar'] ); ?>" alt="<?php echo esc_attr( $sg_reader['name'] ); ?>" loading="lazy" width="72" height="72" />
					<div class="sg-reader-name"><?php echo esc_html( $sg_reader['name'] ); ?></div>
					<div class="sg-reader-count"><?php echo esc_html( $sg_reader['count'] ); ?> <?php esc_html_e( '条评论', 'steamgrid' ); ?></div>
				</div>
			<?php endforeach; ?>
		</div>
	<?php else : ?>
		<p class="sg-widget-empty"><?php esc_html_e( '还没有读者数据。', 'steamgrid' ); ?></p>
	<?php endif; ?>
</div>
<?php
get_footer();
