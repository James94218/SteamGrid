<?php
/**
 * Template Name: 找回密码
 * Template Post Type: page
 *
 * @package SteamGrid
 */

get_header();

$sg_msg = sg_get_auth_message();
?>
<div class="sg-container sg-page sg-auth-page">
	<div class="sg-auth-card">
		<div class="sg-auth-brand">
			<span class="sg-auth-mark"><?php echo esc_html( mb_substr( get_bloginfo( 'name' ), 0, 1 ) ); ?></span>
			<h1 class="sg-auth-title"><?php esc_html_e( '找回密码', 'steamgrid' ); ?></h1>
			<p class="sg-auth-desc"><?php esc_html_e( '输入用户名或邮箱，我们会发送重置密码链接。', 'steamgrid' ); ?></p>
		</div>

		<?php if ( $sg_msg['text'] ) : ?>
			<div class="sg-auth-alert sg-auth-alert-<?php echo esc_attr( $sg_msg['type'] ); ?>"><?php echo esc_html( $sg_msg['text'] ); ?></div>
		<?php endif; ?>

		<?php if ( ! sg_on( 'auth_enable' ) ) : ?>
			<p class="sg-auth-alert sg-auth-alert-error"><?php esc_html_e( '该功能暂未开启。', 'steamgrid' ); ?></p>
		<?php else : ?>
			<form method="post" class="sg-form sg-auth-form" action="<?php echo esc_url( get_permalink() ); ?>">
				<?php wp_nonce_field( 'sg_auth', 'sg_nonce' ); ?>
				<input type="hidden" name="sg_action" value="lostpass" />

				<p class="sg-form-item">
					<label for="sg-lost-user"><?php esc_html_e( '用户名或邮箱', 'steamgrid' ); ?></label>
					<input type="text" id="sg-lost-user" name="user_login" required autocomplete="username" placeholder="<?php esc_attr_e( '请输入用户名或邮箱', 'steamgrid' ); ?>" />
				</p>

				<button type="submit" class="sg-btn sg-btn-block"><?php esc_html_e( '发送重置邮件', 'steamgrid' ); ?></button>
			</form>

			<p class="sg-auth-switch"><?php esc_html_e( '想起密码了？', 'steamgrid' ); ?><a href="<?php echo esc_url( sg_auth_url( 'login' ) ); ?>"><?php esc_html_e( '返回登录', 'steamgrid' ); ?></a></p>
		<?php endif; ?>
	</div>
</div>
<?php
get_footer();
