<?php
/**
 * Template Name: 站点地图
 * Template Post Type: page
 *
 * @package SteamGrid
 */

get_header();

$sg_sitemap_posts = new WP_Query(
	array(
		'posts_per_page'      => 100,
		'ignore_sticky_posts' => true,
	)
);
?>
<div class="sg-container sg-page">
	<div class="sg-page-head">
		<h1 class="sg-page-title"><?php esc_html_e( '站点地图', 'steamgrid' ); ?></h1>
		<p class="sg-page-desc"><?php esc_html_e( '全部页面、分类与最新文章索引。', 'steamgrid' ); ?></p>
	</div>

	<div class="sg-sitemap-block">
		<h2><?php esc_html_e( '页面', 'steamgrid' ); ?></h2>
		<ul class="sg-sitemap-list">
			<?php
			wp_list_pages(
				array(
					'title_li' => '',
					'depth'    => 2,
				)
			);
			?>
		</ul>
	</div>

	<div class="sg-sitemap-block">
		<h2><?php esc_html_e( '分类', 'steamgrid' ); ?></h2>
		<ul class="sg-sitemap-list">
			<?php
			wp_list_categories(
				array(
					'title_li'   => '',
					'show_count' => true,
					'hide_empty' => true,
					'depth'      => 2,
				)
			);
			?>
		</ul>
	</div>

	<div class="sg-sitemap-block">
		<h2><?php esc_html_e( '最新文章', 'steamgrid' ); ?></h2>
		<ul class="sg-sitemap-list">
			<?php
			if ( $sg_sitemap_posts->have_posts() ) :
				while ( $sg_sitemap_posts->have_posts() ) :
					$sg_sitemap_posts->the_post();
					?>
					<li>
						<a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html( get_the_title() ); ?></a>
						<span> · <?php echo esc_html( get_the_date() ); ?></span>
					</li>
					<?php
				endwhile;
				wp_reset_postdata();
			endif;
			?>
		</ul>
	</div>

	<div class="sg-sitemap-block">
		<h2><?php esc_html_e( '按月归档', 'steamgrid' ); ?></h2>
		<ul class="sg-sitemap-list">
			<?php
			wp_get_archives(
				array(
					'type'  => 'monthly',
					'limit' => 24,
				)
			);
			?>
		</ul>
	</div>
</div>
<?php
get_footer();
