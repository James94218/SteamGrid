<?php
/**
 * Template Name: 用户注册
 * Template Post Type: page
 *
 * @package SteamGrid
 */

get_header();

$sg_msg = sg_get_auth_message();
?>
<div class="sg-container sg-page sg-auth-page">
	<div class="sg-auth-card">
		<div class="sg-auth-brand">
			<span class="sg-auth-mark"><?php echo esc_html( mb_substr( get_bloginfo( 'name' ), 0, 1 ) ); ?></span>
			<h1 class="sg-auth-title"><?php esc_html_e( '注册账号', 'steamgrid' ); ?></h1>
			<p class="sg-auth-desc"><?php echo esc_html( get_bloginfo( 'description' ) ); ?></p>
		</div>

		<?php if ( $sg_msg['text'] ) : ?>
			<div class="sg-auth-alert sg-auth-alert-<?php echo esc_attr( $sg_msg['type'] ); ?>"><?php echo esc_html( $sg_msg['text'] ); ?></div>
		<?php endif; ?>

		<?php if ( ! sg_on( 'auth_enable' ) || ! sg_on( 'register_enable' ) ) : ?>
			<p class="sg-auth-alert sg-auth-alert-error"><?php esc_html_e( '注册功能暂未开启。', 'steamgrid' ); ?></p>
		<?php else : ?>
			<form method="post" class="sg-form sg-auth-form" action="<?php echo esc_url( get_permalink() ); ?>">
				<?php wp_nonce_field( 'sg_auth', 'sg_nonce' ); ?>
				<input type="hidden" name="sg_action" value="register" />

				<p class="sg-form-item">
					<label for="sg-register-user"><?php esc_html_e( '用户名', 'steamgrid' ); ?></label>
					<input type="text" id="sg-register-user" name="user_login" required autocomplete="username" minlength="3" placeholder="<?php esc_attr_e( '至少 3 个字符', 'steamgrid' ); ?>" />
				</p>

				<p class="sg-form-item">
					<label for="sg-register-email"><?php esc_html_e( '邮箱', 'steamgrid' ); ?></label>
					<input type="email" id="sg-register-email" name="user_email" required autocomplete="email" placeholder="you@example.com" />
				</p>

				<p class="sg-form-item">
					<label for="sg-register-pass"><?php esc_html_e( '密码', 'steamgrid' ); ?></label>
					<input type="password" id="sg-register-pass" name="user_pass" required autocomplete="new-password" minlength="6" placeholder="<?php esc_attr_e( '至少 6 位', 'steamgrid' ); ?>" />
				</p>

				<p class="sg-form-item">
					<label for="sg-register-pass2"><?php esc_html_e( '确认密码', 'steamgrid' ); ?></label>
					<input type="password" id="sg-register-pass2" name="user_pass2" required autocomplete="new-password" minlength="6" placeholder="<?php esc_attr_e( '再次输入密码', 'steamgrid' ); ?>" />
				</p>

				<?php echo sg_captcha_field( 'register' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

				<label class="sg-checkbox"><input type="checkbox" name="agree" value="1" required /> <?php esc_html_e( '我已阅读并同意本站条款', 'steamgrid' ); ?></label>

				<button type="submit" class="sg-btn sg-btn-block"><?php esc_html_e( '注册', 'steamgrid' ); ?></button>
			</form>

			<p class="sg-auth-switch"><?php esc_html_e( '已有账号？', 'steamgrid' ); ?><a href="<?php echo esc_url( sg_auth_url( 'login' ) ); ?>"><?php esc_html_e( '去登录', 'steamgrid' ); ?></a></p>
		<?php endif; ?>
	</div>
</div>
<?php
get_footer();
