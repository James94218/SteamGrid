<?php
/**
 * Template Name: 标签云
 * Template Post Type: page
 *
 * @package SteamGrid
 */

get_header();

$sg_tags = get_tags(
	array(
		'number'     => absint( sg_get( 'tags_limit', 120 ) ),
		'orderby'    => 'count',
		'order'      => 'DESC',
		'hide_empty' => true,
	)
);
?>
<div class="sg-container sg-page">
	<div class="sg-main-grid">
		<div class="sg-content-area">
			<div class="sg-page-head">
				<h1 class="sg-page-title"><?php esc_html_e( '标签云', 'steamgrid' ); ?></h1>
				<p class="sg-page-desc"><?php esc_html_e( '按文章数量排序的全部标签。', 'steamgrid' ); ?></p>
			</div>

			<?php if ( $sg_tags ) : ?>
				<div class="sg-tag-page">
					<?php foreach ( $sg_tags as $sg_tag ) : ?>
						<a class="sg-tag-chip" href="<?php echo esc_url( get_tag_link( $sg_tag ) ); ?>">
							<?php echo sg_svg_icon( 'tag' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<span><?php echo esc_html( $sg_tag->name ); ?></span>
							<em><?php echo esc_html( number_format_i18n( $sg_tag->count ) ); ?></em>
						</a>
					<?php endforeach; ?>
				</div>
			<?php else : ?>
				<p class="sg-widget-empty"><?php esc_html_e( '还没有创建标签。', 'steamgrid' ); ?></p>
			<?php endif; ?>
		</div>
		<?php get_sidebar(); ?>
	</div>
</div>
<?php
get_footer();
