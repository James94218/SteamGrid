<?php
/**
 * Template Name: 用户中心
 * Template Post Type: page
 *
 * @package SteamGrid
 */

if ( ! is_user_logged_in() ) {
	wp_safe_redirect( sg_auth_url( 'login' ) );
	exit;
}

get_header();

$sg_user       = wp_get_current_user();
$sg_msg        = sg_get_auth_message();
$sg_tab        = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'profile'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$sg_allowed    = array( 'profile', 'password', 'posts', 'comments' );
$sg_tab        = in_array( $sg_tab, $sg_allowed, true ) ? $sg_tab : 'profile';
$sg_avatar     = sg_user_avatar_url( $sg_user->ID, 128 );
$sg_posts_num  = count_user_posts( $sg_user->ID );
$sg_comments   = get_comments(
	array(
		'author_email' => $sg_user->user_email,
		'status'       => 'approve',
		'number'       => 999,
		'count'        => true,
	)
);
?>
<div class="sg-container sg-page sg-user-center">

	<div class="sg-uc-head">
		<div class="sg-uc-avatar">
			<img src="<?php echo esc_url( $sg_avatar ); ?>" alt="<?php echo esc_attr( $sg_user->display_name ); ?>" width="96" height="96" />
		</div>
		<div class="sg-uc-info">
			<h1 class="sg-uc-name"><?php echo esc_html( $sg_user->display_name ); ?></h1>
			<p class="sg-uc-meta">
				<span>@<?php echo esc_html( $sg_user->user_login ); ?></span>
				<span><?php echo esc_html( $sg_user->user_email ); ?></span>
				<?php if ( sg_is_email_verified( $sg_user->ID ) ) : ?>
					<span class="sg-uc-badge is-ok"><?php esc_html_e( '已验证', 'steamgrid' ); ?></span>
				<?php else : ?>
					<span class="sg-uc-badge"><?php esc_html_e( '未验证', 'steamgrid' ); ?></span>
				<?php endif; ?>
			</p>
			<p class="sg-uc-stats">
				<span><?php echo esc_html( number_format_i18n( $sg_posts_num ) ); ?> <?php esc_html_e( '文章', 'steamgrid' ); ?></span>
				<span><?php echo esc_html( number_format_i18n( (int) $sg_comments ) ); ?> <?php esc_html_e( '评论', 'steamgrid' ); ?></span>
			</p>
		</div>
		<div class="sg-uc-actions">
			<a class="sg-btn sg-btn-ghost" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( '返回首页', 'steamgrid' ); ?></a>
			<?php if ( current_user_can( 'edit_posts' ) ) : ?>
				<a class="sg-btn sg-btn-ghost" href="<?php echo esc_url( admin_url() ); ?>"><?php esc_html_e( 'WordPress 后台', 'steamgrid' ); ?></a>
			<?php endif; ?>
			<?php if ( current_user_can( 'manage_options' ) ) : ?>
				<a class="sg-btn sg-btn-ghost" href="<?php echo esc_url( admin_url( 'admin.php?page=steamgrid-settings' ) ); ?>"><?php esc_html_e( '主题设置', 'steamgrid' ); ?></a>
			<?php endif; ?>
			<a class="sg-btn" href="<?php echo esc_url( wp_logout_url( sg_auth_url( 'login' ) ) ); ?>"><?php esc_html_e( '退出登录', 'steamgrid' ); ?></a>
		</div>
	</div>

	<?php if ( $sg_msg['text'] ) : ?>
		<div class="sg-auth-alert sg-auth-alert-<?php echo esc_attr( $sg_msg['type'] ); ?>"><?php echo esc_html( $sg_msg['text'] ); ?></div>
	<?php endif; ?>

	<div class="sg-uc-layout">
		<nav class="sg-uc-tabs" aria-label="<?php esc_attr_e( '用户中心导航', 'steamgrid' ); ?>">
			<a class="<?php echo 'profile' === $sg_tab ? 'is-active' : ''; ?>" href="<?php echo esc_url( sg_user_center_tab_url( 'profile' ) ); ?>"><?php esc_html_e( '资料设置', 'steamgrid' ); ?></a>
			<a class="<?php echo 'password' === $sg_tab ? 'is-active' : ''; ?>" href="<?php echo esc_url( sg_user_center_tab_url( 'password' ) ); ?>"><?php esc_html_e( '修改密码', 'steamgrid' ); ?></a>
			<a class="<?php echo 'posts' === $sg_tab ? 'is-active' : ''; ?>" href="<?php echo esc_url( sg_user_center_tab_url( 'posts' ) ); ?>"><?php esc_html_e( '我的文章', 'steamgrid' ); ?></a>
			<a class="<?php echo 'comments' === $sg_tab ? 'is-active' : ''; ?>" href="<?php echo esc_url( sg_user_center_tab_url( 'comments' ) ); ?>"><?php esc_html_e( '我的评论', 'steamgrid' ); ?></a>
		</nav>

		<div class="sg-uc-panel">
			<?php if ( 'profile' === $sg_tab ) : ?>
				<form method="post" class="sg-form" enctype="multipart/form-data" action="<?php echo esc_url( get_permalink() ); ?>">
					<?php wp_nonce_field( 'sg_auth', 'sg_nonce' ); ?>
					<input type="hidden" name="sg_action" value="profile" />

					<div class="sg-form-item sg-avatar-upload">
						<label for="sg-avatar"><?php esc_html_e( '头像', 'steamgrid' ); ?></label>
						<div class="sg-avatar-row">
							<img src="<?php echo esc_url( $sg_avatar ); ?>" alt="" width="64" height="64" />
							<input type="file" id="sg-avatar" name="sg_avatar" accept="image/*" />
						</div>
					</div>

					<p class="sg-form-item">
						<label for="sg-display-name"><?php esc_html_e( '昵称', 'steamgrid' ); ?></label>
						<input type="text" id="sg-display-name" name="display_name" value="<?php echo esc_attr( $sg_user->display_name ); ?>" />
					</p>

					<p class="sg-form-item">
						<label for="sg-user-url"><?php esc_html_e( '个人网站', 'steamgrid' ); ?></label>
						<input type="url" id="sg-user-url" name="user_url" value="<?php echo esc_url( $sg_user->user_url ); ?>" placeholder="https://…" />
					</p>

					<p class="sg-form-item">
						<label for="sg-user-desc"><?php esc_html_e( '个人简介', 'steamgrid' ); ?></label>
						<textarea id="sg-user-desc" name="description" rows="4"><?php echo esc_textarea( $sg_user->description ); ?></textarea>
					</p>

					<button type="submit" class="sg-btn"><?php esc_html_e( '保存资料', 'steamgrid' ); ?></button>
				</form>

			<?php elseif ( 'password' === $sg_tab ) : ?>
				<form method="post" class="sg-form sg-form-narrow" action="<?php echo esc_url( get_permalink() ); ?>">
					<?php wp_nonce_field( 'sg_auth', 'sg_nonce' ); ?>
					<input type="hidden" name="sg_action" value="password" />

					<p class="sg-form-item">
						<label for="sg-current-pass"><?php esc_html_e( '当前密码', 'steamgrid' ); ?></label>
						<input type="password" id="sg-current-pass" name="current_password" required autocomplete="current-password" />
					</p>
					<p class="sg-form-item">
						<label for="sg-new-pass"><?php esc_html_e( '新密码', 'steamgrid' ); ?></label>
						<input type="password" id="sg-new-pass" name="new_password" required minlength="6" autocomplete="new-password" />
					</p>
					<p class="sg-form-item">
						<label for="sg-confirm-pass"><?php esc_html_e( '确认新密码', 'steamgrid' ); ?></label>
						<input type="password" id="sg-confirm-pass" name="confirm_password" required minlength="6" autocomplete="new-password" />
					</p>

					<button type="submit" class="sg-btn"><?php esc_html_e( '修改密码', 'steamgrid' ); ?></button>
				</form>

			<?php elseif ( 'posts' === $sg_tab ) : ?>
				<?php
				$sg_my_posts = new WP_Query(
					array(
						'author'         => $sg_user->ID,
						'posts_per_page' => 10,
						'post_status'    => array( 'publish', 'pending', 'draft' ),
					)
				);
				?>
				<?php if ( $sg_my_posts->have_posts() ) : ?>
					<ul class="sg-uc-list">
						<?php while ( $sg_my_posts->have_posts() ) : ?>
							<?php $sg_my_posts->the_post(); ?>
							<li>
								<a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a>
								<span class="sg-uc-list-meta"><?php echo esc_html( get_the_date() ); ?> · <?php echo esc_html( sg_comment_count_text() ); ?></span>
							</li>
						<?php endwhile; ?>
					</ul>
					<?php wp_reset_postdata(); ?>
				<?php else : ?>
					<p class="sg-widget-empty"><?php esc_html_e( '你还没有发布文章。', 'steamgrid' ); ?></p>
				<?php endif; ?>

			<?php else : ?>
				<?php
				$sg_my_comments = get_comments(
					array(
						'author_email' => $sg_user->user_email,
						'status'       => 'approve',
						'number'       => 10,
					)
				);
				?>
				<?php if ( $sg_my_comments ) : ?>
					<ul class="sg-uc-list">
						<?php foreach ( $sg_my_comments as $sg_comment ) : ?>
							<li>
								<a href="<?php echo esc_url( get_comment_link( $sg_comment ) ); ?>"><?php echo esc_html( wp_trim_words( get_comment_text( $sg_comment ), 24 ) ); ?></a>
								<span class="sg-uc-list-meta"><?php echo esc_html( get_comment_date( '', $sg_comment ) ); ?> · <?php echo esc_html( get_the_title( $sg_comment->comment_post_ID ) ); ?></span>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php else : ?>
					<p class="sg-widget-empty"><?php esc_html_e( '你还没有发表评论。', 'steamgrid' ); ?></p>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php
get_footer();
