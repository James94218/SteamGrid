<?php
/**
 * Template Name: 文章归档
 * Template Post Type: page
 *
 * @package SteamGrid
 */

get_header();
?>
<div class="sg-container sg-page">
	<div class="sg-main-grid">
		<div class="sg-content-area">
			<div class="sg-page-head">
				<h1 class="sg-page-title"><?php esc_html_e( '文章归档', 'steamgrid' ); ?></h1>
				<p class="sg-page-desc"><?php esc_html_e( '按月份与分类浏览全部文章。', 'steamgrid' ); ?></p>
			</div>

			<div class="sg-archive-block">
				<h2><?php esc_html_e( '按月份', 'steamgrid' ); ?></h2>
				<ul class="sg-archive-list">
					<?php
					wp_get_archives(
						array(
							'type'            => 'monthly',
							'show_post_count' => true,
							'limit'           => absint( sg_get( 'archive_months', 60 ) ),
						)
					);
					?>
				</ul>
			</div>

			<div class="sg-archive-block">
				<h2><?php esc_html_e( '按分类', 'steamgrid' ); ?></h2>
				<ul class="sg-archive-list">
					<?php
					wp_list_categories(
						array(
							'title_li'   => '',
							'show_count' => true,
							'hide_empty' => true,
						)
					);
					?>
				</ul>
			</div>
		</div>
		<?php get_sidebar(); ?>
	</div>
</div>
<?php
get_footer();
