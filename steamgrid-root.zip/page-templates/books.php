<?php
/**
 * Template Name: 书籍推荐
 * Template Post Type: page
 *
 * @package SteamGrid
 */

get_header();

$sg_slug     = sanitize_title( sg_get( 'books_category', 'books' ) );
$sg_category = get_category_by_slug( $sg_slug );
$sg_books    = new WP_Query(
	array(
		'category_name'       => $sg_slug,
		'posts_per_page'      => 12,
		'ignore_sticky_posts' => true,
	)
);
?>
<div class="sg-container sg-page">
	<div class="sg-main-grid">
		<div class="sg-content-area">
			<div class="sg-page-head">
				<h1 class="sg-page-title"><?php esc_html_e( '书籍推荐', 'steamgrid' ); ?></h1>
				<?php if ( $sg_category && $sg_category->description ) : ?>
					<p class="sg-page-desc"><?php echo esc_html( $sg_category->description ); ?></p>
				<?php else : ?>
					<p class="sg-page-desc"><?php printf( esc_html__( '展示分类「%s」下的书籍文章。', 'steamgrid' ), esc_html( $sg_slug ) ); ?></p>
				<?php endif; ?>
			</div>

			<?php if ( $sg_books->have_posts() ) : ?>
				<div class="sg-grid">
					<?php
					while ( $sg_books->have_posts() ) :
						$sg_books->the_post();
						get_template_part( 'template-parts/content', 'card' );
					endwhile;
					?>
				</div>
			<?php else : ?>
				<div class="sg-none">
					<h2><?php esc_html_e( '还没有书籍推荐', 'steamgrid' ); ?></h2>
					<p>
						<?php
						printf(
							/* translators: %s: 分类别名 */
							esc_html__( '请创建分类「%s」并发布书籍文章，或到主题设置中修改分类别名。', 'steamgrid' ),
							esc_html( $sg_slug )
						);
						?>
					</p>
				</div>
			<?php endif; ?>
			<?php wp_reset_postdata(); ?>
		</div>
		<?php get_sidebar(); ?>
	</div>
</div>
<?php
get_footer();
