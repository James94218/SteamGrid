<?php
/**
 * Template Name: 站点导航
 * Template Post Type: page
 *
 * @package SteamGrid
 */

get_header();

$sg_friend_links = sg_footer_links_parse();
$sg_pages        = get_pages(
	array(
		'sort_column' => 'menu_order,post_title',
		'number'      => 60,
	)
);
?>
<div class="sg-container sg-page">
	<div class="sg-main-grid">
		<div class="sg-content-area">
			<div class="sg-page-head">
				<h1 class="sg-page-title"><?php esc_html_e( '站点导航', 'steamgrid' ); ?></h1>
				<p class="sg-page-desc"><?php esc_html_e( '常用页面与友情链接。底部链接可在「主题设置 → 页脚设置 → 底部链接」中维护。', 'steamgrid' ); ?></p>
			</div>

			<?php if ( $sg_friend_links ) : ?>
				<div class="sg-archive-block">
					<h2><?php esc_html_e( '友情链接', 'steamgrid' ); ?></h2>
					<div class="sg-links-grid">
						<?php foreach ( $sg_friend_links as $sg_link ) : ?>
							<a class="sg-link-card" href="<?php echo esc_url( $sg_link['url'] ); ?>" target="_blank" rel="noopener nofollow">
								<?php echo sg_svg_icon( 'link' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span><?php echo esc_html( $sg_link['name'] ); ?></span>
							</a>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endif; ?>

			<?php if ( $sg_pages ) : ?>
				<div class="sg-archive-block">
					<h2><?php esc_html_e( '页面导航', 'steamgrid' ); ?></h2>
					<div class="sg-links-grid">
						<?php foreach ( $sg_pages as $sg_page ) : ?>
							<a class="sg-link-card" href="<?php echo esc_url( get_permalink( $sg_page ) ); ?>">
								<?php echo sg_svg_icon( 'map' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span><?php echo esc_html( $sg_page->post_title ); ?></span>
							</a>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endif; ?>

			<?php if ( ! $sg_friend_links && ! $sg_pages ) : ?>
				<div class="sg-none">
					<h2><?php esc_html_e( '暂无导航内容', 'steamgrid' ); ?></h2>
					<p><?php esc_html_e( '请先创建页面，或在主题设置中填写底部链接。', 'steamgrid' ); ?></p>
				</div>
			<?php endif; ?>
		</div>
		<?php get_sidebar(); ?>
	</div>
</div>
<?php
get_footer();
