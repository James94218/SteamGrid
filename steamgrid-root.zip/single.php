<?php
/**
 * 单篇文章模板
 *
 * @package SteamGrid
 */

get_header();

$sg_reward_qr = sg_get( 'reward_qr' );
?>

<div class="sg-container sg-page">
	<div class="sg-main-grid">

		<div class="sg-content-area">
			<?php
			while ( have_posts() ) :
				the_post();

				$sg_post_id   = get_the_ID();
				$sg_stats     = sg_reading_stats( $sg_post_id );
				$sg_likes     = (int) get_post_meta( $sg_post_id, '_sg_likes', true );
				$sg_reward_qr = sg_get( 'reward_qr' );
				?>
				<article id="post-<?php the_ID(); ?>" <?php post_class( 'sg-article' ); ?>>
					<header class="sg-article-head">
						<div class="sg-article-meta">
							<span class="sg-article-date"><?php echo esc_html( get_the_date() ); ?></span>
							<span class="sg-article-author"><?php the_author(); ?></span>
							<span class="sg-article-cats"><?php the_category( ' / ' ); ?></span>
							<?php if ( sg_on( 'reading_time' ) ) : ?>
								<span class="sg-article-reading">
									<?php echo sg_svg_icon( 'clock' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									<?php echo esc_html( sprintf( __( '%1$s 字 · 约 %2$s 分钟', 'steamgrid' ), number_format_i18n( $sg_stats['total'] ), number_format_i18n( $sg_stats['minutes'] ) ) ); ?>
								</span>
							<?php endif; ?>
							<span class="sg-article-views">
								<?php echo sg_svg_icon( 'eye' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<?php echo esc_html( number_format_i18n( sg_get_views( $sg_post_id ) ) ); ?>
							</span>
							<?php if ( comments_open() ) : ?>
								<span class="sg-article-comments"><?php echo esc_html( sg_comment_count_text( $sg_post_id ) ); ?></span>
							<?php endif; ?>
						</div>
						<h1 class="sg-article-title"><?php the_title(); ?></h1>
					</header>

					<?php sg_ad( 'article_top' ); ?>

					<?php if ( has_post_thumbnail() ) : ?>
						<figure class="sg-article-thumb">
							<?php the_post_thumbnail( 'large' ); ?>
						</figure>
					<?php endif; ?>

					<div class="sg-article-content">
						<?php
						the_content();

						wp_link_pages(
							array(
								'before' => '<div class="sg-page-links">' . esc_html__( '分页：', 'steamgrid' ),
								'after'  => '</div>',
							)
						);
						?>
					</div>

					<?php sg_ad( 'article_bottom' ); ?>

					<footer class="sg-article-foot">
						<?php if ( has_tag() ) : ?>
							<?php the_tags( '<div class="sg-tags">', '', '</div>' ); ?>
						<?php endif; ?>

						<div class="sg-post-actions">
							<?php if ( sg_on( 'like_enable' ) ) : ?>
								<button type="button" class="sg-action-btn sg-like-btn" data-sg-like data-post-id="<?php echo esc_attr( $sg_post_id ); ?>">
									<?php echo sg_svg_icon( 'heart' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									<span class="sg-like-count" data-sg-like-count><?php echo esc_html( number_format_i18n( $sg_likes ) ); ?></span>
									<span class="sg-action-label"><?php esc_html_e( '点赞', 'steamgrid' ); ?></span>
								</button>
							<?php endif; ?>

							<?php if ( sg_on( 'reward_enable' ) ) : ?>
								<button type="button" class="sg-action-btn" data-sg-modal-open="sg-reward-modal">
									<?php echo sg_svg_icon( 'chart' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									<span class="sg-action-label"><?php esc_html_e( '打赏', 'steamgrid' ); ?></span>
								</button>
							<?php endif; ?>

							<?php if ( sg_on( 'share_enable' ) ) : ?>
								<button type="button" class="sg-action-btn" data-sg-modal-open="sg-share-modal">
									<?php echo sg_svg_icon( 'share' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									<span class="sg-action-label"><?php esc_html_e( '分享', 'steamgrid' ); ?></span>
								</button>
							<?php endif; ?>

							<?php if ( sg_on( 'poster_enable' ) ) : ?>
								<button type="button" class="sg-action-btn" data-sg-modal-open="sg-poster-modal">
									<?php echo sg_svg_icon( 'image' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									<span class="sg-action-label"><?php esc_html_e( '海报', 'steamgrid' ); ?></span>
								</button>
							<?php endif; ?>
						</div>
					</footer>
				</article>

				<?php
				the_post_navigation(
					array(
						'prev_text' => '← %title',
						'next_text' => '%title →',
					)
				);

				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
			endwhile;
			?>
		</div>

		<?php get_sidebar(); ?>
	</div>
</div>

<?php if ( sg_on( 'reward_enable' ) ) : ?>
	<div class="sg-modal" id="sg-reward-modal" data-sg-modal hidden>
		<div class="sg-modal-dialog" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( '打赏作者', 'steamgrid' ); ?>">
			<button type="button" class="sg-modal-close" data-sg-modal-close aria-label="<?php esc_attr_e( '关闭', 'steamgrid' ); ?>"><?php echo sg_svg_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
			<h3 class="sg-modal-title"><?php esc_html_e( '打赏作者', 'steamgrid' ); ?></h3>
			<?php if ( $sg_reward_qr ) : ?>
				<div class="sg-reward-qr"><img src="<?php echo esc_url( $sg_reward_qr ); ?>" alt="<?php esc_attr_e( '打赏二维码', 'steamgrid' ); ?>" loading="lazy" /></div>
			<?php endif; ?>
			<p class="sg-reward-text"><?php echo esc_html( sg_get( 'reward_text' ) ); ?></p>
		</div>
	</div>
<?php endif; ?>

<?php if ( sg_on( 'share_enable' ) ) : ?>
	<div class="sg-modal" id="sg-share-modal" data-sg-modal hidden>
		<div class="sg-modal-dialog" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( '分享文章', 'steamgrid' ); ?>">
			<button type="button" class="sg-modal-close" data-sg-modal-close aria-label="<?php esc_attr_e( '关闭', 'steamgrid' ); ?>"><?php echo sg_svg_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
			<h3 class="sg-modal-title"><?php esc_html_e( '分享到', 'steamgrid' ); ?></h3>
			<div class="sg-share-grid">
				<button type="button" class="sg-share-item" data-sg-share="weibo"><?php esc_html_e( '微博', 'steamgrid' ); ?></button>
				<button type="button" class="sg-share-item" data-sg-share="qq"><?php esc_html_e( 'QQ', 'steamgrid' ); ?></button>
				<button type="button" class="sg-share-item" data-sg-share="twitter"><?php esc_html_e( 'X / Twitter', 'steamgrid' ); ?></button>
				<button type="button" class="sg-share-item" data-sg-share="copy"><?php esc_html_e( '复制链接', 'steamgrid' ); ?></button>
			</div>
		</div>
	</div>
<?php endif; ?>

<?php if ( sg_on( 'poster_enable' ) ) : ?>
	<div class="sg-modal" id="sg-poster-modal" data-sg-modal hidden>
		<div class="sg-modal-dialog sg-modal-poster" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( '生成海报', 'steamgrid' ); ?>">
			<button type="button" class="sg-modal-close" data-sg-modal-close aria-label="<?php esc_attr_e( '关闭', 'steamgrid' ); ?>"><?php echo sg_svg_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
			<h3 class="sg-modal-title"><?php esc_html_e( '文章海报', 'steamgrid' ); ?></h3>
			<div class="sg-poster-wrap">
				<canvas id="sg-poster-canvas" width="750" height="1000"></canvas>
			</div>
			<div class="sg-poster-actions">
				<a class="sg-btn" id="sg-poster-download" download="<?php echo esc_attr( sanitize_title( get_the_title() ) . '-poster.png' ); ?>" href="#"><?php esc_html_e( '下载海报', 'steamgrid' ); ?></a>
			</div>
		</div>
	</div>
<?php endif; ?>

<?php
get_footer();
