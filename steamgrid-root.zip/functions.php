<?php
/**
 * SteamGrid 主题函数与初始化
 *
 * @package SteamGrid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SG_VERSION', '2.0.5' );
define( 'SG_DIR', get_template_directory() );
define( 'SG_URI', get_template_directory_uri() );

/* ------------------------------------------------------------
 * 主题基础支持
 * ---------------------------------------------------------- */
function sg_setup() {
	load_theme_textdomain( 'steamgrid', SG_DIR . '/languages' );

	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 64,
			'width'       => 240,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'customize-selective-refresh-widgets' );

	register_nav_menus(
		array(
			'primary' => __( '顶部主导航', 'steamgrid' ),
			'footer'  => __( '底部导航', 'steamgrid' ),
		)
	);

	add_image_size( 'sg-card', 920, 430, true );
	add_image_size( 'sg-thumb', 480, 270, true );
}
add_action( 'after_setup_theme', 'sg_setup' );

/* ------------------------------------------------------------
 * 小工具区域
 * ---------------------------------------------------------- */
function sg_widgets_init() {
	register_sidebar(
		array(
			'name'          => __( '侧边栏', 'steamgrid' ),
			'id'            => 'sidebar-1',
			'description'   => __( '文章页、归档页、首页与搜索页的侧边栏。', 'steamgrid' ),
			'before_widget' => '<section id="%1$s" class="sg-widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h3 class="sg-widget-title">',
			'after_title'   => '</h3>',
		)
	);

	for ( $i = 1; $i <= 4; $i++ ) {
		register_sidebar(
			array(
				/* translators: %d: 页脚栏序号 */
				'name'          => sprintf( __( '页脚栏 %d', 'steamgrid' ), $i ),
				'id'            => 'footer-' . $i,
				'description'   => __( '页脚四栏小工具区域。', 'steamgrid' ),
				'before_widget' => '<section id="%1$s" class="sg-widget sg-footer-widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h3 class="sg-widget-title">',
				'after_title'   => '</h3>',
			)
		);
	}
}
add_action( 'widgets_init', 'sg_widgets_init' );

/* ------------------------------------------------------------
 * 前端资源
 * ---------------------------------------------------------- */
function sg_scripts() {
	wp_enqueue_style( 'sg-style', get_stylesheet_uri(), array(), SG_VERSION );
	wp_enqueue_style( 'sg-main', SG_URI . '/assets/css/main.css', array( 'sg-style' ), SG_VERSION );
	wp_enqueue_style( 'sg-features', SG_URI . '/assets/css/features.css', array( 'sg-main' ), SG_VERSION );

	wp_enqueue_script( 'sg-main', SG_URI . '/assets/js/main.js', array(), SG_VERSION, true );
	wp_enqueue_script( 'sg-app', SG_URI . '/assets/js/app.js', array( 'sg-main' ), SG_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	// Twemoji
	if ( sg_on( 'twemoji' ) && sg_get( 'twemoji_cdn' ) ) {
		wp_enqueue_script( 'sg-twemoji', sg_get( 'twemoji_cdn' ), array(), null, true );
	}

	// DPlayer（仅当文章使用短代码时）
	if ( is_singular() && sg_on( 'shortcodes_enable' ) ) {
		$content = (string) get_post_field( 'post_content', get_queried_object_id() );
		if ( has_shortcode( $content, 'dplayer' ) ) {
			if ( sg_get( 'dplayer_css' ) ) {
				wp_enqueue_style( 'sg-dplayer', sg_get( 'dplayer_css' ), array(), null );
			}
			if ( sg_get( 'dplayer_cdn' ) ) {
				wp_enqueue_script( 'sg-dplayer', sg_get( 'dplayer_cdn' ), array(), null, true );
			}
		}
	}

	// 极验
	if ( 'geetest' === sg_get( 'captcha_mode' ) && sg_get( 'geetest_id' ) && sg_get( 'geetest_key' ) ) {
		wp_enqueue_script( 'sg-geetest', 'https://static.geetest.com/v4/gt4.js', array(), null, true );
	}

	$css = sg_dynamic_css();
	if ( $css ) {
		wp_add_inline_style( 'sg-features', $css );
	}

	$custom_css = (string) sg_get( 'custom_css' );
	if ( $custom_css ) {
		wp_add_inline_style( 'sg-features', $custom_css );
	}

	$like_count = 0;
	if ( is_singular() ) {
		$like_count = (int) get_post_meta( get_queried_object_id(), '_sg_likes', true );
	}

	$current_user = wp_get_current_user();
	$email_ok     = $current_user->ID ? sg_is_email_verified( $current_user->ID ) : false;

	wp_localize_script(
		'sg-app',
		'SG_DATA',
		array(
			'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
			'nonce'          => wp_create_nonce( 'sg_ajax' ),
			'homeUrl'        => home_url( '/' ),
			'pjax'           => sg_on( 'pjax' ),
			'skeleton'       => sg_on( 'skeleton' ),
			'loadMore'       => sg_on( 'load_more' ),
			'commentsAjax'   => sg_on( 'comments_ajax' ),
			'commentOpen'    => is_singular() && comments_open(),
			'likeEnable'     => sg_on( 'like_enable' ),
			'likeCount'      => $like_count,
			'posterEnable'   => sg_on( 'poster_enable' ),
			'posterQr'       => sg_on( 'poster_qr' ),
			'shareEnable'    => sg_on( 'share_enable' ),
			'codeCopy'       => sg_on( 'code_copy' ),
			'tocEnable'      => sg_on( 'toc_enable' ),
			'twemoji'        => sg_on( 'twemoji' ),
			'lazyLoad'       => sg_on( 'lazy_load' ),
			'themeToggle'    => sg_on( 'theme_toggle' ),
			'stickySidebar'  => sg_on( 'sidebar_sticky' ),
			'mobileSidebar'  => sg_on( 'mobile_sidebar' ),
			'prefetch'       => sg_on( 'next_prefetch' ),
			'postId'         => is_singular() ? get_queried_object_id() : 0,
			'postTitle'      => is_singular() ? get_the_title() : get_bloginfo( 'name' ),
			'postExcerpt'    => is_singular() ? wp_strip_all_tags( get_the_excerpt() ) : get_bloginfo( 'description' ),
			'siteName'       => get_bloginfo( 'name' ),
			'logoUrl'        => has_custom_logo() ? wp_get_attachment_image_url( get_theme_mod( 'custom_logo' ), 'medium' ) : '',
			'loggedIn'       => is_user_logged_in(),
			'emailVerified'  => (bool) $email_ok,
			'loginUrl'       => sg_auth_url( 'login' ),
			'registerUrl'    => sg_auth_url( 'register' ),
			'userCenterUrl'  => sg_auth_url( 'user_center' ),
			'commentMaxLength' => 65525,
			'captchaMode'    => sg_get( 'captcha_mode' ),
			'geetestId'      => sg_get( 'geetest_id' ),
			'geetestKeySet'  => (bool) ( sg_get( 'geetest_id' ) && sg_get( 'geetest_key' ) ),
			'posterQrCdn'    => 'https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js',
			'mediaTitle'     => __( '选择图片', 'steamgrid' ),
			'i18n'           => array(
				'copied'        => __( '代码已复制', 'steamgrid' ),
				'copyFailed'    => __( '复制失败，请手动选择', 'steamgrid' ),
				'loading'       => __( '加载中…', 'steamgrid' ),
				'loadMore'      => __( '加载更多', 'steamgrid' ),
				'noMore'        => __( '没有更多内容了', 'steamgrid' ),
				'like'          => __( '点赞', 'steamgrid' ),
				'likeDone'      => __( '已点赞', 'steamgrid' ),
				'commentPosted' => __( '评论已提交', 'steamgrid' ),
				'commentPending' => __( '评论已提交，等待审核', 'steamgrid' ),
				'commentError'  => __( '评论提交失败，请重试', 'steamgrid' ),
				'commentEmpty'  => __( '评论内容不能为空', 'steamgrid' ),
				'posterGenerating' => __( '正在生成海报…', 'steamgrid' ),
				'posterFailed'  => __( '海报生成失败', 'steamgrid' ),
				'captchaRefresh' => __( '点击刷新验证码', 'steamgrid' ),
				'shareCopied'   => __( '链接已复制', 'steamgrid' ),
				'tocTitle'      => __( '目录', 'steamgrid' ),
				'commentLoad'   => __( '加载更多评论', 'steamgrid' ),
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'sg_scripts' );

/* ------------------------------------------------------------
 * 后台脚本
 * ---------------------------------------------------------- */
function sg_admin_scripts( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_script( 'sg-media-uploader', SG_URI . '/assets/js/media-uploader.js', array( 'jquery' ), SG_VERSION, true );
}
add_action( 'admin_enqueue_scripts', 'sg_admin_scripts' );

/* ------------------------------------------------------------
 * 动态 CSS 变量
 * ---------------------------------------------------------- */
function sg_dynamic_css() {
	$vars = array(
		'--sg-font-size'      => absint( sg_get( 'font_size', 16 ) ) . 'px',
		'--sg-font-weight'    => absint( sg_get( 'font_weight', 400 ) ),
		'--sg-heading-weight' => absint( sg_get( 'heading_weight', 700 ) ),
		'--sg-card-radius'    => absint( sg_get( 'card_radius', 4 ) ) . 'px',
		'--sg-grid-cols'      => absint( sg_get( 'grid_cols', 4 ) ),
		'--sg-container'      => absint( sg_get( 'container_width', 1200 ) ) . 'px',
	);

	$accent = sanitize_hex_color( sg_get( 'accent_color', '#66c0f4' ) );
	if ( $accent ) {
		$vars['--sg-accent'] = $accent;
	}

	$css = ':root{';
	foreach ( $vars as $k => $v ) {
		$css .= $k . ':' . $v . ';';
	}
	$css .= '}';

	return $css;
}

/* ------------------------------------------------------------
 * 色彩模式初始化脚本（避免闪烁）
 * ---------------------------------------------------------- */
function sg_theme_mode_script() {
	$mode = sg_get( 'color_mode', 'auto' );
	$gray = sg_on( 'gray_mode' );
	?>
	<script>
	(function () {
		try {
			var pref = localStorage.getItem('sg-color-mode') || <?php echo wp_json_encode( $mode ); ?>;
			var media = window.matchMedia('(prefers-color-scheme: light)');
			var resolve = function () {
				return pref === 'auto' ? (media.matches ? 'light' : 'dark') : pref;
			};
			document.documentElement.setAttribute('data-sg-theme', resolve());
			document.documentElement.setAttribute('data-sg-mode', pref);
			<?php if ( $gray ) : ?>
			document.documentElement.classList.add('sg-gray');
			<?php endif; ?>
			if (media.addEventListener) {
				media.addEventListener('change', function () {
					if (pref === 'auto') {
						document.documentElement.setAttribute('data-sg-theme', resolve());
					}
				});
			}
		} catch (e) {}
	})();
	</script>
	<?php
}
add_action( 'wp_head', 'sg_theme_mode_script', 1 );

/* ------------------------------------------------------------
 * 布局辅助
 * ---------------------------------------------------------- */
function sg_has_sidebar() {
	$templates = array(
		'page-templates/login.php',
		'page-templates/register.php',
		'page-templates/lost-password.php',
		'page-templates/user-center.php',
		'page-templates/sitemap.php',
	);

	if ( is_page_template( $templates ) ) {
		return false;
	}

	if ( 'none' === sg_get( 'sidebar_position' ) ) {
		return false;
	}

	if ( is_front_page() && ! sg_on( 'home_sidebar' ) ) {
		return false;
	}

	return true;
}

function sg_posts_page_url() {
	$page = (int) get_option( 'page_for_posts' );
	if ( $page ) {
		$url = get_permalink( $page );
		if ( $url ) {
			return $url;
		}
	}
	return home_url( '/' );
}

function sg_hero_style_attr() {
	$style = 'background-color:' . esc_attr( sg_get( 'hero_bg', '#1b2838' ) ) . ';';

	$image = sg_get( 'hero_image' );
	if ( $image ) {
		$style .= 'background-image:url(' . esc_url( $image ) . ');';
	}

	return 'style="' . $style . '"';
}

/**
 * 首页幻灯片数据
 *
 * 支持手动条目与自动提取文章；自动模式使用特色图片、标题、摘要与标签。
 *
 * @return array
 */
function sg_get_carousel_slides() {
	$source = sg_get( 'carousel_source', 'posts' );

	if ( 'manual' === $source ) {
		$raw    = sg_get( 'slides', array() );
		$slides = array();

		if ( is_array( $raw ) ) {
			foreach ( $raw as $slide ) {
				if ( ! is_array( $slide ) ) {
					continue;
				}

				$title = trim( (string) ( isset( $slide['title'] ) ? $slide['title'] : '' ) );
				$image = (string) ( isset( $slide['image'] ) ? $slide['image'] : '' );

				if ( '' === $title && '' === $image ) {
					continue;
				}

				$slides[] = array(
					'image'  => $image,
					'title'  => $title,
					'text'   => (string) ( isset( $slide['text'] ) ? $slide['text'] : '' ),
					'tags'   => (string) ( isset( $slide['tags'] ) ? $slide['tags'] : '' ),
					'link'   => (string) ( isset( $slide['link'] ) ? $slide['link'] : '' ),
					'button' => (string) ( isset( $slide['button'] ) ? $slide['button'] : '' ),
				);
			}
		}

		if ( $slides ) {
			return $slides;
		}
	}

	$args = array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => max( 1, absint( sg_get( 'carousel_count', 5 ) ) ),
		'ignore_sticky_posts' => true,
	);

	$category = absint( sg_get( 'carousel_category', 0 ) );
	if ( $category ) {
		$args['cat'] = $category;
	}

	$post_ids = (string) sg_get( 'carousel_posts' );
	if ( $post_ids ) {
		$ids = array_filter( array_map( 'absint', preg_split( '/[,\s]+/', $post_ids ) ) );
		if ( $ids ) {
			$args['post__in'] = $ids;
			$args['orderby']  = 'post__in';
		}
	}

	$posts  = get_posts( $args );
	$button = (string) sg_get( 'carousel_button_text' );
	if ( ! $button ) {
		$button = __( '查看详情', 'steamgrid' );
	}

	$slides = array();
	foreach ( $posts as $post ) {
		$image = get_the_post_thumbnail_url( $post->ID, 'full' );
		if ( ! $image ) {
			$meta = get_post_meta( $post->ID, '_sg_card_image', true );
			if ( $meta ) {
				$image = $meta;
			}
		}

		$tags      = get_the_tags( $post->ID );
		$tag_names = array();
		if ( $tags ) {
			foreach ( $tags as $tag ) {
				$tag_names[] = $tag->name;
			}
		} else {
			$cats = get_the_category( $post->ID );
			if ( $cats ) {
				foreach ( $cats as $cat ) {
					$tag_names[] = $cat->name;
				}
			}
		}

		$slides[] = array(
			'image'  => $image ? $image : '',
			'title'  => get_the_title( $post ),
			'text'   => wp_strip_all_tags( get_the_excerpt( $post ) ),
			'tags'   => implode( ',', $tag_names ),
			'link'   => get_permalink( $post ),
			'button' => $button,
		);
	}

	return $slides;
}

function sg_pagination() {
	the_posts_pagination(
		array(
			'mid_size'  => 2,
			'prev_text' => __( '← 上一页', 'steamgrid' ),
			'next_text' => __( '下一页 →', 'steamgrid' ),
		)
	);
}

function sg_menu_fallback() {
	echo '<ul id="primary-menu" class="sg-menu">';
	echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( '首页', 'steamgrid' ) . '</a></li>';
	wp_list_pages(
		array(
			'title_li' => '',
			'depth'    => 1,
			'number'   => 6,
		)
	);
	echo '</ul>';
}

function sg_body_classes( $classes ) {
	$classes[] = 'sg-layout-' . sanitize_html_class( sg_get( 'layout_mode', 'grid' ) );
	$classes[] = 'sg-cards-' . sanitize_html_class( sg_get( 'card_style', 'default' ) );

	$sidebar = sg_get( 'sidebar_position', 'right' );
	if ( 'none' === $sidebar || ! sg_has_sidebar() ) {
		$classes[] = 'sg-no-sidebar';
	} else {
		$classes[] = 'sg-sidebar-' . sanitize_html_class( $sidebar );
	}

	if ( is_front_page() && ! sg_on( 'home_sidebar' ) ) {
		$classes[] = 'sg-home-no-sidebar';
	}
	if ( ! sg_on( 'sidebar_sticky' ) ) {
		$classes[] = 'sg-sidebar-static';
	}
	if ( sg_on( 'pjax' ) ) {
		$classes[] = 'sg-pjax-enabled';
	}
	if ( sg_on( 'gray_mode' ) ) {
		$classes[] = 'sg-gray';
	}
	if ( is_user_logged_in() ) {
		$classes[] = 'sg-logged-in';
	}

	return $classes;
}
add_filter( 'body_class', 'sg_body_classes' );

/* ------------------------------------------------------------
 * 图标
 * ---------------------------------------------------------- */
function sg_svg_icon( $name ) {
	$icons = array(
		'shield'    => '<svg class="sg-icon sg-icon-shield" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 2l8 4v6c0 4.7-3.3 8.2-8 10-4.7-1.8-8-5.3-8-10V6l8-4zm0 2.2L5.7 6.9V12c0 3.8 2.6 6.7 6.3 8.3 3.7-1.6 6.3-4.5 6.3-8.3V6.9L12 4.2z"/><path fill="currentColor" d="M10.6 15.4l-2.9-2.9 1.4-1.4 1.5 1.5 4.1-4.1 1.4 1.4-5.5 5.5z"/></svg>',
		'globe'     => '<svg class="sg-icon sg-icon-globe" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3c2.5 2.6 3.9 5.7 3.9 9S14.5 18.4 12 21c-2.5-2.6-3.9-5.7-3.9-9S9.5 5.6 12 3z"/></svg>',
		'github'    => '<svg class="sg-icon sg-icon-github" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.11.79-.25.79-.56 0-.27-.01-1.17-.02-2.12-3.2.7-3.88-1.36-3.88-1.36-.52-1.33-1.28-1.68-1.28-1.68-1.04-.71.08-.7.08-.7 1.15.08 1.76 1.19 1.76 1.19 1.02 1.75 2.68 1.25 3.34.95.1-.74.4-1.25.72-1.54-2.55-.29-5.24-1.28-5.24-5.69 0-1.26.45-2.28 1.19-3.09-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.17 1.18a11 11 0 0 1 5.77 0c2.2-1.49 3.17-1.18 3.17-1.18.63 1.59.23 2.76.11 3.05.74.81 1.19 1.83 1.19 3.09 0 4.42-2.69 5.39-5.25 5.68.41.35.77 1.04.77 2.1 0 1.51-.01 2.73-.01 3.11 0 .31.21.68.8.56A11.51 11.51 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5z"/></svg>',
		'weibo'     => '<svg class="sg-icon sg-icon-weibo" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12 6.5 2 12 2zM8.9 14.2c-2.8 0-5 1-5 2.2 0 1.2 2.2 2.2 5 2.2s5-1 5-2.2c0-1.2-2.2-2.2-5-2.2zm0 3.6c-1.6 0-3-.5-3-1.1 0-.6 1.4-1.1 3-1.1s3 .5 3 1.1c0 .6-1.4 1.1-3 1.1zm5.9-7.6c-1.7-1-3.9-1-5.8.1-.5.3-.7.9-.4 1.4.3.5.9.7 1.4.4 1.3-.8 2.9-.8 4.1-.1.5.3 1.1.1 1.3-.4.3-.5.1-1.1-.5-1.4zm1.4 2.6c-1-.5-2.5-.5-3.8.1-.4.2-.6.7-.4 1.1.2.4.7.6 1.1.4.8-.4 1.8-.5 2.5-.1.5.2 1-.1 1.2-.6.2-.5-.1-1-.6-1.2zm4.3-2.9c-.3-.4-.8-.4-1.2-.1-1 .8-2.2 1.4-3.5 1.7-.5.1-.9.6-.8 1.1.1.5.6.9 1.1.8 1.6-.3 3-1 4.3-2.1.4-.3.4-.8.1-1.2z"/></svg>',
		'bilibili'  => '<svg class="sg-icon sg-icon-bilibili" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="13" rx="2.5"/><path d="M8 2l4 4 4-4"/><path d="M9 11.5h.01M15 11.5h.01"/></svg>',
		'mail'      => '<svg class="sg-icon sg-icon-mail" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M2 7l10 6 10-6"/></svg>',
		'arrow-up'  => '<svg class="sg-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5M5 12l7-7 7 7"/></svg>',
		'steam'     => '<svg class="sg-icon sg-icon-steam" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false"><path fill="currentColor" d="M11.979 0C5.678 0 .511 4.86.022 11.037l6.432 2.658c.545-.371 1.203-.59 1.912-.59.063 0 .125.004.188.006l2.861-4.142V8.91c0-2.495 2.028-4.524 4.524-4.524 2.494 0 4.523 2.03 4.523 4.524s-2.029 4.525-4.523 4.525h-.105l-4.076 2.911c0 .052.004.105.004.159 0 1.875-1.515 3.396-3.39 3.396-1.635 0-3.016-1.173-3.331-2.727L.436 15.27C1.862 20.307 6.486 24 11.979 24c6.627 0 11.999-5.373 11.999-12S18.605 0 11.979 0zM7.54 18.21l-1.473-.61c.262.543.714.999 1.314 1.25 1.297.539 2.793-.076 3.332-1.375.263-.63.264-1.319.005-1.949s-.75-1.121-1.377-1.383c-.624-.26-1.29-.249-1.878-.03l1.523.63c.956.4 1.409 1.5 1.009 2.455-.397.957-1.497 1.41-2.454 1.012H7.54zm11.415-9.303c0-1.662-1.353-3.015-3.015-3.015-1.665 0-3.015 1.353-3.015 3.015 0 1.665 1.35 3.015 3.015 3.015 1.663 0 3.015-1.35 3.015-3.015zm-5.273-.005c0-1.252 1.013-2.266 2.265-2.266 1.249 0 2.266 1.014 2.266 2.266 0 1.251-1.017 2.265-2.266 2.265-1.253 0-2.265-2.265-2.265-2.265z"/></svg>',
		'netease'   => '<svg class="sg-icon sg-icon-netease" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path fill="currentColor" d="M14.8 6.4v7.03a2.6 2.6 0 1 1-2.6-2.6c.18 0 .35.02.52.05V8.1l4.05-.95v-.75a.55.55 0 0 1 .68-.53l.55.14a.55.55 0 0 1 .42.53v1.3l-3.62.85v2.2a3.9 3.9 0 1 0 3.28 3.85V7.1a.7.7 0 0 1 .55-.68l.3-.07a.5.5 0 0 0 .38-.49V5.2a.55.55 0 0 0-.68-.54l-3.83.9a.55.55 0 0 0-.42.53z" transform="translate(-1.2 -0.4)"/><circle cx="8.2" cy="15.6" r="1.35" fill="currentColor"/></svg>',
		'sun'       => '<svg class="sg-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5 5l1.6 1.6M17.4 17.4L19 19M19 5l-1.6 1.6M6.6 17.4L5 19"/></svg>',
		'moon'      => '<svg class="sg-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.5 14.6A8.6 8.6 0 0 1 9.4 3.5 8.8 8.8 0 1 0 20.5 14.6z"/></svg>',
		'user'      => '<svg class="sg-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="3.6"/><path d="M4.5 20.2c1.1-3.4 4-5.2 7.5-5.2s6.4 1.8 7.5 5.2"/></svg>',
		'clock'     => '<svg class="sg-icon" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5.2l3.4 2"/></svg>',
		'heart'     => '<svg class="sg-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 20.6l-1.3-1.2C6 15.3 2.8 12.4 2.8 8.9 2.8 6 5 3.8 7.8 3.8c1.6 0 3.1.8 4.2 2 1.1-1.2 2.6-2 4.2-2 2.8 0 5 2.2 5 5.1 0 3.5-3.2 6.4-7.9 10.5L12 20.6z"/></svg>',
		'share'     => '<svg class="sg-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="2.4"/><circle cx="6" cy="12" r="2.4"/><circle cx="18" cy="19" r="2.4"/><path d="M8.2 10.8l7.6-4.4M8.2 13.2l7.6 4.4"/></svg>',
		'image'     => '<svg class="sg-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="8.5" cy="10" r="1.5"/><path d="M21 15l-5-5-9 9"/></svg>',
		'download'  => '<svg class="sg-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12M6.5 9.5L12 15l5.5-5.5M4.5 20.5h15"/></svg>',
		'lock'      => '<svg class="sg-icon" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="4.5" y="10" width="15" height="10.5" rx="2"/><path d="M8 10V7.5a4 4 0 0 1 8 0V10"/></svg>',
		'link'      => '<svg class="sg-icon" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M10 14a4 4 0 0 0 5.7 0l2.6-2.6a4 4 0 1 0-5.7-5.7L11.5 6.8"/><path d="M14 10a4 4 0 0 0-5.7 0l-2.6 2.6a4 4 0 1 0 5.7 5.7l1.1-1.1"/></svg>',
		'copy'      => '<svg class="sg-icon" viewBox="0 0 24 24" width="14" height="14" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="8.5" y="8.5" width="12" height="12" rx="2"/><path d="M15.5 8.5V5.5a2 2 0 0 0-2-2h-8a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h3"/></svg>',
		'chart'     => '<svg class="sg-icon" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 20V4M4 20h16"/><path d="M8 16v-4M12 16V8M16 16v-6"/></svg>',
		'tag'       => '<svg class="sg-icon" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 12.5V4h8.5l8.5 8.5-8.5 8.5-8.5-8.5z"/><circle cx="8" cy="8" r="1.4"/></svg>',
		'book'      => '<svg class="sg-icon" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15.5H6.5A2.5 2.5 0 0 0 4 21V5.5z"/><path d="M4 18.5A2.5 2.5 0 0 1 6.5 16H20"/></svg>',
		'map'       => '<svg class="sg-icon" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4L3.5 6v14L9 18l6 2 5.5-2V4L15 6 9 4z"/><path d="M9 4v14M15 6v14"/></svg>',
		'menu'      => '<svg class="sg-icon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
		'close'     => '<svg class="sg-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
		'info'      => '<svg class="sg-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9.2" fill="none" stroke="currentColor" stroke-width="2"/><path fill="currentColor" d="M11 10.5h2v6h-2zM11 7.2h2v2.1h-2z"/></svg>',
		'success'   => '<svg class="sg-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9.2" fill="none" stroke="currentColor" stroke-width="2"/><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M7.5 12.5l3 3 6-6"/></svg>',
		'warning'   => '<svg class="sg-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" d="M12 3.5l9 16H3l9-16z"/><path fill="currentColor" d="M11 9.5h2v5h-2zM11 16.2h2v2h-2z"/></svg>',
		'quote'     => '<svg class="sg-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false" fill="currentColor"><path d="M7.5 6.5C5 7.6 3.6 9.6 3.6 12.2c0 2 1.2 3.4 2.9 3.4 1.6 0 2.7-1.1 2.7-2.6 0-1.4-1-2.4-2.3-2.4-.3 0-.6 0-.8.1.3-1.2 1.3-2.2 2.6-2.8l-1.2-1.4zm9.2 0C14.2 7.6 12.8 9.6 12.8 12.2c0 2 1.2 3.4 2.9 3.4 1.6 0 2.7-1.1 2.7-2.6 0-1.4-1-2.4-2.3-2.4-.3 0-.6 0-.8.1.3-1.2 1.3-2.2 2.6-2.8l-1.2-1.4z"/></svg>',
		'eye'       => '<svg class="sg-icon" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/></svg>',
		'fire'      => '<svg class="sg-icon" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 2.8c1 3.1 3.9 5 5.4 7.4 1.2 1.9 1.6 4 1.6 5.6A7 7 0 0 1 5 15.8c0-1.7.6-3.3 1.9-4.8.2 1.8 1.2 2.7 2.3 2.7 1.3 0 2.1-1 2.1-2.4 0-2.6-.9-4.9-.9-7.3 0-.4 0-.8.2-1.2.4-.2.9-.3 1.4 0z"/></svg>',
	);

	return isset( $icons[ $name ] ) ? $icons[ $name ] : '';
}

/* ------------------------------------------------------------
 * 统计辅助
 * ---------------------------------------------------------- */
function sg_reading_stats( $post_id = 0 ) {
	$post_id = $post_id ? (int) $post_id : get_the_ID();
	$content = (string) get_post_field( 'post_content', $post_id );
	$content = wp_strip_all_tags( strip_shortcodes( $content ) );

	$chars = preg_match_all( '/[\x{4e00}-\x{9fa5}]/u', $content );
	$chars = $chars ? (int) $chars : 0;

	$latin = preg_replace( '/[\x{4e00}-\x{9fa5}]/u', ' ', $content );
	$words = str_word_count( $latin );
	$total = $chars + $words;
	$minutes = max( 1, (int) ceil( $total / 400 ) );

	return array(
		'chars'   => $chars,
		'words'   => $words,
		'total'   => $total,
		'minutes' => $minutes,
	);
}

function sg_get_views( $post_id = 0 ) {
	$post_id = $post_id ? (int) $post_id : get_the_ID();
	return (int) get_post_meta( $post_id, '_sg_views', true );
}

function sg_count_view() {
	if ( is_admin() || ! is_singular() ) {
		return;
	}
	$post_id = get_queried_object_id();
	if ( ! $post_id ) {
		return;
	}
	$views = (int) get_post_meta( $post_id, '_sg_views', true );
	update_post_meta( $post_id, '_sg_views', $views + 1 );
}
add_action( 'wp', 'sg_count_view' );

/* ------------------------------------------------------------
 * 其它
 * ---------------------------------------------------------- */
function sg_excerpt_length( $length ) {
	return 22;
}
add_filter( 'excerpt_length', 'sg_excerpt_length' );

function sg_excerpt_more( $more ) {
	return '&hellip;';
}
add_filter( 'excerpt_more', 'sg_excerpt_more' );

function sg_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'sg_pingback_header' );

/**
 * 切换主题时创建页面与刷新规则
 */
function sg_after_switch_theme() {
	sg_create_auth_pages();
	sg_migrate_legacy_settings();
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'sg_after_switch_theme' );

/* ------------------------------------------------------------
 * 引入模块
 * ---------------------------------------------------------- */
require SG_DIR . '/inc/settings.php';
require SG_DIR . '/inc/admin-ui.php';
require SG_DIR . '/inc/avatar.php';
require SG_DIR . '/inc/captcha.php';
require SG_DIR . '/inc/security.php';
require SG_DIR . '/inc/optimize.php';
require SG_DIR . '/inc/seo.php';
require SG_DIR . '/inc/thumb.php';
require SG_DIR . '/inc/toc.php';
require SG_DIR . '/inc/site-card.php';
require SG_DIR . '/inc/shortcodes.php';
require SG_DIR . '/inc/widgets.php';
require SG_DIR . '/inc/ads.php';
require SG_DIR . '/inc/ajax.php';
require SG_DIR . '/inc/comments.php';
require SG_DIR . '/inc/user-center.php';
require SG_DIR . '/inc/meta-boxes.php';
