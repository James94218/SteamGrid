<?php
/**
 * 卡片模板（宫格中的单张卡片）
 *
 * @package SteamGrid
 */

$sg_post_id    = get_the_ID();
$sg_card_img   = sg_card_image_url( $sg_post_id );
$sg_card_link  = sg_card_link_url( $sg_post_id );
$sg_read_time  = sg_on( 'reading_time' ) ? sg_reading_stats( $sg_post_id ) : null;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'sg-card' ); ?>>
	<a class="sg-card-media<?php echo $sg_card_img ? '' : ' sg-no-img'; ?>" href="<?php echo esc_url( $sg_card_link ); ?>">
		<?php if ( $sg_card_img ) : ?>
			<img src="<?php echo esc_url( $sg_card_img ); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy" />
		<?php endif; ?>
	</a>

	<div class="sg-card-body">
		<h2 class="sg-card-title"><a href="<?php echo esc_url( $sg_card_link ); ?>"><?php the_title(); ?></a></h2>

		<div class="sg-card-meta">
			<span class="sg-card-date"><?php echo esc_html( get_the_date() ); ?></span>
			<?php if ( $sg_read_time ) : ?>
				<span class="sg-card-read"><?php echo sg_svg_icon( 'clock' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php echo esc_html( $sg_read_time['minutes'] ); ?> <?php esc_html_e( '分钟', 'steamgrid' ); ?></span>
			<?php endif; ?>
			<span class="sg-card-views"><?php echo sg_svg_icon( 'eye' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php echo esc_html( sg_get_views() ); ?></span>
		</div>

		<p class="sg-card-desc"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 22 ) ); ?></p>
	</div>
</article>
