<?php
/**
 * 无内容提示
 *
 * @package SteamGrid
 */
?>
<div class="sg-none">
	<h2><?php esc_html_e( '这里空空如也', 'steamgrid' ); ?></h2>
	<p><?php esc_html_e( '没有找到相关内容，试试搜索或返回首页。', 'steamgrid' ); ?></p>
	<?php get_search_form(); ?>
	<p>
		<a class="sg-btn" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( '返回首页', 'steamgrid' ); ?></a>
	</p>
</div>
