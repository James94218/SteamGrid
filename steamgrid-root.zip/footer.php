<?php
/**
 * 页脚
 *
 * @package SteamGrid
 */

$sg_footer_has_widgets = false;
for ( $sg_i = 1; $sg_i <= 4; $sg_i++ ) {
	if ( is_active_sidebar( 'footer-' . $sg_i ) ) {
		$sg_footer_has_widgets = true;
		break;
	}
}

$sg_footer_links = sg_footer_links_parse();
$sg_social       = sg_social_links();
?>
</main>

<div class="sg-sidebar-overlay" data-sg-sidebar-close hidden></div>

<footer id="colophon" class="sg-site-footer">

	<?php if ( $sg_footer_has_widgets ) : ?>
	<div class="sg-container sg-footer-widgets">
		<?php for ( $sg_i = 1; $sg_i <= 4; $sg_i++ ) : ?>
			<?php if ( is_active_sidebar( 'footer-' . $sg_i ) ) : ?>
			<div class="sg-footer-col">
				<?php dynamic_sidebar( 'footer-' . $sg_i ); ?>
			</div>
			<?php endif; ?>
		<?php endfor; ?>
	</div>
	<?php endif; ?>

	<div class="sg-footer-bar">
		<div class="sg-container sg-footer-inner">

			<div class="sg-footer-info">
				<p class="sg-copyright">
					&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
					<span class="sg-copyright-sep">·</span>
					<?php echo esc_html( sg_get( 'copyright', __( '保留所有权利', 'steamgrid' ) ) ); ?>
				</p>

				<p class="sg-footer-beian">
					<?php $sg_icp = sg_get( 'icp' ); ?>
					<?php if ( $sg_icp ) : ?>
						<a class="sg-beian-link" href="<?php echo esc_url( sg_get( 'icp_link', 'https://beian.miit.gov.cn/' ) ); ?>" target="_blank" rel="noopener nofollow">
							<?php echo sg_svg_icon( 'globe' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<span><?php echo esc_html( $sg_icp ); ?></span>
						</a>
					<?php endif; ?>

					<?php $sg_beian = sg_get( 'beian' ); ?>
					<?php if ( $sg_beian ) : ?>
						<a class="sg-beian-link sg-beian-gongan" href="<?php echo esc_url( sg_get( 'beian_link', 'https://beian.mps.gov.cn/' ) ); ?>" target="_blank" rel="noopener nofollow">
							<?php echo sg_svg_icon( 'shield' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<span><?php echo esc_html( $sg_beian ); ?></span>
						</a>
					<?php endif; ?>
				</p>
			</div>

			<?php if ( $sg_social ) : ?>
			<div class="sg-footer-social">
				<?php foreach ( $sg_social as $sg_item ) : ?>
					<a class="sg-social-link sg-social-<?php echo esc_attr( $sg_item['icon'] ); ?>" href="<?php echo esc_url( $sg_item['url'] ); ?>" target="_blank" rel="noopener nofollow" aria-label="<?php echo esc_attr( $sg_item['label'] ); ?>" title="<?php echo esc_attr( $sg_item['label'] ); ?>">
						<?php echo sg_svg_icon( $sg_item['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</a>
				<?php endforeach; ?>
			</div>
			<?php endif; ?>

			<?php if ( $sg_footer_links ) : ?>
			<div class="sg-footer-links">
				<?php foreach ( $sg_footer_links as $sg_link ) : ?>
					<a href="<?php echo esc_url( $sg_link['url'] ); ?>"><?php echo sg_svg_icon( 'link' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php echo esc_html( $sg_link['name'] ); ?></a>
				<?php endforeach; ?>
			</div>
			<?php endif; ?>

			<?php if ( has_nav_menu( 'footer' ) ) : ?>
			<nav class="sg-footer-nav" aria-label="<?php esc_attr_e( '底部导航', 'steamgrid' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'footer',
						'container'      => false,
						'menu_class'     => 'sg-menu sg-menu-footer',
						'depth'          => 1,
					)
				);
				?>
			</nav>
			<?php endif; ?>
		</div>
	</div>

	<?php sg_ad( 'footer' ); ?>

	<?php $sg_footer_html = sg_get( 'footer_html' ); ?>
	<?php if ( $sg_footer_html ) : ?>
		<div class="sg-footer-html">
			<div class="sg-container"><?php echo wp_kses_post( $sg_footer_html ); ?></div>
		</div>
	<?php endif; ?>

	<?php $sg_footer_js = sg_get( 'footer_js' ); ?>
	<?php if ( $sg_footer_js ) : ?>
		<script type="text/javascript">
			<?php echo $sg_footer_js; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- 已在保存时过滤 </script> ?>
		</script>
	<?php endif; ?>
</footer>

<?php sg_ad_float(); ?>

<button type="button" class="sg-back-top" aria-label="<?php esc_attr_e( '回到顶部', 'steamgrid' ); ?>">
	<?php echo sg_svg_icon( 'arrow-up' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
</button>

<?php wp_footer(); ?>
</body>
</html>
