<?php
/**
 * 搜索表单
 *
 * @package SteamGrid
 */

if ( ! isset( $GLOBALS['sg_search_form_count'] ) ) {
	$GLOBALS['sg_search_form_count'] = 0;
}
$GLOBALS['sg_search_form_count']++;
$sg_search_form_id = 'sg-search-field-' . $GLOBALS['sg_search_form_count'];
?>
<form role="search" method="get" class="sg-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="<?php echo esc_attr( $sg_search_form_id ); ?>"><?php esc_html_e( '搜索：', 'steamgrid' ); ?></label>
	<input
		type="search"
		id="<?php echo esc_attr( $sg_search_form_id ); ?>"
		class="sg-search-field"
		placeholder="<?php echo esc_attr( sprintf( __( '搜索 %s …', 'steamgrid' ), get_bloginfo( 'name' ) ) ); ?>"
		value="<?php echo get_search_query(); ?>"
		name="s"
	/>
	<button type="submit" class="sg-search-submit" aria-label="<?php esc_attr_e( '搜索', 'steamgrid' ); ?>">
		<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>
	</button>
</form>
