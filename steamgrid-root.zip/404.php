<?php
/**
 * 404 页面
 *
 * @package SteamGrid
 */

get_header();
?>

<div class="sg-container sg-page">
	<div class="sg-none sg-404">
		<p class="sg-404-code">404</p>
		<h1><?php esc_html_e( '页面不存在', 'steamgrid' ); ?></h1>
		<p><?php esc_html_e( '你访问的页面可能已被移除，或者地址有误。', 'steamgrid' ); ?></p>
		<?php get_search_form(); ?>
		<p>
			<a class="sg-btn" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( '返回首页', 'steamgrid' ); ?></a>
		</p>
	</div>
</div>

<?php
get_footer();
