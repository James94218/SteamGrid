<?php
/**
 * 页头
 *
 * @package SteamGrid
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( '跳至内容', 'steamgrid' ); ?></a>

<?php
$sg_announcement_text = trim( (string) sg_get( 'announcement_text' ) );
$sg_announcement_link = (string) sg_get( 'announcement_link' );
$sg_announcement_speed = max( 8, absint( sg_get( 'announcement_speed', 30 ) ) );
if ( sg_on( 'announcement_enable' ) && $sg_announcement_text ) :
	?>
	<div class="sg-announcement" data-sg-announcement>
		<div class="sg-container sg-announcement-inner">
			<span class="sg-announcement-icon" aria-hidden="true"><?php echo sg_svg_icon( 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			<div class="sg-announcement-track">
				<div class="sg-announcement-move" style="--sg-marquee-duration:<?php echo esc_attr( $sg_announcement_speed ); ?>s">
					<span class="sg-announcement-text">
						<?php if ( $sg_announcement_link ) : ?>
							<a href="<?php echo esc_url( $sg_announcement_link ); ?>"><?php echo esc_html( $sg_announcement_text ); ?></a>
						<?php else : ?>
							<?php echo esc_html( $sg_announcement_text ); ?>
						<?php endif; ?>
					</span>
					<span class="sg-announcement-text" aria-hidden="true">
						<?php if ( $sg_announcement_link ) : ?>
							<a href="<?php echo esc_url( $sg_announcement_link ); ?>" tabindex="-1"><?php echo esc_html( $sg_announcement_text ); ?></a>
						<?php else : ?>
							<?php echo esc_html( $sg_announcement_text ); ?>
						<?php endif; ?>
					</span>
				</div>
			</div>
			<?php if ( sg_on( 'announcement_close' ) ) : ?>
				<button type="button" class="sg-announcement-close" data-sg-announcement-close aria-label="<?php esc_attr_e( '关闭公告', 'steamgrid' ); ?>">
					<?php echo sg_svg_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</button>
			<?php endif; ?>
		</div>
	</div>
<?php endif; ?>

<header id="masthead" class="sg-site-header">
	<div class="sg-container sg-header-inner">

		<div class="sg-brand<?php echo sg_on( 'logo_shine' ) ? ' sg-brand-shine' : ''; ?>">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<a class="sg-brand-text" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
					<span class="sg-brand-mark" aria-hidden="true">
						<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 3v18M3 12h18"/><circle cx="12" cy="12" r="3"/></svg>
					</span>
					<span class="sg-brand-name"><?php bloginfo( 'name' ); ?></span>
				</a>
			<?php endif; ?>
		</div>

		<nav id="site-navigation" class="sg-main-nav" aria-label="<?php esc_attr_e( '主菜单', 'steamgrid' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_id'        => 'primary-menu',
					'menu_class'     => 'sg-menu',
					'fallback_cb'    => 'sg_menu_fallback',
					'depth'          => 2,
				)
			);
			?>
		</nav>

		<div class="sg-header-actions">
			<div class="sg-header-search"><?php get_search_form(); ?></div>

			<?php if ( sg_on( 'theme_toggle' ) ) : ?>
				<button type="button" class="sg-icon-btn sg-theme-toggle" data-sg-theme-toggle aria-label="<?php esc_attr_e( '切换昼夜模式', 'steamgrid' ); ?>" aria-pressed="false">
					<span class="sg-theme-icon-dark"><?php echo sg_svg_icon( 'moon' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<span class="sg-theme-icon-light"><?php echo sg_svg_icon( 'sun' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				</button>
			<?php endif; ?>

			<button type="button" class="sg-icon-btn sg-search-toggle" aria-expanded="false" aria-controls="sg-search-panel" aria-label="<?php esc_attr_e( '打开搜索', 'steamgrid' ); ?>">
				<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>
			</button>

			<?php if ( sg_on( 'auth_enable' ) ) : ?>
				<?php if ( is_user_logged_in() ) : ?>
					<?php $sg_current_user = wp_get_current_user(); ?>
					<a class="sg-header-user" href="<?php echo esc_url( sg_auth_url( 'user_center' ) ); ?>" title="<?php echo esc_attr( $sg_current_user->display_name ); ?>">
						<img class="sg-header-avatar" src="<?php echo esc_url( sg_user_avatar_url( $sg_current_user->ID, 56 ) ); ?>" alt="" width="28" height="28" />
						<span class="sg-header-username"><?php echo esc_html( $sg_current_user->display_name ); ?></span>
					</a>
				<?php else : ?>
					<a class="sg-header-login" href="<?php echo esc_url( sg_auth_url( 'login' ) ); ?>"><?php esc_html_e( '登录', 'steamgrid' ); ?></a>
					<?php if ( sg_on( 'register_enable' ) ) : ?>
						<a class="sg-header-register" href="<?php echo esc_url( sg_auth_url( 'register' ) ); ?>"><?php esc_html_e( '注册', 'steamgrid' ); ?></a>
					<?php endif; ?>
				<?php endif; ?>
			<?php endif; ?>

			<?php if ( sg_on( 'mobile_sidebar' ) && sg_has_sidebar() ) : ?>
				<button type="button" class="sg-icon-btn sg-sidebar-toggle" data-sg-sidebar-open aria-label="<?php esc_attr_e( '打开侧边栏', 'steamgrid' ); ?>">
					<?php echo sg_svg_icon( 'tag' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</button>
			<?php endif; ?>

			<button type="button" class="sg-menu-toggle" aria-expanded="false" aria-controls="primary-menu" aria-label="<?php esc_attr_e( '打开菜单', 'steamgrid' ); ?>">
				<span></span><span></span><span></span>
			</button>
		</div>
	</div>

	<div id="sg-search-panel" class="sg-search-panel">
		<div class="sg-container"><?php get_search_form(); ?></div>
	</div>
</header>

<?php sg_ad( 'header' ); ?>

<main id="primary" class="sg-main">
